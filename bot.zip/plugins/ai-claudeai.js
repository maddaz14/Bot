import axios from 'axios';

const handler = async (m, { conn, text, usedPrefix, command }) => {
    // Pastikan ada teks query yang diberikan oleh pengguna
    if (!text) {
        throw `Hai! Saya adalah Claude AI. Apa yang ingin kamu tanyakan hari ini?\n\nContoh: *${usedPrefix}${command} Siapa pencipta internet?*`;
    }

    // Ambil domain dan API Key Maelyn dari global.maelyn di config.js
    const maelynDomain = global.maelyn.domain;
    const maelynApiKey = global.maelyn.key;

    // Lakukan validasi dasar untuk memastikan konfigurasi ada
    if (!maelynDomain || !maelynApiKey) {
        throw 'API Key atau Domain Maelyn untuk Claude AI belum diatur di config.js! Mohon hubungi pemilik bot.';
    }

    await conn.sendMessage(m.chat, { react: { text: '🍏', key: m.key } }); // Reaksi loading

    try {
        // Encode the query for URL safety
        const encodedQuery = encodeURIComponent(text);
        // Build the API URL
        const apiUrl = `${maelynDomain}/api/claude?q=${encodedQuery}&apikey=${maelynApiKey}`;

        // Send GET request to the Maelyn API
        const response = await axios.get(apiUrl);
        const { status, result, code } = response.data;

        if (status === 'Success' && code === 200 && result) {
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); // Reaksi sukses
            m.reply(result); // Result langsung berupa string respons AI
        } else {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }); // Reaksi gagal
            m.reply(`❌ Gagal mendapatkan respons dari Claude AI. Respon API: ${JSON.stringify(response.data)}`);
        }
    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }); // Reaksi error
        m.reply(`Terjadi kesalahan saat menghubungi Claude AI API: ${e.message}`);
    }
};

handler.help = ['claudechat', 'claudeai'];
handler.tags = ['ai'];
handler.command = /^(claudechat|claudeai)$/i; // Menggunakan regex untuk beberapa alias
handler.limit = true; // Batasi penggunaan jika perlu
handler.premium = false; // Hanya untuk pengguna non-premium jika perlu

export default handler;