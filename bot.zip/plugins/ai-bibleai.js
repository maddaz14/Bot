import axios from "axios"

// ==========================================================
// 1. DATA TRANSLATION DAN FUNGSI VALIDASI
// ==========================================================

// Daftar terjemahan yang valid
const validTranslations = {
  "IRVBen": "Indian Revised Version (Bengali)",
  "CUV": "Chinese Union Version",
  "nld1939": "Dutch 1939 Petrus Canisiusvertaling",
  "NBG": "Dutch NBG 1951",
  "ESV": "English Standard Version",
  "NASB20": "New American Standard Bible 2020",
  "ASV14": "American Standard Version 1914",
  "KJV11": "King James Version 1611",
  "LSG": "Louis Segond (French)",
  "LUT": "Luther Bible (German)",
  "IRVHin": "Indian Revised Version (Hindi)",
  "PaBa": "Pavitra Bible (Hindi)",
  "TB": "Alkitab Terjemahan Baru 1974 (Indonesian)", // Default Indonesia
  "DB1885": "Diodati Bibbia 1885 (Italian)",
  "NR06": "Nuova Riveduta 2006 (Italian)",
  "polUBG": "Polish Biblia Gdańska",
  "AA": "Almeida Atualizada (Portuguese)",
  "RVR09": "Reina Valera 1909 (Spanish)",
  "SKB": "Svenska Kärnbibeln",
  "SV1917": "Swedish 1917 Bible",
  "KJV": "King James Version (Thai)",
  "IRVUrd": "Indian Revised Version (Urdu)",
  "DGV": "Kitab-e-Muqaddas (Urdu)",
  "ERVVI": "Easy-to-Read Vietnamese Version",
}

// Fungsi untuk memeriksa validitas kode terjemahan
function isValidTranslation(abbreviation) {
  return Object.keys(validTranslations).includes(abbreviation)
}

// ==========================================================
// 2. FUNGSI PENCARIAN API BIBLE AI
// ==========================================================

async function searchBibleAI(question, translationAbbr = "TB") {
  // Hanya memastikan kode terjemahan dalam huruf besar
  const selectedTranslation = translationAbbr.toUpperCase()

  if (!isValidTranslation(selectedTranslation)) {
    throw new Error(`Terjemahan "${selectedTranslation}" tidak valid.`)
  }

  const encodedQuestion = encodeURIComponent(question)

  const config = {
    method: "GET",
    url: `https://api.bibleai.com/v2/search?question=${encodedQuestion}&translation=${selectedTranslation}&filters[]=bible&filters[]=books&filters[]=articles&pro=true&language=en-US&id=`,
    headers: {
      "User-Agent": "Mozilla/5.0 (Linux; Android 12; itel S665L Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/137.0.7151.115 Mobile Safari/537.36",
      "Accept": "application/json, text/plain, */*",
      "Accept-Encoding": "gzip, deflate, br, zstd",
      "sec-ch-ua-platform": "\"Android\"",
      "sec-ch-ua": "\"Android WebView\";v=\"137\", \"Chromium\";v=\"137\", \"Not/A)Brand\";v=\"24\"",
      "sec-ch-ua-mobile": "?1",
      "app-version": "1.2.0",
      "device-agent": "itel S665L Build/SP1A.210812.016 Android 12",
      "origin": "https://localhost",
      "x-requested-with": "bible.ai.search",
      "sec-fetch-site": "cross-site",
      "sec-fetch-mode": "cors",
      "sec-fetch-dest": "empty",
      "sec-fetch-storage-access": "active",
      "referer": "https://localhost/",
      "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      "priority": "u=1, i",
    },
    timeout: 30000,
  }

  try {
    const { data: response } = await axios.request(config)
    
    if (!response.data || !response.data.answer) {
        throw new Error("Jawaban AI kosong atau format API berubah.")
    }
    
    return { 
        answer: response.data.answer, 
        sources: response.data.sources, 
        metadata: response.data.metadata,
        translation: validTranslations[selectedTranslation],
        translationCode: selectedTranslation,
    }
  } catch (error) {
    if (error.response) {
      throw new Error(`API Error: ${error.response.status} - ${error.response.statusText}`)
    } else if (error.request) {
      throw new Error("Network Error: Tidak ada respons dari API.")
    } else {
      throw new Error(`Request Error: ${error.message}`)
    }
  }
}

// ==========================================================
// 3. HANDLER PLUGIN BOT WHATSAPP
// ==========================================================

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    // Memberi daftar terjemahan yang disarankan
    const suggestedTranslations = ['TB', 'ESV', 'KJV', 'LUT', 'RVR09']
    const suggestionList = suggestedTranslations.map(code => 
        ` - *${code}* (${validTranslations[code].split('(')[0].trim()})`
    ).join('\n')
    
    return m.reply(`*Contoh penggunaan:*
${usedPrefix}${command} apa itu iman | ESV

*Pemisah:* Gunakan tanda *vertikal bar* (|) untuk memisahkan pertanyaan dan kode terjemahan.

*Terjemahan Default:* TB (Terjemahan Baru Indonesia)

*Terjemahan yang disarankan:*
${suggestionList}
    
*Untuk melihat semua kode:* ${usedPrefix}${command} list
`);
  }
  
  // Tampilkan daftar terjemahan
  if (text.toLowerCase().trim() === 'list') {
      const translationList = Object.entries(validTranslations)
        .map(([code, name]) => `*${code}* - ${name}`)
        .join('\n')
        
      return m.reply(`*Daftar Kode Terjemahan Alkitab (Bible AI):*\n\n${translationList}`);
  }

  await conn.sendMessage(m.chat, {
    react: { text: '🧠', key: m.key } // Reaksi untuk AI/proses berpikir
  })

  // Memisahkan pertanyaan dan kode terjemahan
  const [question, translationInput] = text.split('|').map(s => s.trim())
  
  // Tentukan terjemahan, default ke 'TB'
  const translationCode = (translationInput || 'TB').toUpperCase()

  if (!question) {
       return m.reply(`Pertanyaan tidak boleh kosong. Gunakan: ${usedPrefix}${command} <pertanyaan> | <kode_terjemahan>`);
  }

  try {
    const result = await searchBibleAI(question, translationCode)

    const sourcesText = result.sources && result.sources.length > 0
        ? `*Sumber Ayat:*\n${result.sources.map(s => ` - ${s.book} ${s.chapter}:${s.verse}`).join('\n')}`
        : '';
        
    const finalCaption = `*Jawaban AI Alkitab*
*Terjemahan:* ${result.translation} (*${result.translationCode}*)
*Pertanyaan:* ${question}

---
*Jawaban:*
${result.answer}

---
${sourcesText}

_Powered by Bible AI_
`;
    
    // Kirim jawaban
    await m.reply(finalCaption)

    await conn.sendMessage(m.chat, {
      react: { text: '✅', key: m.key }
    })
  } catch (e) {
    console.error('Error BibleAI:', e)
    m.reply(`❌ Eror saat mencari jawaban:\n\n${e.message}`)
    
    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key }
    })
  }
}

handler.command = ['bibleai', 'bai']
handler.help = ['bibleai <pertanyaan> | <kode_terjemahan>']
handler.tags = ['ai', 'religi']

export default handler