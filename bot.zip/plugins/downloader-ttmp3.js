import axios from 'axios'
import moment from 'moment-timezone'

// Ambil data TikTok via API tikwm
async function tiktokV1(query) {
  const encodedParams = new URLSearchParams()
  encodedParams.set('url', query)
  encodedParams.set('hd', '1')

  const { data } = await axios.post('https://tikwm.com/api/', encodedParams, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      Cookie: 'current_language=en',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
    }
  })

  return data
}

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply('Masukkan URL TikTok!\nContoh: .ttmp3 https://vt.tiktok.com/xxxxxx')

  // React emoji 🕊️ saat mulai proses
  await conn.sendMessage(m.chat, {
    react: { text: '🕊️', key: m.key }
  })

  try {
    const dataV1 = await tiktokV1(text)
    if (!dataV1?.data) return m.reply('Gagal mengambil data dari TikTok!')

    const d = dataV1.data

    // Ambil info musik
    const musicUrl = d.music || d.music_info?.play || null
    const musicTitle = d.music_info?.title || 'tiktok_audio'
    const musicAuthor = d.music_info?.author || 'unknown'

    if (!musicUrl) return m.reply('Tidak ada audio yang ditemukan pada video ini!')

    const time = d.create_time
      ? moment.unix(d.create_time).tz('Asia/Jakarta').format('dddd, D MMMM YYYY [pukul] HH:mm:ss')
      : '-'

    const caption = `*TikTok MP3 Info*
*Judul:* ${d.title || '-'}
*Musik:* ${musicTitle} - ${musicAuthor}
*Durasi:* ${d.duration || '-'}s
*Upload:* ${time}
*Views:* ${d.play_count || 0} | *Likes:* ${d.digg_count || 0}`

    // Kirim audio langsung
    await conn.sendMessage(m.chat, {
      audio: { url: musicUrl },
      fileName: `${musicTitle}.mp3`,
      mimetype: 'audio/mpeg',
      ptt: false,
      caption
    }, { quoted: m })

    // React emoji ✅ setelah selesai kirim audio
    await conn.sendMessage(m.chat, {
      react: { text: '✅', key: m.key }
    })
  } catch (e) {
    console.error(e)
    m.reply(`Terjadi kesalahan: ${e.message}`)
  }
}

handler.command = ['ttmp3']
handler.help = ['ttmp3 <url>']
handler.tags = ['downloader']

export default handler