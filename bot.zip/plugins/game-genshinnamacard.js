import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  // Jika tidak ada input, tampilkan semua namecard yang tersedia
  if (!text) {
    try {
      const available = await genshindb.namecards("names", { matchCategories: true });
      return m.reply(`🧧 *Daftar Namecard Tersedia:*\n\n${available.join(", ")}`);
    } catch (e) {
      console.error('[NAMECARD LIST ERROR]', e);
      return m.reply('❌ Gagal mengambil daftar kartu nama.');
    }
  }

  try {
    const result = await genshindb.namecards(text);

    if (result) {
      let response = `🧧 *Kartu Nama: ${result.name}*\n\n`;
      response += `📖 _${result.description || "Deskripsi tidak tersedia"}_\n\n`;
      response += `⭐ *Rarity:* ${result.rarity || "Tidak diketahui"}\n`;
      response += `🔓 *Unlock:* ${result.unlock || "Tidak diketahui"}`;
      return m.reply(response);
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[NAMECARD ERROR]', err);
    try {
      const available = await genshindb.namecards("names", { matchCategories: true });
      return m.reply(`❌ Kartu nama '${text}' tidak ditemukan.\n\n📜 *Namecard yang tersedia:*\n${available.join(", ")}`);
    } catch (e) {
      return m.reply('⚠️ Gagal menampilkan daftar kartu nama.');
    }
  }
};

handler.help = ['genshin-namacard <nama>'];
handler.tags = ['game'];
handler.command = /^(genshin-namacard|g-namacard|gens-namacard)$/i;
handler.limit = 1;
handler.register = true;

export default handler;