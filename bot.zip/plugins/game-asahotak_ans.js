import similarity from 'similarity'
import { jidNormalizedUser } from '@fuxxy-star/baileys'
const threshold = 0.72

let handler = async (m, { conn, args }) => {
  conn.asahotak = conn.asahotak || {}
  let id = m.chat
  if (!(id in conn.asahotak)) return m.reply('Tidak ada soal aktif di chat ini. Ketik .asahotak untuk memulai.')

  if (!args[0]) return m.reply('Contoh: .asah enigma')

  let soal = conn.asahotak[id]
  let jawaban = args.join(' ').toLowerCase().trim()
  let json = soal[1]

  if (jawaban === json.jawaban.toLowerCase().trim()) {
    let user = jidNormalizedUser(m.sender)
    global.db.data.users[user].exp += soal[2]
    m.reply(`*Benar!*\n+${soal[2]} XP`)
    clearTimeout(soal[4])
    delete conn.asahotak[id]
  } else if (similarity(jawaban, json.jawaban.toLowerCase().trim()) >= threshold) {
    m.reply('*Dikit lagi!*')
  } else {
    m.reply('*Salah!*')
  }
}

handler.command = /^asah$/i
handler.limit = true

export default handler