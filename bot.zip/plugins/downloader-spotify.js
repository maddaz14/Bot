import fetch from 'node-fetch';

const fkontak = {
  key: {
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast',
    fromMe: false,
    id: 'SPOTIFY'
  },
  message: {
    conversation: `🎵 Spotify Downloader by ${global.namebot || 'Bot'}`
  }
};

const s = {
    tools: {
        async hit(description, url, options, returnType = 'text') {
            try {
                const response = await fetch(url, options);
                if (!response.ok) throw new Error(`${response.status} ${response.statusText}\n${await response.text() || '(response body kosong)'}`);
                if (returnType === 'text') {
                    const data = await response.text();
                    return { data, response };
                } else if (returnType === 'json') {
                    const data = await response.json();
                    return { data, response };
                } else {
                    throw new Error('invalid returnType param.');
                }
            } catch (e) {
                throw new Error(`hit ${description} failed. ${e.message}`);
            }
        }
    },

    get baseUrl() {  
        return 'https://spotisongdownloader.to';
    },  
    get baseHeaders() {  
        return {  
            'accept-encoding': 'gzip, deflate, br, zstd',  
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0'  
        };
    },  

    async getCookie() {  
        const url = this.baseUrl;
        const headers = this.baseHeaders;
        const { response } = await this.tools.hit('homepage', url, { headers });
        
        const setCookieHeader = response.headers.get('set-cookie');
        if (!setCookieHeader) throw new Error('gagal mendapatkan header Set-Cookie');

        let cookie = setCookieHeader.split('; ')?.[0];
        
        if (!cookie?.length) throw new Error(`gagal mendapatkan kuki`);
        cookie += '; _ga=GA1.1.2675401.1754827078';
        return { cookie };
    },  

    async ifCaptcha(gcObject) {  
        const pathname = '/ifCaptcha.php';
        const url = new URL(pathname, this.baseUrl);
        const headers = {  
            referer: new URL(this.baseUrl).href,  
            ...gcObject,  
            ...this.baseHeaders  
        };
        await this.tools.hit('ifCaptcha', url, { headers });
        return headers;
    },  

    async singleTrack(spotifyTrackUrl, icObject) {  
        const pathname = '/api/composer/spotify/xsingle_track.php';
        const url = new URL(pathname, this.baseUrl);
        url.search = new URLSearchParams({ url: spotifyTrackUrl });
        const headers = icObject;
        const { data } = await this.tools.hit('single track', url, { headers }, 'json');
        return data;
    },  

    async singleTrackHtml(stObject, icObj) {  
        const payload = [  
            stObject.song_name,  
            stObject.duration,  
            stObject.img,  
            stObject.artist,  
            stObject.url,  
            stObject.album_name,  
            stObject.released  
        ];
        const pathname = '/track.php';
        const url = new URL(pathname, this.baseUrl);
        const headers = icObj;
        const body = new URLSearchParams({ data: JSON.stringify(payload) });
        await this.tools.hit('track html', url, { headers, body, method: 'post' });
        return true;
    },  

    async downloadUrl(spotifyTrackUrl, icObj, stObj) {  
        const pathname = '/api/composer/spotify/ssdw23456ytrfds.php';
        const url = new URL(pathname, this.baseUrl);
        const headers = icObj;
        const body = new URLSearchParams({  
            song_name: '',  
            artist_name: '',  
            url: spotifyTrackUrl,  
            zip_download: 'false',  
            quality: 'm4a'  
        });
        const { data } = await this.tools.hit('get download url', url, { headers, body, method: 'post' }, 'json');
        return { ...data, ...stObj };
    },  

    async download(spotifyTrackUrl) {  
        const gcObj = await this.getCookie();
        const icObj = await this.ifCaptcha(gcObj);
        const stObj = await this.singleTrack(spotifyTrackUrl, icObj);
        await this.singleTrackHtml(stObj, icObj);
        const dlObj = await this.downloadUrl(spotifyTrackUrl, icObj, stObj);
        return dlObj;
    }
};

const handler = async (m, { conn, args, usedPrefix, command }) => {
  const query = args.join(' ');
  if (!query) throw `🔍 Contoh penggunaan:\n${usedPrefix + command} Can You Feel the Love Tonight`;

  await conn.sendMessage(m.chat, { react: { text: '🎶', key: m.key } });

  try {
    const searchUrl = `https://api.siputzx.my.id/api/s/spotify?query=${encodeURIComponent(query)}`;
    const searchRes = await fetch(searchUrl);
    const searchJson = await searchRes.json();

    if (!searchJson.status || !Array.isArray(searchJson.data) || searchJson.data.length === 0) {
      throw new Error('Lagu tidak ditemukan.');
    }

    const track = searchJson.data[0];
    const dl = await s.download(track.track_url);

    if (!dl || !dl.dlink) {
      throw new Error('Gagal mengunduh lagu.');
    }
    
    const audioRes = await fetch(dl.dlink);
    if (!audioRes.ok) throw new Error('Gagal mengunduh audio.');
    const audioBuffer = await audioRes.arrayBuffer();

    const caption = `
🎵 *${dl.song_name}*
🧑‍🎤 *Artist:* ${dl.artist}
🕒 *Durasi:* ${track.duration}
📅 *Spotify URL:* ${track.track_url}

> Powered by ${global.namebot || 'Bot'}
`.trim();

    await conn.sendMessage(m.chat, {
      audio: Buffer.from(audioBuffer),
      mimetype: 'audio/mpeg',
      fileName: `${dl.song_name}.mp3`,
      ptt: false,
      caption,
      contextInfo: {
        externalAdReply: {
          title: dl.song_name,
          body: dl.artist,
          mediaType: 2,
          renderLargeThumbnail: true,
          thumbnailUrl: dl.img || 'https://files.catbox.moe/krt1fc.jpg',
          sourceUrl: track.track_url
        }
      }
    }, { quoted: fkontak });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    console.error(err);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    await conn.reply(m.chat, `❌ Gagal:\n${err.message || err}`, m, { quoted: fkontak });
  }
};

handler.help = ['spotify <judul lagu>'];
handler.tags = ['downloader'];
handler.command = /^spotify$/i;
handler.limit = true;
handler.register = true;

export default handler;