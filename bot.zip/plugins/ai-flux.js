import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        throw `Masukkan prompt!\n\nContoh:\n${usedPrefix + command} cyberpunk lizard`;
    }

    await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });

    const url = `https://api.siputzx.my.id/api/ai/flux?prompt=${encodeURIComponent(text)}`;

    try {
        const response = await axios.get(url, { responseType: 'arraybuffer' });

        await conn.sendMessage(m.chat, {
            image: response.data,
            caption: `🧠 AI Flux Prompt:\n*${text}*`
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        m.reply('❌ Gagal menghasilkan gambar. Pastikan prompt valid.');
    }
};

handler.help = ['flux <prompt>'];
handler.tags = ['ai', 'image'];
handler.command = /^flux$/i;
handler.limit = true;

export default handler;