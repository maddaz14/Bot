let handler = async (m, { conn, args }) => {
    if (!args[0]) throw 'Masukkan ID channel atau default ke ubed Bot'
    
    // ID channel (newsletter)
    let channelId = args[0] || '120363369035192952@newsletter'
    
    // Ambil pesan terakhir dari channel
    let msgs = store.messages[channelId]
    if (!msgs || !msgs.length) throw 'Tidak ada pesan di channel ini, pastikan bot sudah join channel'
    
    // Ambil 1 pesan terakhir
    let lastMsg = msgs[msgs.length - 1]

    // Forward pesan asli
    await conn.relayMessage(m.chat, lastMsg.message, { messageId: lastMsg.key.id })
}

handler.command = /^forwardchannel$/i
export default handler