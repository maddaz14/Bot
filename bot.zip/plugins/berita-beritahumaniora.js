import axios from 'axios';

/**
 * Endpoint API Antara News - Humanities
 */
const API_URL = 'https://api.nekolabs.my.id/news/antara/humanities';

/**
 * Handler utama bot untuk menampilkan berita humaniora Antara.
 */
let handler = async (m, { conn, usedPrefix, command }) => {
    const emoji = '🧘';
    
    // 1. Reaksi Emoji Saat Memproses
    await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } });

    try {
        // 2. Kirim Permintaan ke API
        const response = await axios.get(API_URL, {
            timeout: 20000 
        });

        const data = response.data;

        // 3. Validasi Respon API
        if (data && data.status === true && data.result && data.result.length > 0) {
            
            // Ambil maksimal 5 hasil pertama
            const results = data.result.slice(0, 5); 
            
            let caption = `*--- 🧘 Berita Gaya Hidup/Humaniora (Antara) ---*\n\n`;

            results.forEach((item, index) => {
                // Format tanggal agar lebih mudah dibaca
                const date = new Date(item.date).toLocaleDateString('id-ID', {
                    year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
                });
                
                // Batasi deskripsi agar tidak terlalu panjang
                const description = item.description.length > 100 
                                  ? item.description.substring(0, 100).replace(/&ldquo;|&rdquo;/g, '"') + '...' 
                                  : item.description.replace(/&ldquo;|&rdquo;/g, '"');
                                  
                caption += `*${index + 1}. ${item.title}*\n`;
                caption += `  • Tanggal: ${date}\n`;
                caption += `  • Deskripsi: ${description}\n`;
                caption += `  • Baca Selengkapnya: ${item.url}\n\n`;
            });

            caption += `_Menampilkan ${results.length} berita terbaru._`;

            // Hapus reaksi
            await conn.sendMessage(m.chat, { react: { text: null, key: m.key } });
            
            // Kirim thumbnail berita pertama sebagai preview
            const firstThumbnail = results[0].thumbnail;

            await conn.sendFile(m.chat, firstThumbnail, 'humanities_news_preview.jpg', caption, m);
            
        } else {
            // Kasus status: false atau tidak ditemukan
            throw new Error(data.message || 'Gagal mendapatkan data berita humaniora dari API.');
        }

    } catch (e) {
        // 4. Error Handling dan Hapus Reaksi
        await conn.sendMessage(m.chat, { react: { text: null, key: m.key } });
        
        let errorMessage = 'Terjadi kesalahan saat menghubungi server berita.';
        if (axios.isAxiosError(e) && e.response) {
            errorMessage = `Server API error: Status ${e.response.status}.`;
        } else if (e.message) {
            errorMessage = e.message;
        }

        console.error('Error Antara Humanities News:', e);
        m.reply(`⚠️ Waduh, ada masalah nih, Senpai:\n${errorMessage}`);
    }
};

handler.help = ['beritahumaniora'];
handler.command = ['beritahumaniora', 'antarahum'];
handler.tags = ['news'];
handler.limit = true;

export default handler;