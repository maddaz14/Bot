let handler = async (m) => m;

// Daftar kata kunci promosi
let promoWords = /\b(jual|jualan|diskon|promo|harga|order|ready|stock|gratis|ongkir|open\s?po|borong|cuci\s?gudang|gas\s?order|cuan|cod|murah|pre\s?order|stock\s?terbatas|bayar\s?ditempat|beli|grab\s?it|big\s?sale|flash\s?sale|deal)\b/i;

handler.before = async function (m, { isBotAdmin, isAdmin, conn }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true;

  // Pastikan data chat ada
  let chat = global.db.data.chats[m.chat] || {};
  if (typeof chat.antiPromosi === "undefined") chat.antiPromosi = false;
  global.db.data.chats[m.chat] = chat;

  let isPromo = promoWords.test(m.text || "");

  if (chat.antiPromosi && isPromo) {
    if (isAdmin) {
      return m.reply("*Admin kebal dari anti promosi.*");
    }

    if (!isBotAdmin) {
      return m.reply("*Bot bukan admin, tidak bisa hapus.*");
    }

    await m.reply(
      `*「 ANTI PROMOSI 」*\nPesan ${await conn.getName(m.sender)} terdeteksi promosi, langsung dihapus 🚫`
    );

    await conn.sendMessage(m.chat, { delete: m.key });
    return true;
  }

  return false;
};

export default handler;