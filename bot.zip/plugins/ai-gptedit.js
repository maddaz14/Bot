import axios from "axios";
import FormData from "form-data";
import { fileTypeFromBuffer } from "file-type";

// 🔥 Scrap API Key dari overchat.ai
async function scrapeApiKey() {
  try {
    const targetUrl = "https://overchat.ai/image/ghibli";
    const { data: htmlContent } = await axios.get(targetUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    });

    const apiKeyRegex = /const apiKey = '([^']+)'/;
    const match = htmlContent.match(apiKeyRegex);

    if (match && match[1]) {
      return match[1];
    } else {
      throw new Error("Gagal menemukan API Key di halaman web.");
    }
  } catch (err) {
    throw new Error(`Scrape API Key gagal: ${err.message}`);
  }
}

// 🔥 Plugin handler .gptedit
let handler = async (m, { conn, text }) => {
  try {
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    if (!text) {
      return m.reply(
        "📌 Contoh: reply gambar dengan caption *.gptedit ubah jadi kartun anime*"
      );
    }

    // --- ambil media ---
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";
    if (!mime.startsWith("image/"))
      return m.reply("❌ Kirim atau reply gambar dengan caption *.gptedit [prompt]*");

    let media = await q.download();
    if (!media) return m.reply("❌ Gagal mendownload media");

    const ext = (await fileTypeFromBuffer(media))?.ext || "png";

    // --- scrap api key ---
    const apiKey = await scrapeApiKey();

    // --- kirim request ke OpenAI ---
    const apiUrl = "https://api.openai.com/v1/images/edits";
    const form = new FormData();
    form.append("image", media, { filename: `file.${ext}`, contentType: mime });
    form.append("prompt", text); // prompt dari user
    form.append("model", "gpt-image-1");
    form.append("n", 1);
    form.append("size", "1024x1024");
    form.append("quality", "medium");

    const response = await axios.post(apiUrl, form, {
      headers: {
        ...form.getHeaders(),
        Authorization: `Bearer ${apiKey}`,
      },
      responseType: "json",
    });

    const resultData = response.data;
    if (resultData?.data?.[0]?.b64_json) {
      const base64Image = resultData.data[0].b64_json;
      const buffer = Buffer.from(base64Image, "base64");

      await conn.sendMessage(
        m.chat,
        { image: buffer, mimetype: "image/png", caption: "✨ Hasil edit siap!" },
        { quoted: m }
      );
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } else {
      throw new Error("Respons API tidak valid atau tidak berisi data gambar.");
    }
  } catch (err) {
    console.error(err);
    m.reply(`💥 Error: ${err.message || err}`);
  }
};

handler.help = ["gptedit <prompt>"];
handler.tags = ["ai", "image"];
handler.command = /^gptedit$/i;

export default handler;