import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text || isNaN(parseInt(text))) {
    return m.reply(`❗ Masukkan nomor *rank petualang* yang valid.\n\nContoh:\n*${usedPrefix + command} 5*`);
  }

  let rankNumber = parseInt(text);

  try {
    const result = await genshindb.adventureranks(rankNumber);
    if (result) {
      let response = `🧭 *Rank Petualang Ditemukan: Rank ${rankNumber}*\n\n`;
      response += `📈 *Experience:* ${result.exp || "Tidak tersedia"}\n`;
      response += `🎁 *Reward:* ${result.reward || "Tidak tersedia"}\n`;
      response += `📖 *Deskripsi:* ${result.description || "Tidak tersedia"}`;
      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[ADV RANK ERROR]', err);
    try {
      const list = await genshindb.adventureranks("names");
      return m.reply(`❌ Rank ${rankNumber} tidak ditemukan.\n\n📜 *Rank yang tersedia:*\n${list.join(", ")}`);
    } catch (e) {
      return m.reply('⚠️ Gagal mengambil daftar rank petualang.');
    }
  }
};

handler.help = ['genshin-advrank <angka>'];
handler.tags = ['game'];
handler.command = /^(genshin-rankaddventure|g-rankaddventure|genshin-advrank|g-advrank|gens-rankaddventure|gens-advrank)$/i;
handler.limit = 1;
handler.register = true;

export default handler;