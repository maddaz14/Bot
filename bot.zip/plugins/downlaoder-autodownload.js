import axios from 'axios'

const detectPlatform = (url = '') => {
  url = url.toLowerCase()
  if (url.includes('tiktok.com') || url.includes('vt.tiktok.com')) return 'tiktok'
  if (url.includes('instagram.com')) return 'instagram'
  if (url.includes('facebook.com') || url.includes('fb.watch')) return 'facebook'
  return null
}

let handler = async (m, { conn, text }) => {
  if (!text) throw 'Contoh: *.autodownload on* atau *.autodownload off*'

  if (text.toLowerCase() === 'on') {
    global.autodownload = true
    m.reply('✅ Auto-download diaktifkan.')
  } else if (text.toLowerCase() === 'off') {
    global.autodownload = false
    m.reply('❌ Auto-download dimatikan.')
  } else {
    throw 'Gunakan format: *.autodownload on* atau *.autodownload off*'
  }
}

handler.command = ['autodownload']
handler.help = ['autodownload [on/off]']
handler.tags = ['downloader']
handler.owner = true

// Auto detect & download
handler.before = async (m, { conn }) => {
  global.autodownload = global.autodownload ?? false
  if (!global.autodownload) return
  
  // Daftar keyword yang akan diabaikan
  const keywordsToIgnore = ['.tt', '.tiktok', '.fb', '.facebook', '.ig', '.instagram', '.twitter']
  
  // Periksa apakah pesan mengandung salah satu keyword
  const textMessage = m.text?.toLowerCase() || ''
  if (keywordsToIgnore.some(keyword => textMessage.includes(keyword))) {
    // Jika ada keyword, bot akan berhenti tanpa merespons
    return
  }

  const urlMatch = m.text?.match(/https?:\/\/[^\s]+/gi)
  if (!urlMatch) return

  const url = urlMatch[0]
  const platform = detectPlatform(url)

  if (!platform) return
  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

  try {
    let result, caption, fileUrl, fileName

    if (platform === 'tiktok') {
      const { data } = await axios.get(`https://api.maelyn.sbs/api/tiktok/download?url=${encodeURIComponent(url)}&apikey=zahra999`)
      if (!data || !data.result?.video?.nwm_url) throw '❌ Gagal mengambil video TikTok.'
      result = data.result
      fileUrl = result.video.nwm_url
      caption = `🎵 *TIKTOK*\n👤 Author: ${result.author.nickname}\n🎬 Title: ${result.title || '-'}`
    }

    if (platform === 'instagram') {
      const { data } = await axios.get(`https://api.maelyn.sbs/api/instagram?url=${encodeURIComponent(url)}&apikey=zahra999`)
      if (!data?.result?.length) throw '❌ Gagal mengambil video Instagram.'
      result = data.result[0]
      fileUrl = result.download_link
      caption = `📸 *INSTAGRAM*\n🖼️ Thumbnail: ${result.thumbnail_link}`
    }

    if (platform === 'facebook') {
      const { data } = await axios.get(`https://api.maelyn.sbs/api/facebook?url=${encodeURIComponent(url)}&apikey=zahra999`)
      if (!data?.result?.medias?.length) throw '❌ Gagal mengambil video Facebook.'
      result = data.result
      const hd = result.medias.find(v => v.quality === 'hd') || result.medias[0]
      fileUrl = hd.url
      caption = `📘 *FACEBOOK*\n🎬 ${result.title || 'Video'}\n💾 Quality: ${hd.quality}`
    }

    if (!fileUrl) throw '❌ Link media tidak ditemukan.'

    await conn.sendFile(m.chat, fileUrl, fileName || 'media.mp4', caption, m)
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    m.reply(`Gagal download media.\n\n${err.message || err}`)
  }
}

export default handler