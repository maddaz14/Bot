import { GoogleGenerativeAI } from "@google/generative-ai";
import fs from "fs";
import path from "path";

// --- KONFIGURASI ---
// Menggunakan API Key Anda (Asumsi AIzaSyDGKKLqFglsXuW8fv64qbkMjlG1i6t_AIU adalah key yang valid)
const GEMINI_API_KEY = "AIzaSyDGKKLqFglsXuW8fv64qbkMjlG1i6t_AIU";
const MODEL_NAME = "gemini-2.0-flash-exp-image-generation"; // Model yang Anda gunakan

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";

  if (!mime) return m.reply(`Kirim/reply gambar dengan caption *${usedPrefix + command}*`);
  if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png.`);
  
  // 1. Tentukan style tambahan (opsional) atau cadar saja
  let customStyle = text ? `, in the style of ${text}` : ''; 
  
  // 2. PROMPT PERMANEN: Instruksi untuk menambahkan cadar dan mempertahankan objek/pose
  const promptText = `
Modify the main subject/character in the image. The character must be wearing a complete face veil (niqab or cadar) that covers the entire face, showing only the eyes.
Preserve the character's original pose, position, and background as much as possible.
The rest of the clothing should be modest, covering the whole body. ${customStyle}.
`;

  m.reply(`Proses menambahkan cadar pada objek gambar${text ? ` dengan gaya ${text}` : ''}...`);

  try {
    let imgData = await q.download();
    
    // Pastikan folder tmp ada
    const tempDir = path.join(process.cwd(), "tmp");
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    
    let genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    const base64Image = imgData.toString("base64");

    const contents = [
      { text: promptText },
      {
        inlineData: {
          mimeType: mime,
          data: base64Image
        }
      }
    ];

    const model = genAI.getGenerativeModel({
      model: MODEL_NAME,
      generationConfig: {
        responseModalities: ["Text", "Image"]
      },
    });

    const response = await model.generateContent(contents);

    let resultImage;
    let resultText = "";

    // Logika parsing respons
    const candidate = response.response.candidates?.[0];
    if (candidate) {
        for (const part of candidate.content.parts) {
            if (part.text) {
                resultText += part.text;
            } else if (part.inlineData) {
                const imageData = part.inlineData.data;
                resultImage = Buffer.from(imageData, "base64");
            }
        }
    }


    if (resultImage) {
      const tempPath = path.join(process.cwd(), "tmp", `cadar_${Date.now()}.png`);
      fs.writeFileSync(tempPath, resultImage);

      await conn.sendMessage(m.chat, {
        image: { url: tempPath },
        caption: `*✅ Berhasil! Objek sekarang bercadar.*`
      }, { quoted: m });

      // Hapus file sementara setelah 30 detik
      setTimeout(() => {
        try {
          fs.unlinkSync(tempPath);
        } catch { }
      }, 30000);
    } else {
      m.reply(`❌ Gagal mengubah gambar. Coba lagi nanti. ${resultText.trim() ? `\n\nPesan API: ${resultText.trim()}` : ''}`);
    }
  } catch (error) {
    console.error(error);
    m.reply(`💥 Error: ${error.message}`);
  }
};

handler.help = ["pakaicadar", "cadarkan"];
handler.tags = ["ai", "maker"];
handler.command = ["pakaicadar", "cadar", "cadarkan"];

export default handler;