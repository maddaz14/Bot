import fetch from 'node-fetch'

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text || !text.includes('|')) throw `Contoh: ${usedPrefix + command} zahra|hahaha`

  const [lama, baru] = text.split('|').map(v => v.trim())
  if (!lama || !baru) throw 'Format salah. Gunakan: lama|baru'

  const githubUsername = 'Obet24077'
  const repo = 'Baru'
  const token = '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'
  const branch = 'main'

  const settingsApiUrl = `https://api.github.com/repos/${githubUsername}/${repo}/contents/src/settings.json`

  const resSettings = await fetch(settingsApiUrl, {
    headers: { Authorization: `Bearer ${token}` }
  })
  if (!resSettings.ok) throw 'Gagal mengambil settings.json dari GitHub'

  const jsonSettings = await resSettings.json()
  const shaSettings = jsonSettings.sha
  const settings = JSON.parse(Buffer.from(jsonSettings.content, 'base64').toString())

  if (!settings.apiSettings || !Array.isArray(settings.apiSettings.apikey)) throw 'Format settings.json tidak valid.'

  const index = settings.apiSettings.apikey.indexOf(lama)
  if (index === -1) throw `Apikey "${lama}" tidak ditemukan.`

  settings.apiSettings.apikey[index] = baru

  const encodedSettings = Buffer.from(JSON.stringify(settings, null, 2)).toString('base64')

  await fetch(settingsApiUrl, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json'
    },
    body: JSON.stringify({
      message: `Edit apikey: ${lama} → ${baru}`,
      content: encodedSettings,
      branch,
      sha: shaSettings
    })
  })

  m.reply(`✅ Apikey berhasil diubah:\n*${lama}* → *${baru}*`)
}

handler.command = ['editapikey']
handler.tags = ['owner']
handler.help = ['editapikey <lama>|<baru>']
handler.owner = true

export default handler