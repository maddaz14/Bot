// Dibuat oleh ubed - Plugin pencarian YouTube pakai yt-search
import ytSearch from 'yt-search'

let handler = async (m, { conn, text, command }) => {
  if (!text) {
    return m.reply(`❗ Masukkan kata kunci pencarian.\nContoh: .ytsearch armada asal kau bahagia`)
  }

  const res = await ytSearch(text)
  const videos = res.videos.slice(0, 10)

  if (!videos.length) {
    return m.reply('❌ Tidak ada hasil ditemukan.')
  }

  let rows = videos.map(video => ({
    header: `${video.author.name}`,
    title: video.title.length > 70 ? video.title.slice(0, 67) + '...' : video.title,
    description: `▶️ ${video.timestamp} | 👁️ ${video.views.toLocaleString()}\n🔗 ${video.url}`,
    id: `.yts2 ${video.url}`
  }))

  await conn.sendMessage(m.chat, {
    product: {
      productImage: { url: videos[0].thumbnail },
      productId: '9999999999999999',
      title: `Hasil: ${text}`,
      description: 'Pilih video YouTube dari hasil pencarian di bawah',
      currencyCode: 'IDR',
      priceAmount1000: '0',
      retailerId: 'ytsearch',
      url: videos[0].url,
      productImageCount: 1
    },
    businessOwnerJid: '6285147777105@s.whatsapp.net',
    caption: '🔍 *Hasil Pencarian YouTube*',
    title: 'Daftar Video',
    subtitle: 'Klik salah satu untuk mengunduh',
    footer: '> Nooriko Bot',
    interactiveButtons: [
      {
        name: 'single_select',
        buttonParamsJson: JSON.stringify({
          title: 'Pilih Video',
          sections: [
            {
              title: '🎬 Video Teratas',
              highlight_label: 'YouTube Result',
              rows
            }
          ]
        })
      }
    ],
    hasMediaAttachment: false
  }, { quoted: m })
}

handler.command = /^ytsearch|yts$/i
handler.tags = ['internet']
handler.help = ['ytsearch <kata kunci>']

export default handler