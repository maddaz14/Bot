let handler = async (m, { conn }) => {
  let meta = await conn.groupMetadata(m.chat)
  let ids = meta.participants.map(p => p.id)
  console.log('🟢 m.sender:', m.sender)
  console.log('🟢 participants:', ids)
  m.reply('Logged sender dan ID peserta.')
}
handler.command = /^debugid$/i
export default handler