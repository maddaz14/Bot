let handler = async (m, { conn }) => {
    let user = global.db.data.users[m.sender];
    let bot = global.db.data.settings[conn.user.jid];

    // Pengecekan premium pribadi
    if (!user.premiumTime || user.premiumTime < 1) {
        throw '❌ Kamu bukan pengguna premium.';
    }

    // Hitung sisa premium dalam milidetik
    const sisaPremium = user.premiumTime - Date.now();

    // Jika sisa premium kurang dari 2 hari (48 jam)
    if (sisaPremium < 2 * 24 * 60 * 60 * 1000) {
        throw `⏳ Premium kamu kurang dari 2 hari.\n\nSisa waktu premium: ${await time(sisaPremium)}\n\nFitur ini hanya bisa digunakan jika premium kamu lebih dari 2 hari.`;
    }

    if (!user.cheatTime) user.cheatTime = 0;
    if (Date.now() - user.cheatTime < 86400000) {
        throw `⏳ Tunggu dulu ya...\nGunakan lagi setelah: ${await time(user.cheatTime + 86400000 - Date.now())}`;
    }

    user.money = 999999999;
    user.limit = 999999999;
    user.exp = 999999999;
    user.cheatTime = Date.now();

    m.reply(`   [ *P R E M I U M* 👑 ]\n\n*Selamat Kamu Mendapatkan:*\n*Koin:* 999999999\n*Limit:* 999999999\n*Exp:* 999999999`);
};

handler.command = /^(cheat)$/i;
// Hapus baris ini agar handler utama tidak memeriksa status premium grup.
// handler.premium = true;
handler.cooldown = 1;
export default handler;

function time(ms) {
    if (ms < 0) ms = 0;
    let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000);
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24;
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
    return [d, ' *Hari* ', h, ' *Jam* ', m, ' *Menit* ', s, ' *Detik* '].map(v => v.toString().padStart(2, 0)).join('');
}