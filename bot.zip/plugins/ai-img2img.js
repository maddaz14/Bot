import axios from 'axios';
import FormData from 'form-data';
import { fileTypeFromBuffer } from 'file-type';

let handler = async (m, { conn, args }) => {
    try {
        if (m._img2img_done) return;
        m._img2img_done = true;

        let prompt = args.join(" ");
        if (!prompt) return m.reply("📌 Masukkan prompt!\n\nContoh:\n.img2img gaya anime");

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || q.mediaType || '';
        if (!mime || mime === 'conversation') return m.reply('📌 Reply/kirim gambar dengan caption prompt.\nContoh: .img2img gaya anime');

        let media = await q.download();
        let newUrl;

        // 🔥 Upload file persis seperti tourl
        try {
            const form = new FormData();
            form.append('file', media, {
                filename: `media.${(await fileTypeFromBuffer(media))?.ext || 'bin'}`,
                contentType: mime
            });

            const res = await axios.post('https://apiku.ubed.my.id/api/upload', form, {
                headers: form.getHeaders(),
                maxBodyLength: Infinity
            });

            if (res.data && res.data.url) {
                newUrl = res.data.url;
            } else if (typeof res.data === 'string' && res.data.startsWith('http')) {
                newUrl = res.data;
            } else {
                throw new Error('Respon dari API tidak valid.');
            }
        } catch (uploadError) {
            console.error('Gagal mengunggah ke API Anda:', uploadError);
            throw new Error('❌ Gagal mengunggah file ke server proxy.');
        }

        // 🔥 Panggil API img2img
        const apiUrl = `https://apiku.ubed.my.id/api/img2img?url=${encodeURIComponent(newUrl)}&prompt=${encodeURIComponent(prompt)}`;
        const result = await axios.get(apiUrl, { responseType: "arraybuffer" });

        await conn.sendMessage(
            m.chat,
            { image: Buffer.from(result.data), caption: "✅ Hasil img2img siap!" },
            { quoted: m }
        );

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('img2img error:', error);
        conn.sendMessage(m.chat, { text: `💥 Error: ${error.message || error}` }, { quoted: m });
    }
};

handler.help = ['img2img <prompt>'];
handler.tags = ['ai', 'image'];
handler.command = /^img2img$/i;

export default handler;