let handler = async (m, { conn, args, usedPrefix, command }) => {
    const sender = m.sender
    const pasangan = global.db.data.users[sender]?.pasangan
    const mentioned = m.mentionedJid[0]

    if (!pasangan) return m.reply('⚠️ Kamu belum menikah.')
    if (!mentioned) return m.reply(`⚠️ Tag pasanganmu.\n\nContoh:\n${usedPrefix}${command} iya @pasangan`)
    if (mentioned !== pasangan) return m.reply('⚠️ Yang kamu tag bukan pasanganmu.')

    let user = global.db.data.users[sender]
    let pasanganData = global.db.data.users[pasangan]

    if (!user.bikinAnakDitawari || user.bikinAnakDitawari !== pasangan)
        return m.reply('⚠️ Tidak ada permintaan bikin anak yang tertunda dari pasanganmu.')

    if ((user.anak?.length || 0) >= 2 || (pasanganData.anak?.length || 0) >= 2)
        return m.reply('⚠️ Salah satu dari kalian sudah memiliki maksimal 2 anak.')

    if (pasanganData.money < 5000000)
        return m.reply('⚠️ Pasanganmu tidak memiliki cukup uang (Rp 5 juta).')

    // Ambil calon anak random (level 2+)
    let semuaUser = Object.keys(global.db.data.users).filter(jid =>
        jid !== pasangan && jid !== sender && global.db.data.users[jid].level >= 2
    )

    if (!semuaUser.length) return m.reply('⚠️ Tidak ditemukan user yang cocok jadi anak.')

    let anakRandom = semuaUser[Math.floor(Math.random() * semuaUser.length)]

    pasanganData.money -= 5000000

    // Tambahkan anak
    pasanganData.anak = pasanganData.anak || []
    user.anak = user.anak || []
    pasanganData.anak.push(anakRandom)
    user.anak.push(anakRandom)

    await m.reply(`👶 *Selamat!*\nKamu dan *${conn.getName(pasangan)}* telah dikaruniai anak bernama *${conn.getName(anakRandom)}* (fiksi).`)

    await conn.sendMessage(pasangan, {
        text: `👶 *Selamat!*\nKamu dan *${conn.getName(sender)}* telah memiliki anak bernama *${conn.getName(anakRandom)}* (fiksi).\n\nGunakan *.keluarga* untuk melihat status keluargamu.`,
        mentions: [sender, anakRandom]
    })

    // Reset status
    delete user.bikinAnakDitawari
    delete pasanganData.bikinAnakPending
}

handler.help = ['buatanak iya @pasangan']
handler.tags = ['rpg']
handler.command = /^buatanak\s+i?ya$/i

export default handler