let handler = async (m, { conn }) => {
  // React emoji 🍏 saat mulai proses
  await conn.sendMessage(m.chat, {
    react: {
      text: '🍏',
      key: m.key
    }
  })

  const videos = [
{"url":"https://e.top4top.io/m_1930wespy0.mp4"},
{"url":"https://e.top4top.io/m_19303zfi20.mp4"},
{"url":"https://j.top4top.io/m_1930t00kx0.mp4"},
{"url":"https://e.top4top.io/m_1930kx7hi0.mp4"},
{"url":"https://c.top4top.io/m_19307g6kd0.mp4"},
{"url":"https://f.top4top.io/m_19306yk4c0.mp4"},
{"url":"https://i.top4top.io/m_1930y1u780.mp4"},
{"url":"https://j.top4top.io/m_1930ilsyy0.mp4"},
{"url":"https://i.top4top.io/m_19301948b0.mp4"},
{"url":"https://d.top4top.io/m_1930zg8460.mp4"},
{"url":"https://i.top4top.io/m_19301yozl0.mp4"},
{"url":"https://g.top4top.io/m_1930qjr2q0.mp4"},
{"url":"https://l.top4top.io/m_1930x1wp50.mp4"},
{"url":"https://a.top4top.io/m_1930zr1041.mp4"},
{"url":"https://b.top4top.io/m_1930s29hq2.mp4"},
{"url":"https://a.top4top.io/m_1930kbo0y0.mp4"},
{"url":"https://j.top4top.io/m_1930xek9z0.mp4"},
{"url":"https://i.top4top.io/m_1930s7gb80.mp4"},
{"url":"https://c.top4top.io/m_1930w0dbu0.mp4"},
{"url":"https://d.top4top.io/m_1930xu4kd1.mp4"},
{"url":"https://a.top4top.io/m_1930zw2nb0.mp4"},
{"url":"https://b.top4top.io/m_1930eybjj1.mp4"},
{"url":"https://g.top4top.io/m_1930fmx330.mp4"},
{"url":"https://l.top4top.io/m_1930gnlam0.mp4"},
{"url":"https://g.top4top.io/m_1930twwu50.mp4"},
{"url":"https://l.top4top.io/m_1930qkeh70.mp4"},
{"url":"https://l.top4top.io/m_1930wefm20.mp4"},
{"url":"https://a.top4top.io/m_1930idzd51.mp4"}
]

  let randomVideo = videos[Math.floor(Math.random() * videos.length)]

  await conn.sendMessage(m.chat, {
    video: { url: randomVideo.url },
    caption: '✅ Asupan santuy',
  }, { quoted: m })
}

handler.help = ['santuy']
handler.tags = ['asupan']
handler.command = /^santuy$/i

export default handler