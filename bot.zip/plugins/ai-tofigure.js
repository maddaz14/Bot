import axios from "axios";
import FormData from "form-data";
import sharp from "sharp"; // ✅ untuk convert ke PNG
import { fileTypeFromBuffer } from "file-type";

// 🔥 Scrape API Key dari overchat.ai
async function scrapeApiKey() {
  try {
    const targetUrl = "https://overchat.ai/image/ghibli";
    const { data: htmlContent } = await axios.get(targetUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    });

    const apiKeyRegex = /const apiKey = '([^']+)'/;
    const match = htmlContent.match(apiKeyRegex);

    if (match && match[1]) {
      return match[1];
    } else {
      throw new Error("❌ Gagal menemukan API Key di halaman web.");
    }
  } catch (err) {
    throw new Error(`❌ Scrape API Key gagal: ${err.message}`);
  }
}

// 🔥 Handler .tofigure (prompt bawaan)
let handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    // Prompt bawaan
    const prompt = `
Using the nano-banana model, a commercial 1/7 scale figurine of the character in the picture was created, depicting a realistic style and a realistic environment.
The figurine is placed on a computer desk with a round transparent acrylic base. There is no text on the base.
The computer screen shows the Zbrush modeling process of the figurine.
Next to the computer screen is a BANDAI-style toy box with the original painting printed on it.
-- Render the scene in LANDSCAPE orientation (16:9 aspect ratio), wide-angle composition
`;

    // --- cek apakah ada gambar ---
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";

    const apiKey = await scrapeApiKey();
    let buffer;

    if (mime && mime.startsWith("image/")) {
      // === MODE IMG2IMG ===
      let media = await q.download();
      if (!media) return m.reply("❌ Gagal mendownload media");

      // 🔥 pastikan konversi ke PNG
      let pngBuffer = await sharp(media).png().toBuffer();

      const apiUrl = "https://api.openai.com/v1/images/edits";
      const form = new FormData();
      form.append("image", pngBuffer, {
        filename: "input.png", // ✅ harus PNG
        contentType: "image/png",
      });
      form.append("prompt", prompt);
      form.append("model", "gpt-image-1");
      form.append("n", 1);
      form.append("size", "1024x1024"); // ✅ square wajib

      const response = await axios.post(apiUrl, form, {
        headers: {
          ...form.getHeaders(),
          Authorization: `Bearer ${apiKey}`,
        },
        responseType: "json",
      });

      const resultData = response.data;
      if (resultData?.data?.[0]?.b64_json) {
        buffer = Buffer.from(resultData.data[0].b64_json, "base64");
      } else {
        throw new Error("Respons API tidak valid (mode img2img).");
      }
    } else {
      // === MODE TEXT2IMG ===
      const apiUrl = "https://api.openai.com/v1/images/generations";
      const response = await axios.post(
        apiUrl,
        {
          prompt,
          model: "gpt-image-1",
          n: 1,
          size: "1024x1024", // ✅ square wajib
          quality: "high",
        },
        {
          headers: { Authorization: `Bearer ${apiKey}` },
        }
      );

      const resultData = response.data;
      if (resultData?.data?.[0]?.b64_json) {
        buffer = Buffer.from(resultData.data[0].b64_json, "base64");
      } else {
        throw new Error("Respons API tidak valid (mode text2img).");
      }
    }

    // === kirim hasil ke user ===
    await conn.sendMessage(
      m.chat,
      { image: buffer, mimetype: "image/png", caption: "✨ Figurine siap!" },
      { quoted: m }
    );

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (err) {
    console.error(err);
    m.reply(`💥 Error: ${err.message || err}`);
  }
};

handler.help = ["tofigure"];
handler.tags = ["ai", "image"];
handler.command = /^tofigure$/i;

export default handler;