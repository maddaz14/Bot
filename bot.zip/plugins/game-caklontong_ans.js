import similarity from 'similarity'

const threshold = 0.72

let handler = async (m, { conn, args }) => {
    conn.caklontong = conn.caklontong || {}
    const id = m.chat

    // Pastikan ada soal yang aktif
    if (!(id in conn.caklontong)) {
        return m.reply('Tidak ada soal Cak Lontong aktif di chat ini.')
    }

    // Pastikan jawaban diberikan
    if (!args[0]) {
        return m.reply('Masukkan jawaban!\nContoh: *.cak jawabanmu*')
    }

    const json = conn.caklontong[id][1]
    const poin = conn.caklontong[id][2]
    const jawaban = json.jawaban.trim().toLowerCase()
    const userJawab = args.join(' ').trim().toLowerCase()

    // Pastikan user ada di DB
    global.db.data.users[m.sender] = global.db.data.users[m.sender] || { exp: 0 }

    if (userJawab === jawaban) {
        // Jawaban benar
        global.db.data.users[m.sender].exp += poin
        await conn.sendFile(
            m.chat, 
            'https://telegra.ph/file/ab725c3de31e39bf3a08a.jpg', 
            'benar.jpg', 
            `*Benar!* +${poin} XP\n${json.deskripsi}`, 
            m
        )
        clearTimeout(conn.caklontong[id][3])
        delete conn.caklontong[id]
    } else if (similarity(userJawab, jawaban) >= threshold) {
        m.reply('*Dikit lagi!*')
    } else {
        m.reply('*Salah!*')
    }
}

handler.help = ['cak <jawaban>']
handler.tags = ['game']
handler.command = /^cak$/i

export default handler