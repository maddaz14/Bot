export async function before(m, {
    conn,
    participants
}) {
    const info = {
        // Ganti dengan daftar nomor owner kamu. Pisahkan dengan koma dan letakkan di dalam tanda kurung siku [].
        nomerown: ['6285147777105', '6285248500955', '6285147688631'] 
    };

    if (!conn.time_join) {
        conn.time_join = {
            join: false,
            time: 0,
        };
    }

    const currentTime = Math.floor(Date.now() / 1000);

    if (!m.isGroup || conn.time_join.time > currentTime) {
        console.log("Not a group message or still in cooldown");
        return;
    }

    const isCek = global.db.data.users[m.sender];
    let messageText = "";
    
    // Mengecek apakah nomor pengirim ada di dalam array nomerown.
    const isHardcodedOwner = info.nomerown.includes(m.sender.split('@')[0]);

    if (isHardcodedOwner) {
        // Pesan sambutan untuk owner yang hardcoded di dalam kode
        messageText = "📣 *Perhatian semua, Ownerku ubed telah tiba disini* ";
    } else if (isCek?.owner) {
        // Pesan sambutan untuk owner yang terdaftar di database
        messageText = "Selamat datang, Owner !";
    } else if (isCek?.premium) {
        // Pesan sambutan untuk pengguna premium
        messageText = "Hai king!";
    }

    if (messageText) {
        await conn.sendMessage(
            m.chat, {
                text: messageText,
            }, {
                quoted: m
            }
        );

        conn.time_join = {
            join: true,
            time: currentTime + 2400,
        };
    } else {
        console.log("No message to send");
    }
}