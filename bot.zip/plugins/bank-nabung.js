const fkontak = {
    key: {
        participant: '0@s.whatsapp.net',
        remoteJid: '0@s.whatsapp.net',
        fromMe: false,
        id: 'Halo',
    },
    message: {
        conversation: `nabung ${global.namebot || 'Bot'} ✨`,
    },
};

const xpperlimit = 1;

let handler = async (m, { conn, command, args }) => {
    let user = global.db.data.users[m.sender];

    let input = args[0]?.toLowerCase();
    let count = (input === 'all')
        ? Math.floor(user.money / xpperlimit)
        : parseInt(input) || 1;

    count = Math.max(1, count);

    if (isNaN(count)) return conn.reply(m.chat, `Masukkan jumlah yang valid untuk ditabung.`, fkontak);

    if (user.money >= xpperlimit * count) {
        user.money -= xpperlimit * count;
        user.bank += count;

        conn.reply(m.chat, `✅ Sukses menabung Rp ${count.toLocaleString()} 💸`, fkontak);
    } else {
        conn.reply(m.chat, `❌ Uang kamu tidak cukup untuk menabung Rp ${count.toLocaleString()}.`, fkontak);
    }
};

handler.help = ['nabung <jumlah/all>', 'atm'];
handler.tags = ['rpg'];
handler.command = /^(nabung|atm)(all|\d+)?$/i;
handler.register = true;

export default handler;