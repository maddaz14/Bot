import fs from "fs"
import { execSync } from "child_process"

let handler = async (m, { conn }) => {
  try {
    const tempDir = "./tmp"
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

    // Bersihkan folder tmp
    let files = fs.readdirSync(tempDir)
    for (let file of files) {
      fs.unlinkSync(`${tempDir}/${file}`)
    }

    await m.reply("*🍏 Wait proses backup.....*")

    const backupName = "fuxxymd"
    const backupPath = `${tempDir}/${backupName}.zip`

    // File atau folder yang tidak ingin dibackup
    const excludedDirsAndFiles = ["node_modules", "sessions", "package-lock.json", "yarn.lock"]
    const excludedPlugins = [
      "plugins/tools-cekkey.js",
      "plugins/owner-addbuyer.js",
      "plugins/owner-editkey.js",
      "plugins/owner-spgithub.js"
    ]

    // Ambil semua file/folder utama yang boleh dibackup
    const list = (await execSync("ls")).toString().split("\n").filter(pe => pe && !excludedDirsAndFiles.includes(pe))

    // Pastikan .env selalu termasuk dalam backup
    if (!list.includes(".env")) {
      list.push(".env")
    }

    // Bangun argumen pengecualian untuk zip
    const excludeFlags = excludedPlugins.map(f => `-x "${f}"`).join(" ")

    // Proses zip
    await execSync(`zip -r ${backupPath} ${list.join(" ")} ${excludeFlags}`)

    // Kirim file ke PM
    await conn.sendMessage(m.sender, {
      document: fs.readFileSync(backupPath),
      fileName: `${backupName}.zip`,
      mimetype: "application/zip"
    }, { quoted: m })

    fs.unlinkSync(backupPath)
    m.reply("*Script bot berhasil dikirim ke private chat!*")
  } catch (e) {
    console.error("Error terjadi:", e)
    m.reply("❌ *Gagal membuat backup script!*")
  }
}

handler.help = ["backup"]
handler.tags = ["owner"]
handler.command = /^(backup|bk)$/i
handler.mods = true

export default handler