let handler = async (m, { conn }) => {
    const text = m.text?.toLowerCase() || "";

    // Tidak perlu kondisi jika tidak ada logika tambahan
    await conn.sendMessage(m.chat, {
        audio: { url: 'https://files.catbox.moe/g3cvhp.opus' },
        mimetype: 'audio/mp4',
        ptt: true
    }, { quoted: m });
};

handler.command = ['desah'];

export default handler;