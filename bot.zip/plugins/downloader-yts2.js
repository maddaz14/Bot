// Dibuat oleh ubed - Pilihan format YouTube
let handler = async (m, { conn, args, command }) => {
  const url = args[0]
  const isYT = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\//i.test(url)

  if (!url || !isYT) {
    return m.reply('❗ Masukkan link YouTube yang valid!\nContoh: .yt https://youtube.com/watch?v=xxxxx')
  }

  const fkontak = {
    key: { participant: '0@s.whatsapp.net', remoteJid: 'status@broadcast' },
    message: {
      contactMessage: {
        displayName: 'YOUTUBE',
        vcard: 'BEGIN:VCARD\nVERSION:3.0\nN:YT;;;\nFN:YT\nEND:VCARD'
      }
    }
  }

  const buttons = [
    { buttonId: `.ytmp3 ${url}`, buttonText: { displayText: '🎵 Download MP3' }, type: 1 },
    { buttonId: `.ytmp4 ${url}`, buttonText: { displayText: '🎥 Download MP4' }, type: 1 }
  ]

  await conn.sendMessage(m.chat, {
    text: `📥 Silakan pilih format yang ingin diunduh untuk:\n${url}`,
    footer: 'Nooriko Bot',
    buttons,
    headerType: 1
  }, { quoted: fkontak })
}

handler.command = /^yts2$/i
handler.tags = ['downloader']
handler.help = ['yts2 <url>']

export default handler