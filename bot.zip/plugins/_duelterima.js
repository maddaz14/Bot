const handler = async (m, { conn }) => {
  conn.duel = conn.duel || []
  const duel = conn.duel.find(d => d.opponent === m.sender)
  if (!duel) return m.reply('Tidak ada tantangan untuk kamu.')

  const user = global.db.data.users[duel.challenger]
  const enemy = global.db.data.users[duel.opponent]
  user.lastduel = Date.now()

  const Aku = Math.floor(Math.random() * 101)
  const Kamu = Math.floor(Math.random() * 81)

  let result
  if (Aku > Kamu) {
    user.money -= 900
    enemy.money += 900
    result = `@${duel.challenger.split('@')[0]} MENANG duel! 🎉 (+900 money)`
  } else if (Aku < Kamu) {
    user.money += 450
    enemy.money -= 450
    result = `@${duel.opponent.split('@')[0]} MENANG duel! 🎉 (+450 money)`
  } else {
    user.money += 250
    enemy.money += 250
    result = `Duel SERI! Keduanya dapat +250 money.`
  }

  await conn.sendMessage(m.chat, { text: result, mentions: [duel.challenger, duel.opponent] }, { quoted: m })
  conn.duel = conn.duel.filter(d => d !== duel)
}

handler.command = /^duelterima$/i
handler.group = true

export default handler