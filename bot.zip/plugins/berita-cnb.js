import axios from 'axios';

const handler = async (m, { conn }) => {
  try {
    const res = await axios.get('https://api.siputzx.my.id/api/berita/cnn');
    const json = res.data;

    if (!json.status || !json.data || !json.data.length) {
      return m.reply('❌ Tidak ada berita tersedia.');
    }

    // Reaksi
    await conn.sendMessage(m.chat, { react: { text: '🗞️', key: m.key } });

    const beritaList = json.data.slice(0, 5);
    for (const item of beritaList) {
      await conn.sendMessage(m.chat, {
        image: { url: item.image_full || item.image_thumbnail },
        caption: `📰 *${item.title}*\n\n🕒 *Waktu:* ${item.time}`,
        footer: 'Klik tombol di bawah untuk membaca lebih lanjut.',
        templateButtons: [
          {
            index: 1,
            urlButton: {
              displayText: '🌐 Baca Selengkapnya',
              url: item.link
            }
          }
        ]
      }, { quoted: m });
    }

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (e) {
    console.error(e);
    m.reply('❌ Gagal mengambil berita dari CNN.');
  }
};

handler.command = /^beritacnn$/i;
handler.tags = ['news'];
handler.help = ['beritacnn'];
handler.limit = true;

export default handler;