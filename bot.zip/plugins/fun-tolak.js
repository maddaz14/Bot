import { areJidsSameUser } from '@fuxxy-star/baileys'

let handler = async (m, { conn, text, participants }) => {
  let number, user

  if (isNaN(text)) {
    number = text.split`@`[1]
  } else if (!isNaN(text)) {
    number = text
  }

  if (!text && !m.quoted) 
    return conn.reply(m.chat, `Masukan nomor, tag atau balas pesan target.`, m)

  if (isNaN(number)) 
    return conn.reply(m.chat, `Nomor yang anda masukan salah!`, m)

  if (number.length > 15) 
    return conn.reply(m.chat, `Format salah!`, m)

  try {
    if (text) {
      user = number + '@s.whatsapp.net'
    } else if (m.quoted?.sender) {
      user = m.quoted.sender
    } else if (m.mentionedJid?.length) {
      user = m.mentionedJid[0]
    }
  } catch (e) {
    console.error(e)
  } finally {
    let users = m.isGroup ? participants.find(v => areJidsSameUser(v.id, user)) : {}

    if (!users) 
      return conn.reply(m.chat, `Target atau Nomor tidak ditemukan, mungkin sudah keluar atau bukan anggota grup ini.`, m)

    if (user === m.sender) 
      return conn.reply(m.chat, `Tidak bisa berpacaran dengan diri sendiri!`, m)

    if (user === conn.user.id) 
      return conn.reply(m.chat, `Tidak bisa berpacaran dengan saya t_t`, m)

    if (global.db.data.users[user]?.pasangan !== m.sender) {
      conn.reply(m.chat, `Maaf @${user.split('@')[0]} tidak sedang menembak anda`, m, {
        contextInfo: { mentionedJid: [user] }
      })
    } else {
      global.db.data.users[user].pasangan = ""
      conn.reply(m.chat, `Anda baru saja menolak @${user.split('@')[0]} untuk menjadi pasangan anda!`, m, {
        contextInfo: { mentionedJid: [user] }
      })
    }
  }
}

handler.help = ['tolak *@tag*']
handler.tags = ['fun', 'jadian']
handler.command = /^(tolak)$/i
handler.group = true

export default handler