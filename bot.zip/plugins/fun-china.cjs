const axios = require('axios'); // Impor axios untuk mengambil data dari URL

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        // Mengambil data JSON menggunakan axios
        let response = await axios.get(`https://github.com/ArifzynXD/database/raw/master/asupan/${command}.json`);
        let data = response.data;

        if (!data || data.length === 0) {
            return m.reply("Gambar tidak ditemukan.");
        }

        // Memilih URL gambar secara acak dari array
        let randomImageUrl = data[Math.floor(Math.random() * data.length)].url;

        // Mengirim gambar sebagai respons
        await conn.sendFile(m.chat, randomImageUrl, "china.jpg", null, m);

    } catch (error) {
        console.error("Error fetching image:", error);
        m.reply("Terjadi kesalahan saat mengambil gambar. Silakan coba lagi nanti.");
    }
};

handler.help = ["china"].map((a) => a + " *[Random image]*");
handler.tags = ["fun"];
handler.command = ["china"];
module.exports = handler;