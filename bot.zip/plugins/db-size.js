import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, usedPrefix, command }) => {
  // Path ke database.json (ubah sesuai lokasi sebenarnya jika perlu)
  const dbPath = path.join('./database.json')

  try {
    if (!fs.existsSync(dbPath)) return m.reply('❌ File database.json tidak ditemukan.')

    const stats = fs.statSync(dbPath)
    const sizeInBytes = stats.size
    const sizeInKB = (sizeInBytes / 1024).toFixed(2)
    const sizeInMB = (sizeInBytes / (1024 * 1024)).toFixed(2)

    m.reply(
      `📦 *Ukuran Database Saat Ini*\n\n` +
      `🗂️ Ukuran dalam Byte: *${sizeInBytes} B*\n` +
      `📁 Ukuran dalam KB: *${sizeInKB} KB*\n` +
      `💾 Ukuran dalam MB: *${sizeInMB} MB*`
    )
  } catch (err) {
    console.error(err)
    m.reply('⚠️ Gagal membaca ukuran database.')
  }
}

handler.help = ['cekdbsize']
handler.tags = ['info']
handler.command = /^cekdb(size|ukuran)$/i
handler.owner = true // hanya owner yang bisa

export default handler