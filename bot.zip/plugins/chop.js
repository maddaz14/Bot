let handler = async (m, { conn, usedPrefix, DevMode }) => { 
    try { 
        let __timers = (new Date - global.db.data.users[m.sender].lastmining)
        let _timers = (180000 - __timers) 
        let timers = clockString(_timers)
        
        // Periksa kesehatan minimal 80
        if (global.db.data.users[m.sender].healt > 79) {
            if (__timers > 180000) {
                let user = global.db.data.users[m.sender]

                // Data armor dan hewan peliharaan
                const bonusMap = { 0:0, 1:5, 2:10, 3:15, 4:21, 5:30 }
                let armor = user.armor
                let kucing = user.kucing
                
                // Hitung bonus dari kucing dan armor
                let kucingnya = bonusMap[kucing] || 0
                let armornya = bonusMap[armor] || 0
                
                // Hitung health random dan adjust jika > 60
                let rawHealth = Math.floor(Math.random() * 101)
                let adjustedHealth = rawHealth > 60 ? rawHealth - kucingnya - armornya : rawHealth
                let health = (kucing === 0 && armor === 0) 
                    ? pickRandom(['100','99','98','97','96','95','94','93','92','91','90'])
                    : (kucing > 0 && armor > 0) 
                        ? adjustedHealth 
                        : rawHealth
                
                // Random hadiah lain
                let potion = Math.floor(Math.random() * 2)
                let common = Math.floor(Math.random() * 3)
                let uncommon = Math.floor(Math.random() * 2)
                let mythic = Number(pickRandom(['1', '0', '0', '1']))
                let legendary = Number(pickRandom(['1', '0', '0', '0']))
                let sampah = Math.floor(Math.random() * 300)
                let diamond = Math.floor(Math.random() * 10)
                let kayu = Math.floor(Math.random() * 150)
                let batu = Math.floor(Math.random() * 100)
                let iron = Math.floor(Math.random() * 100)

                // EXP maksimal 6000
                let exp = Math.floor(Math.random() * 6001)
                let uang = Math.floor(Math.random() * 500)
                
                // Kirim pesan hasil
                let str = `
❤️ Saat kamu memotong, kamu mendapatkan:
🪵 Kayu: ${kayu}
🔩 Besi: ${iron}
💵 Emas: ${uang}
⚜️ Exp: ${exp}
dan kamu mendapatkan hadiah tambahan:
💎 Berlian: ${diamond}
`.trim()
                
                await conn.reply(m.chat, '↓Pemotongan:', m)
                await conn.reply(m.chat, str, m)
                
                // Update data user
                user.kayu += kayu
                user.diamond += diamond
                user.batu += batu
                user.iron += iron
                user.exp += exp
                user.money += uang
                user.lastmining = new Date * 1
            } else {
                conn.reply(m.chat, `Tunggu ${timers} lagi`, m)
            }
        } else {
            conn.reply(m.chat, 'Kesehatan minimal 80 untuk melakukan pemotongan', m)
        }
    } catch (e) {
        console.log(e)
        conn.reply(m.chat, 'Error', m)
        if (DevMode) {
            let file = require.resolve(__filename)
            for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').filter(v => v != conn.user.jid)) {
                conn.reply(jid, file + ' error\nNo: *' + m.sender.split`@`[0] + '*\nCommand: *' + m.text + '*\n\n*' + e + '*', m)
            }
        }
    }
}

handler.help = ['chop', 'choping']
handler.tags = ['rpg']
handler.command = /^(chop|choping)$/i

export default handler

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

function clockString(ms) {
    let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return ['\n' + d, ' *Hari ☀️*\n ', h, ' *Jam 🕐*\n ', m, ' *Menit ⏰*\n ', s, ' *Detik ⏱️* '].map(v => v.toString().padStart(2, 0)).join('')
}