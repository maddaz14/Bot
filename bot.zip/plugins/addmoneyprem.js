import { areJidsSameUser } from '@fuxxy-star/baileys';

let handler = async (m, { conn, command, args, participants }) => {
    // --- Fungsi untuk meresolve JID @lid ke JID standar ---
    async function resolveAndCleanJid(inputJid, conn, groupParticipants = []) {
        if (inputJid.endsWith('@s.whatsapp.net')) {
            return inputJid;
        }

        if (inputJid.endsWith('@lid')) {
            let resolved = groupParticipants.find(p => areJidsSameUser(p.id, inputJid) || areJidsSameUser(p.jid, inputJid));
            if (resolved?.jid?.endsWith('@s.whatsapp.net')) {
                return resolved.jid;
            }

            try {
                const [res] = await conn.onWhatsApp(inputJid);
                if (res?.exists) {
                    return res.jid;
                }
            } catch (e) {}
        }
        return inputJid;
    }
    // --- Akhir fungsi helper ---

    let senderJid = m.sender;
    if (m.isGroup && senderJid.endsWith('@lid')) {
        let groupParticipants = participants;
        if (!groupParticipants || groupParticipants.length === 0) {
            const metadata = await conn.groupMetadata(m.chat).catch(() => null);
            if (metadata) {
                groupParticipants = metadata.participants;
            }
        }
        senderJid = await resolveAndCleanJid(m.sender, conn, groupParticipants);
    }

    if (!senderJid || !senderJid.endsWith('@s.whatsapp.net')) {
        throw 'Gagal mendapatkan ID WhatsApp Anda yang valid. Silakan coba lagi.';
    }

    let user = global.db.data.users[senderJid];

    // Pengecekan status premium individu
    if (!user || !user.premium) {
        throw 'Fitur ini hanya dapat digunakan oleh pengguna *Premium*!';
    }
    
    // Batas 2x per hari
    const now = new Date();
    const today = now.toDateString();

    if (!user.last_addmoney || user.last_addmoney !== today) {
        user.last_addmoney = today;
        user.addmoney_count = 0;
    }

    if (user.addmoney_count >= 2) {
        throw 'Kamu sudah mencapai batas *2x penggunaan addmoney hari ini*. Coba lagi besok.';
    }

    let jumlah = args[0] ? parseInt(args[0]) : 1000;
    if (isNaN(jumlah)) throw 'Jumlah money tidak valid!';
    if (jumlah <= 0) throw 'Jumlah harus lebih dari 0!';

    let batasMax = 5_000_000_000;
    if (user.money >= batasMax) {
        throw 'Kamu sudah mencapai batas maksimal money (5.000.000.000), tidak bisa menambah lagi.';
    }
    
    if (user.money + jumlah > batasMax) {
        jumlah = batasMax - user.money;
    }

    user.money += jumlah;
    user.addmoney_count += 1;

    conn.reply(
        m.chat,
        `Berhasil menambahkan *${jumlah.toLocaleString()}* money ke akunmu. Total sekarang: *${user.money.toLocaleString()}*.\n\nSisa penggunaan hari ini: *${2 - user.addmoney_count}x*`,
        m
    );
};

handler.help = ['addmoneyprem'];
handler.tags = ['premium'];
handler.command = /^addmoneyprem$/i;

export default handler;