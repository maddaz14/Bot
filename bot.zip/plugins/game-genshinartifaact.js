import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text) {
    try {
      const list = await genshindb.artifacts("names", { matchCategories: true });
      return m.reply(`📜 *Daftar Artefak Tersedia:*\n\n${list.join(", ")}`);
    } catch (e) {
      console.error('[ARTIFACT LIST ERROR]', e);
      return m.reply('❌ Gagal mengambil daftar artefak.');
    }
  }

  try {
    const result = await genshindb.artifacts(text);
    if (result) {
      let response = `🧿 *Artefak Ditemukan: ${result.name}*\n\n`;
      response += `📝 _${result.description || "Deskripsi tidak tersedia"}_\n\n`;
      response += `📦 *Set:* ${result.set || "Tidak diketahui"}\n`;
      response += `🎖️ *Rarity:* ${Array.isArray(result.rarity) ? result.rarity.join("★, ") + "★" : result.rarity + "★"}\n`;
      response += `🎯 *Slot:* ${result.slot || "Tidak diketahui"}`;
      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[ARTIFACT ERROR]', err);
    try {
      const available = await genshindb.artifacts("names", { matchCategories: true });
      return m.reply(`❌ Artefak '${text}' tidak ditemukan.\n\n📜 *Artefak yang tersedia:*\n${available.join(", ")}`);
    } catch (e) {
      return m.reply('⚠️ Gagal menampilkan daftar artefak.');
    }
  }
};

handler.help = ['genshin-artifact <nama artefak>'];
handler.tags = ['game'];
handler.command = /^(genshin-artifaact|g-artifact|gens-artifact)$/i;
handler.limit = 1;
handler.register = true;

export default handler;