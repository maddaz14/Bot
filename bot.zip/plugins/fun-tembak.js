import { jidNormalizedUser } from '@fuxxy-star/baileys'

let toM = a => '@' + a.split('@')[0]

let handler = async (m, { conn, usedPrefix, text, participants, groupMetadata }) => {
    if (!text) {
        let ps = groupMetadata.participants.map(v => v.id)
        let a = ps.getRandom()
        let b
        do b = ps.getRandom()
        while (b === a)
        let caption = `*Love Message...* ${toM(a)} ❤️ ${toM(b)}\n${ktnmbk.getRandom()}`
        await conn.sendButton(m.chat, caption, wm, null, [
            ['💘 Jodohnya', `${usedPrefix}jodohnya`],
            ['💌 Jodohku', `${usedPrefix}jodohku`]
        ], m, { mentions: conn.parseMention(caption) })
        return
    }

    let number
    if (isNaN(text)) {
        number = text.split`@`[1]
    } else if (!isNaN(text)) {
        number = text
    }

    if (!text && !m.quoted) return conn.reply(m.chat, `Ketik nomor, tag user, atau reply pesan target`, m)
    if (isNaN(number)) return conn.reply(m.chat, `❌ Nomor tidak valid.`, m)
    if (number.length > 15) return conn.reply(m.chat, `❌ Format nomor tidak valid.`, m)

    let user
    try {
        if (text) {
            user = number + '@s.whatsapp.net'
        } else if (m.quoted.sender) {
            user = m.quoted.sender
        } else if (m.mentionedJid[0]) {
            user = m.mentionedJid[0]
        }
    } catch (e) { }

    if (!user) return conn.reply(m.chat, `❌ Tidak bisa menemukan target.`, m)

    // cek apakah target ada di grup
    let users = m.isGroup ? participants.find(v => jidNormalizedUser(v.id) === jidNormalizedUser(user)) : {}
    if (!users) return conn.reply(m.chat, `❌ Target tidak ditemukan di grup ini.`, m)

    if (user === m.sender) return conn.reply(m.chat, `❌ Tidak bisa nembak diri sendiri.`, m)
    if (user === conn.user.jid) return conn.reply(m.chat, `❌ Tidak bisa nembak saya 🤖`, m)

    if (typeof global.db.data.users[user] == "undefined") return m.reply(`❌ User yang ditag belum terdaftar di database.`)

    let pacar = global.db.data.users[user].pasangan
    let spac = global.db.data.users[m.sender].pasangan

    // Sudah punya pasangan
    if (spac && global.db.data.users[spac]?.pasangan === m.sender && spac !== user) {
        return conn.reply(m.chat, 
            `Kamu sudah berpacaran dengan @${spac.split('@')[0]}\n\nKetik *.putus* dulu untuk putus sebelum menembak @${user.split('@')[0]}`, 
            m, { mentions: [user, spac] })
    } else if (pacar && pacar !== m.sender) {
        return conn.reply(m.chat, 
            `Maaf, @${user.split('@')[0]} sudah berpacaran dengan @${pacar.split('@')[0]}.\nSilakan cari pasangan lain.`, 
            m, { mentions: [user, pacar] })
    }

    // Jika sudah saling jadian
    if (pacar === m.sender && spac === user) {
        return conn.reply(m.chat, 
            `❤️ Selamat! Kamu sudah resmi berpacaran dengan @${user.split('@')[0]}`, 
            m, { mentions: [user] })
    }

    // Jika belum ada pasangan, ajak pacaran
    global.db.data.users[m.sender].pasangan = user
    conn.reply(m.chat, 
        `${ktnmbk.getRandom()}\n\n💘 Kamu baru saja mengajak @${user.split('@')[0]} berpacaran.\n\nKetik *${usedPrefix}terima @user* untuk menerima.\nKetik *${usedPrefix}tolak @user* untuk menolak.`, 
        m, { mentions: [user] })
}

handler.help = ['tembak *@user*']
handler.tags = ['fun', 'jadian']
handler.command = /^(tembak|jadian)$/i
handler.group = true

export default handler

// Array kata-kata nembak
let ktnmbk = [
  "Aku baru sadar ternyata selama ini kamu kaya! Kaya yang aku cari selama ini. Kamu mau nggak jadi pacarku?",
  "Aku ingin bilang sesuatu. Udah lama aku suka sama kamu, tapi aku nggak berani ngomong. Jadi, aku putuskan untuk WA saja. Mau nggak kamu jadi pacarku?",
  "Aku ingin mengungkapkan sebuah hal yang tak sanggup lagi aku pendam lebih lama. Aku mencintaimu, maukah kamu menjadi pacarku?",
  "Aku siapkan mental untuk hari ini. Kamu harus menjadi pacarku untuk mengobati rasa cinta yang sudah tak terkendali ini.",
  "Izinkan aku mengatakan sesuatu yang menurutku sangat penting. Hey, kau punya tempat di hatiku yang tidak bisa dimiliki oleh orang lain. Tetaplah di sana dan jadilah kekasihku. Mau?",
  "Bahagia itu kalau aku dan kamu telah menjadi kita.",
  "Hidupku indah karena kamu bersamaku, kamu membuatku bahagia bahkan jika aku merasa sedih. Senyummu menerangi hidupku. Maukah kamu menjadi milikku?",
  "Aku tahu kita sudah lama sahabatan. Tapi nggak salah kan kalau aku suka sama kamu? Apa pun jawaban kamu aku terima."
]