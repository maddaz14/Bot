// Dibuat oleh UBED - Nooriko Bot - Scrape YTMP3 Tanpa API

const yts = require('yt-search')
const axios = require('axios')
const cheerio = require('cheerio')

// Pesan acak untuk fkontak
const randomConversations = [
  "Download lagu langsung dari YouTube! 🎶",
  "Nooriko Bot siap temani harimu dengan musik 📀",
  "Udah siap dengerin lagu favoritmu? 😎",
  "Musik pilihanmu siap diputar 🍃",
]

const getRandomText = () =>
  randomConversations[Math.floor(Math.random() * randomConversations.length)]

function extractVideoId(url) {
  const match = url.match(/(?:v=|\/)([0-9A-Za-z_-]{11})/)
  return match ? match[1] : null
}

async function ytmp3(url) {
  if (!url) throw 'Masukkan URL YouTube!'
  const videoId = extractVideoId(url)
  const thumbnail = videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null

  try {
    const form = new URLSearchParams()
    form.append('q', url)
    form.append('type', 'mp3')

    const res = await axios.post('https://yt1s.click/search', form.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': 'https://yt1s.click',
        'Referer': 'https://yt1s.click/',
        'User-Agent': 'Mozilla/5.0',
      },
    })

    const $ = cheerio.load(res.data)
    const link = $('a[href*="download"]').attr('href')

    if (link) {
      return {
        link,
        title: $('title').text().trim() || 'Unknown Title',
        thumbnail,
        filesize: null,
        duration: null,
        success: true,
      }
    }
  } catch (e) {
    console.warn('Gagal YT1S:', e.message || e.toString())
  }

  try {
    if (!videoId) throw 'Video ID tidak valid'
    const payload = { fileType: 'MP3', id: videoId }

    const res = await axios.post('https://ht.flvto.online/converter', payload, {
      headers: {
        'Content-Type': 'application/json',
        'Origin': 'https://ht.flvto.online',
        'Referer': `https://ht.flvto.online/widget?url=https://www.youtube.com/watch?v=${videoId}`,
        'User-Agent': 'Mozilla/5.0',
      },
    })

    const data = res?.data
    if (!data || typeof data !== 'object') throw 'Tidak ada respon dari FLVTO'
    if (data.status !== 'ok' || !data.link) throw `Status gagal: ${data.msg || 'Tidak diketahui'}`

    return {
      link: data.link,
      title: data.title,
      thumbnail,
      filesize: data.filesize,
      duration: data.duration,
      success: true,
    }
  } catch (e) {
    console.warn('Gagal FLVTO:', e.message || e.toString())
  }

  throw 'Gagal mendapatkan link download.'
}

let handler = async (m, { conn, command, text, usedPrefix }) => {
  const fkontak = {
    key: {
      participant: '0@s.whatsapp.net',
      remoteJid: '0@s.whatsapp.net',
      fromMe: false,
      id: 'Halo',
    },
    message: {
      conversation: getRandomText(),
    },
  }

  if (!text) {
    return conn.reply(
      m.chat,
      `🎵 Hai Kak! Mau cari lagu apa hari ini?\n\nContoh: *${usedPrefix}${command} blue bird naruto*`,
      m,
      { quoted: fkontak }
    )
  }

  await conn.sendMessage(m.chat, {
    react: { text: '🎶', key: m.key },
  })

  try {
    const search = await yts(text)
    if (!search.videos.length) throw '❌ Lagu tidak ditemukan di YouTube.'

    const top10Videos = search.videos.slice(0, 10)
    const firstVideo = search.videos[0]

    // --- Bagian 1: Menampilkan Pesan Interaktif (10 Hasil) ---

    const rows = top10Videos.map((video, index) => {
      const duration = video.timestamp || '00:00'
      const description = `Durasi: ${duration} | Ditonton: ${video.views.toLocaleString()} kali`
      
      return {
        header: `${index + 1}. ${video.title}`,
        title: video.title,
        description: description,
        id: `.ytmp3 ${video.url}` // ID yang akan dijalankan bot jika dipilih
      }
    })

    const thumbnailUrl = firstVideo.thumbnail

    await conn.sendMessage(m.chat, {
      product: {
        productImage: { url: thumbnailUrl },
        productId: '9999999999999999',
        title: 'Hasil Pencarian YouTube',
        description: 'Pilih musik yang ingin Anda unduh',
        currencyCode: 'IDR',
        priceAmount1000: '0',
        retailerId: 'ytsearch',
        url: 'https://wa.me/6285147777105', 
        productImageCount: 1
      },
      businessOwnerJid: '6285147777105@s.whatsapp.net',
      caption: `🧠 *Hasil pencarian untuk:* ${text}\n\n*Silakan pilih dari daftar di bawah ini!*`,
      title: 'Daftar Lagu',
      subtitle: 'Klik tombol di bawah',
      footer: '> Nooriko Bot',
      interactiveButtons: [
        {
          name: 'single_select',
          buttonParamsJson: JSON.stringify({
            title: 'Pilih Musik',
            sections: [
              {
                title: 'Hasil Pencarian',
                highlight_label: 'Pilih Salah Satu',
                rows
              }
            ]
          })
        }
      ],
      hasMediaAttachment: false
    }, { /* Opsi quoted: m dihapus untuk menghindari duplikasi */ }) 

    // --- Bagian 2: Langsung Mengunduh dan Mengirim Hasil Pertama (Audio Saja) ---

    const result = await ytmp3(firstVideo.url)

    if (!result?.link) throw 'Gagal mengambil audio dari YouTube'

    const audio = await axios
      .get(result.link, { responseType: 'arraybuffer' })
      .then(res => res.data)

    await conn.sendMessage(
      m.chat,
      {
        audio: Buffer.from(audio),
        mimetype: 'audio/mpeg',
        fileName: `${result.title}.mp3`,
        ptt: true,
        caption: '✅ *Berhasil mengunduh lagu!*',
      },
      { quoted: fkontak }
    )

    await conn.sendMessage(m.chat, {
      react: { text: '✅', key: m.key },
    })

  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key },
    })
    throw `❌ Gagal mengambil audio YouTube.\n\nLog: ${e.message || e}`
  }
}

handler.help = ['play2', 'musik2', 'lagu2', 'song2'].map(v => v + ' <judul>')
handler.tags = ['downloader']
handler.command = /^(play2|musik2|lagu2|song2)$/i
handler.limit = true
handler.premium = false
handler.register = true

module.exports = handler