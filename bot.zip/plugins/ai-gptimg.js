import axios from "axios";
import FormData from "form-data";
import { fileTypeFromBuffer } from "file-type";

// 🔥 Scrape API Key dari overchat.ai
async function scrapeApiKey() {
  try {
    const targetUrl = "https://overchat.ai/image/ghibli";
    const { data: htmlContent } = await axios.get(targetUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    });

    const apiKeyRegex = /const apiKey = '([^']+)'/;
    const match = htmlContent.match(apiKeyRegex);

    if (match && match[1]) {
      return match[1];
    } else {
      throw new Error("❌ Gagal menemukan API Key di halaman web.");
    }
  } catch (err) {
    throw new Error(`❌ Scrape API Key gagal: ${err.message}`);
  }
}

// 🔥 Plugin handler .gptimage / .gptimg
let handler = async (m, { conn, args }) => {
  try {
    let prompt = args.join(" ");
    if (!prompt) return m.reply("📌 Contoh:\n.gptimg kucing terbang di langit malam gaya Ghibli");

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    // --- cek apakah ada gambar ---
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";

    const apiKey = await scrapeApiKey();
    let buffer;

    if (mime && mime.startsWith("image/")) {
      // === MODE IMG2IMG ===
      let media = await q.download();
      if (!media) return m.reply("❌ Gagal mendownload media");

      const ext = (await fileTypeFromBuffer(media))?.ext || "png";

      const apiUrl = "https://api.openai.com/v1/images/edits";
      const form = new FormData();
      form.append("image", media, {
        filename: `file.${ext}`,
        contentType: mime,
      });
      form.append("prompt", prompt);
      form.append("model", "gpt-image-1");
      form.append("n", 1);
      form.append("size", "1024x1024");
      form.append("quality", "high");

      const response = await axios.post(apiUrl, form, {
        headers: {
          ...form.getHeaders(),
          Authorization: `Bearer ${apiKey}`,
        },
        responseType: "json",
      });

      const resultData = response.data;
      if (resultData?.data?.[0]?.b64_json) {
        buffer = Buffer.from(resultData.data[0].b64_json, "base64");
      } else {
        throw new Error("Respons API tidak valid (mode img2img).");
      }
    } else {
      // === MODE TEXT2IMG ===
      const apiUrl = "https://api.openai.com/v1/images/generations";
      const response = await axios.post(
        apiUrl,
        {
          prompt,
          model: "gpt-image-1",
          n: 1,
          size: "1024x1024",
          quality: "high",
        },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
          },
        }
      );

      const resultData = response.data;
      if (resultData?.data?.[0]?.b64_json) {
        buffer = Buffer.from(resultData.data[0].b64_json, "base64");
      } else {
        throw new Error("Respons API tidak valid (mode text2img).");
      }
    }

    // === kirim hasil ke user ===
    await conn.sendMessage(
      m.chat,
      { image: buffer, mimetype: "image/png", caption: "✨ GPT Image siap!" },
      { quoted: m }
    );

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (err) {
    console.error(err);
    m.reply(`💥 Error: ${err.message || err}`);
  }
};

handler.help = ["gptimage <prompt>", "gptimg <prompt>"];
handler.tags = ["ai", "image"];
handler.command = /^(gptimage|gptimg)$/i;

export default handler;