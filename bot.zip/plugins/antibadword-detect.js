let badwordRegex = /anj|asw|kont|toiol|gblk|t0lol|bgsd|ajn|anjingk|bajingan|bangsat|kontol|memek|pepekq|meki|titit|peler|tetek|toket|ngewe|goblok|tolol|idiot|ngentotd|jembut|bego|dajjal|jancuk|pantek|pukimak|kimak|kampang|lonte|colimek|pelacur|henceut|nigga|fuck|dick|bitch|tits|bastard|asshole/i;

export async function before(m, { conn, isAdmin, isBotAdmin }) {
  if (!m.isGroup || m.fromMe || m.isBaileys) return;

  const chat = global.db.data.chats[m.chat];
  const user = global.db.data.users[m.sender];

  if (!chat?.antiToxic) return;

  const text = m.text || '';
  if (!badwordRegex.test(text)) return;

  if (!user.warnBadword) user.warnBadword = 0;
  user.warnBadword++;

  // Hapus pesan
  await conn.sendMessage(m.chat, { delete: m.key });

  // Kirim peringatan
  await m.reply(`⚠️ *ANTI TOXIC DETEKSI*\n@${m.sender.split('@')[0]} menggunakan kata kasar!\nPeringatan: *${user.warnBadword}/5*`, {
    mentions: [m.sender]
  });

  // Kick jika sudah 5
  if (user.warnBadword >= 5) {
    if (isBotAdmin && !isAdmin) {
      await m.reply(`🚫 *AUTO KICK*\n@${m.sender.split('@')[0]} telah mendapatkan 5 peringatan dan akan dikeluarkan.`, {
        mentions: [m.sender]
      });
      await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
    } else {
      await m.reply(`⚠️ Tidak dapat mengeluarkan @${m.sender.split('@')[0]} karena bot bukan admin atau dia admin.`, {
        mentions: [m.sender]
      });
    }
    user.warnBadword = 0;
  }

  return true;
}