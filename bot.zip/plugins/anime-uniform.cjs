const fetch = require('node-fetch')

let handler = async (m, { conn }) => {
  try {
    // Send processing reaction
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    // Fetch random uniform image from API
    const response = await fetch('https://api.nekorinn.my.id/waifuim/uniform')
    if (!response.ok) throw new Error('Failed to fetch uniform image')
    
    // Get image buffer
    const imageBuffer = await response.buffer()
    
    // Send image with caption
    await conn.sendMessage(m.chat, {
      image: imageBuffer,
      caption: 'Here is your random uniform waifu image~',
      mentions: [m.sender]
    }, { quoted: m })

    // Send success reaction
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

  } catch (error) {
    console.error('Uniform Waifu Error:', error)
    // Send error reaction and message
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    m.reply('Failed to get uniform waifu image. Please try again later.')
  }
}

handler.help = ['waifuuniform']
handler.tags = ['anime', 'fun']
handler.command = /^(waifuuniform|uniform)$/i
handler.limit = true
handler.premium = false

module.exports = handler