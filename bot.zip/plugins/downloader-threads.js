import axios from 'axios'

let handler = async (m, { conn, args, usedPrefix, command }) => {
  let url = args[0]||(m.quoted && m.quoted.text)
  if (!url||!url.includes('/post/')) {
    return m.reply(`masukin url threads contoh : ${usedPrefix + command} https://www.threads.net/@infopop.id/post/DMk2wrVzIoP`)
  }

  let threadId = url.match(/\/post\/([a-zA-Z0-9]+)/)?.[1]
  if (!threadId) return m.reply('eror gagal mengambil id post')

  try {
    m.reply('wettt')
    const res = await axios.get(`https://www.dolphinradar.com/api/threads/post_detail/${threadId}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
        'Accept': 'application/json'
      }
    })

    const data = res.data?.data
    if (!data||!data.post_detail||!data.user) throw 'data tidk di tmukan'

    const { post_detail: post, user } = data
    const media = post.media_list||[]
    const mediaUrls = media.map(m => m.url)

    let caption = `Full name : ${user.full_name}\n`
    caption += `Username : (@${user.username})\n`
    caption += `Verified : ${user.verified ? 'Verified' : 'gk Verified'}\n`
    caption += `Followers : ${user.follower_count} Followers\n\n`
    caption += `Caption : \n${post.caption_text||'-'}\n\n`
    caption += `Likes : ${post.like_count} Likes`

    for (let i = 0; i < mediaUrls.length; i++) {
      await conn.sendFile(m.chat, mediaUrls[i], null, i === 0 ? caption : '', m)
    }

  } catch (err) {
    console.error(err)
    m.reply(`Eror kak : ${err?.message||err}`)
  }
}

handler.help = ['threads', 'tredl']
handler.tags = ['downloader']
handler.command = ['threads', 'tredl']

export default handler