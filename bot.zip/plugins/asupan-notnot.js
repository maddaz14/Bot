let handler = async (m, { conn }) => {
  // Kirim emoji 🍏 sebagai reaksi saat memproses
  await conn.sendMessage(m.chat, {
    react: {
      text: '🍏',
      key: m.key
    }
  })

  const videos = [
    { url: 'https://k.top4top.io/m_2442ag1hz0.mp4' },
    { url: 'https://e.top4top.io/m_2442zoq1q0.mp4' },
    { url: 'https://d.top4top.io/m_2442fhuc30.mp4' },
    { url: 'https://j.top4top.io/m_24422gftd0.mp4' },
    { url: 'https://b.top4top.io/m_2443t8ab30.mp4' },
    { url: 'https://a.top4top.io/m_2443wc3wp0.mp4' },
    { url: 'https://b.top4top.io/m_2443mcw8l0.mp4' },
    { url: 'https://e.top4top.io/m_2444w606q1.mp4' },
    { url: 'https://d.top4top.io/m_24441r8490.mp4' },
    { url: 'https://g.top4top.io/m_2442x0pz10.mp4' }
  ]

  let randomVideo = videos[Math.floor(Math.random() * videos.length)]

  conn.sendMessage(m.chat, {
    video: { url: randomVideo.url },
    caption: '✅ Asupan Notnot',
  }, { quoted: m })
}

handler.help = ['notnot']
handler.tags = ['asupan']
handler.command = /^notnot$/i

export default handler