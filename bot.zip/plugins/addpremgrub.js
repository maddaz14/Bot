const handler = async (m, { conn, text }) => {
  if (!m.isGroup) return m.reply('Fitur ini hanya bisa digunakan di grup.');
  if (!text || isNaN(text)) return m.reply('Contoh: *.addpremgrub 7*');

  const duration = parseInt(text) * 86400000; // hari ke ms
  const expireTime = Date.now() + duration;

  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {};
  global.db.data.chats[m.chat].isPremiumGroup = true;
  global.db.data.chats[m.chat].premiumGroupExpire = expireTime;

  if (global.db.write) await global.db.write();

  m.reply(`✅ Grup ini telah menjadi *Premium Group* selama ${text} hari.\nSemua anggota dapat menggunakan fitur premium hanya di grup ini.`);
};

handler.command = /^addpremgrub$/i;
handler.tags = ['owner'];
handler.help = ['addpremgrub <jumlah hari>'];
handler.owner = true;
handler.group = true;

export default handler;