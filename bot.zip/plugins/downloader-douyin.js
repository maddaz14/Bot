import fetch from 'node-fetch';

const handler = async (m, { conn, args }) => {
  if (!args[0]) throw '❗ Masukkan URL video Douyin.\nContoh:\n.douyin2 https://v.douyin.com/if894Bb/';

  const apikey = 'jagaamanah';
  const inputUrl = args[0];
  const api = `https://api.botcahx.eu.org/api/download/douyin?url=${encodeURIComponent(inputUrl)}&apikey=${apikey}`;

  // Fake quoted message
  const fkontak = {
    key: {
      participant: '0@s.whatsapp.net',
      remoteJid: "0@s.whatsapp.net",
      fromMe: false,
      id: "UbedDouyin"
    },
    message: {
      conversation: "Douyin Video dikirim oleh ubed Bot 🍃"
    }
  };

  // 🍏 React saat memproses
  await conn.sendMessage(m.chat, {
    react: {
      text: '🍏',
      key: m.key
    }
  });

  try {
    const res = await fetch(api);
    const json = await res.json();

    if (!json.status || !json.result) throw '❌ Gagal mendapatkan data dari API.';
    const { title, video, audio } = json.result;

    if (!video?.[0]) throw '❌ Video tidak ditemukan!';
    if (!audio?.[0]) throw '❌ Audio tidak ditemukan!';

    const videoUrl = video[0];
    const audioUrl = audio[0];

    // Kirim video
    await conn.sendMessage(m.chat, {
      video: { url: videoUrl },
      mimetype: 'video/mp4',
      fileName: 'douyin.mp4',
      caption: `🎥 *Douyin Video*\n\n📌 *Judul:* ${title || 'Tanpa judul'}`
    }, { quoted: fkontak });

    // Kirim audio
    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/mpeg',
      ptt: false,
      fileName: 'douyin.mp3'
    }, { quoted: fkontak });

  } catch (err) {
    console.error(err);
    m.reply(`❌ Gagal mengambil media.\n${err.message || err}`, fkontak);
  }
};

handler.help = ['douyin <url>'];
handler.tags = ['downloader'];
handler.command = /^douyin$/i;

export default handler;