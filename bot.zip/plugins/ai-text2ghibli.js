import { randomUUID } from 'crypto'
import { promisify } from 'util'
import zlib from 'zlib'
import fetch from 'node-fetch'

const gunzip = promisify(zlib.gunzip)
const inflate = promisify(zlib.inflate)
const brotli = promisify(zlib.brotliDecompress)

async function _tryDecompress(buf, contentEncoding) {
  if (!contentEncoding) return null
  const enc = contentEncoding.toLowerCase()
  try {
    if (enc.includes('gzip') || enc.includes('x-gzip')) return (await gunzip(buf)).toString('utf8')
    if (enc.includes('deflate')) return (await inflate(buf)).toString('utf8')
    if (enc.includes('br') || enc.includes('brotli')) return (await brotli(buf)).toString('utf8')
  } catch {
    return null
  }
  return null
}

export async function generateImage(prompt) {
  if (!prompt || typeof prompt !== 'string') throw new Error('Promptnya mana bre? 😂')

  const endpoint = 'https://widget-api.overchat.ai/v1/images/generations'
  const uuid = randomUUID()

  const headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 11; vivo 1901) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.7258.143 Mobile Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Encoding': 'identity',
    'Content-Type': 'application/json',
    'sec-ch-ua-platform': '"Android"',
    'x-device-uuid': uuid,
    'authorization': 'Bearer',
    'sec-ch-ua': '"Not;A=Brand";v="99", "Android WebView";v="139", "Chromium";v="139"',
    'sec-ch-ua-mobile': '?1',
    'x-device-language': 'en',
    'x-device-platform': 'web',
    'x-device-version': '1.0.44',
    'origin': 'https://widget.overchat.ai',
    'x-requested-with': 'mark.via.gp',
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://widget.overchat.ai/',
    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'priority': 'u=1, i'
  }

  const bodyObj = {
    prompt,
    model: 'google/imagen4/preview',
    personaId: 'Imagen-4'
  }

  let resp
  try {
    resp = await fetch(endpoint, { method: 'POST', headers, body: JSON.stringify(bodyObj) })
  } catch (err) {
    throw err
  }

  const contentEncoding = resp.headers?.get('content-encoding') || null

  let arr
  try {
    arr = await resp.arrayBuffer()
  } catch (err) {
    throw err
  }

  const buf = Buffer.from(arr)
  let text = buf.toString('utf8')

  let json = null
  try {
    json = JSON.parse(text)
  } catch (err) {
    const decompressed = await _tryDecompress(buf, contentEncoding)
    if (decompressed) {
      try {
        json = JSON.parse(decompressed)
      } catch {
        throw new Error('Respons gak JSON, udah coba dekompres tetep zonk 😂')
      }
    } else {
      throw new Error('JSON gak valid, server lagi mabok 😂')
    }
  }

  if (!json || !Array.isArray(json.data) || !json.data.length) {
    throw new Error('Data kosong, server nya ngambek bre 😝👈')
  }

  const first = json.data[0]
  if (!first.url) throw new Error('Server gak kasih URL gambarnya 😭')

  return first.url
}

// === Handler Plugin ===
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `⚠️ Masukkan prompt!\n\nContoh:\n*${usedPrefix + command} Totoro under the rain, studio ghibli style*`

  await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key } })

  try {
    const imgUrl = await generateImage(text)
    await conn.sendMessage(m.chat, {
      image: { url: imgUrl },
      caption: `✅ *Berhasil generate gambar!*\n🎬 Style: Ghibli\n📌 Prompt: ${text}`
    }, { quoted: m })

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (err) {
    console.error(err)
    throw `❌ Gagal generate gambar.\n\nLog: ${err.message || err}`
  }
}

handler.help = ['text2ghibli <prompt>']
handler.tags = ['ai', 'tools']
handler.command = /^text2ghibli$/i
handler.limit = true
handler.premium = false

export default handler