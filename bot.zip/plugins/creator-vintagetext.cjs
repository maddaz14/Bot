const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('Masukkan teks yang ingin diubah ke gaya 1917\nContoh: .vintagetext Hello World');
  
  try {
    // Send initial reaction
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const apiUrl = `https://api.nekorinn.my.id/ephoto/1917-style-text?text=${encodeURIComponent(text)}`;
    
    // Fetch the image from API
    const response = await fetch(apiUrl);
    if (!response.ok) throw new Error(`API Error: ${response.status}`);
    
    // Get the image buffer
    const imageBuffer = await response.buffer();
    
    // Send the image
    await conn.sendMessage(m.chat, { 
      image: imageBuffer,
      caption: `Teks gaya vintage 1917: ${text}`,
      mentions: [m.sender]
    }, { quoted: m });
    
    // Update reaction
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    
  } catch (error) {
    console.error('Error:', error);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply('Gagal membuat teks vintage. Silakan coba lagi nanti.');
  }
};

handler.help = ['vintagetext <teks>'];
handler.tags = ['creator'];
handler.command = /^(1917text|vintagetext)$/i;
handler.limit = true;
handler.premium = false;

module.exports = handler;