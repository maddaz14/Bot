// plugins/noprefix.js
let handler = async (m, { conn, args, usedPrefix, command }) => {
    let chat = global.db.data.chats[m.chat];
    if (!chat) return;

    // Tidak perlu lagi memeriksa m.isGroup di sini karena sudah ada handler.group = true
    // if (!m.isGroup) {
    //     return m.reply('Perintah ini hanya bisa digunakan di grup.');
    // }

    // Baris ini dihapus karena sudah di-handle oleh handler.admin = true
    // if (!m.isAdmin && !m.isOwner) {
    //     return m.reply('Anda harus menjadi Admin atau Owner untuk menggunakan perintah ini.');
    // }

    let isEnable = args[0] && /(on|enable)/i.test(args[0]);
    let isDisable = args[0] && /(off|disable)/i.test(args[0]);

    if (!isEnable && !isDisable) {
        return m.reply(`Penggunaan:
*${usedPrefix + command} on* untuk mengaktifkan perintah tanpa prefix.
*${usedPrefix + command} off* untuk menonaktifkan perintah tanpa prefix.

Status saat ini: ${chat.noprefix ? '✅ Aktif' : '❌ Nonaktif'}
        `);
    }

    if (isEnable) {
        if (chat.noprefix) return m.reply('Perintah tanpa prefix sudah aktif.');
        chat.noprefix = true;
        m.reply('Perintah tanpa prefix berhasil *diaktifkan* di grup ini. Sekarang bot akan merespons perintah tanpa titik.');
    } else if (isDisable) {
        if (!chat.noprefix) return m.reply('Perintah tanpa prefix sudah nonaktif.');
        chat.noprefix = false;
        m.reply('Perintah tanpa prefix berhasil *dinonaktifkan* di grup ini. Bot hanya akan merespons perintah dengan titik.');
    }
};

handler.help = ['noprefix'];
handler.tags = ['group'];
handler.command = ['noprefix'];
handler.admin = true; // Hanya admin grup yang bisa menggunakan
handler.group = true; // Hanya bisa di grup
module.exports = handler;