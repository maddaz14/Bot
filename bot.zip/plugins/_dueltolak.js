const handler = async (m, { conn }) => {
  conn.duel = conn.duel || []
  const duel = conn.duel.find(d => d.opponent === m.sender)
  if (!duel) return m.reply('Tidak ada tantangan untuk kamu.')

  conn.duel = conn.duel.filter(d => d !== duel)
  await conn.sendMessage(m.chat, {
    text: `@${m.sender.split('@')[0]} menolak duel dari @${duel.challenger.split('@')[0]}.`,
    mentions: [m.sender, duel.challenger]
  }, { quoted: m })
}

handler.command = /^dueltolak$/i
handler.group = true

export default handler