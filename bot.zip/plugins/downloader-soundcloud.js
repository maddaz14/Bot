import fetch from 'node-fetch';

let handler = async (m, { conn, args, text, usedPrefix, command }) => {
  if (!text) throw `📻 Masukkan judul lagu SoundCloud!\n\nContoh:\n${usedPrefix + command} Wali Jamin Rasaku`;

  try {
    // 1. Cari lagu berdasarkan query
    let searchUrl = `https://api.siputzx.my.id/api/s/soundcloud?query=${encodeURIComponent(text)}`;
    let searchRes = await fetch(searchUrl);
    let searchJson = await searchRes.json();

    if (!searchJson.status || !searchJson.data || !searchJson.data.length) {
      throw '🚫 Lagu tidak ditemukan!';
    }

    // 2. Ambil lagu pertama dari hasil pencarian
    let firstResult = searchJson.data[0];
    let downloadUrl = `https://api.siputzx.my.id/api/d/soundcloud?url=${encodeURIComponent(firstResult.permalink_url)}`;

    // 3. Unduh lagu
    let dlRes = await fetch(downloadUrl);
    let dlJson = await dlRes.json();

    if (!dlJson.status || !dlJson.url) {
      throw '🚫 Gagal mengambil link unduhan!';
    }

    // 4. Kirim lagu ke pengguna
    await conn.sendMessage(m.chat, {
      audio: { url: dlJson.url },
      mimetype: 'audio/mpeg',
      fileName: dlJson.title || 'soundcloud.mp3',
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply('❌ Terjadi kesalahan saat memproses permintaanmu!');
  }
};

handler.help = ['soundcloud'].map(v => v + ' <judul>');
handler.tags = ['downloader'];
handler.command = /^(soundcloud)$/i;

export default handler;