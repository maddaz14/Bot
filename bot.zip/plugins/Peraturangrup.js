import fs from 'fs'
import { generateWAMessageFromContent } from '@fuxxy-star/baileys' // ganti adiwajshing → whiskeysockets

const handler = async (m, { conn, args }) => {
    const groupId = args[0]
    if (!groupId || !groupId.endsWith('@g.us')) {
        return m.reply('⚠️ ID grup tidak valid. Contoh: `.peraturan 1234567890@g.us`')
    }

    // Mengambil metadata grup
    const groupMetadata = await conn.groupMetadata(groupId).catch(() => null)
    if (!groupMetadata) {
        return m.reply('⚠️ Gagal mengambil metadata grup atau grup tidak ditemukan.')
    }

    const caption = `📋 *Menu Peraturan Grup:* ${groupMetadata.subject}\n\nPilih peraturan yang ingin diterapkan pada grup ini.`

    const actions = [
        'Leave Grup', 
        'Sewa 1 Hari', 
        'Sewa 5 Hari', 
        'Sewa 7 Hari', 
        'Sewa 2 Minggu', 
        'Sewa 1 Bulan', 
        'Sewa 2 Bulan', 
        'Mute Grup', 
        'Unmute Grup', 
        'Get Link Grup', 
        'Close Grup', 
        'Open Grup'
    ]

    const rows = actions.map(action => {
        let command;
        if (action === 'Mute Grup') {
            command = 'mutegrup'
        } else if (action === 'Unmute Grup') {
            command = 'unmutegrup'
        } else {
            command = action.toLowerCase().replace(/\s+/g, '')
        }
        
        return {
            header: "",
            title: `➕ ${action}`,
            description: "",
            id: `.${command} ${groupId}`
        }
    })

    const msg = generateWAMessageFromContent(
        m.chat,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: caption },
                        footer: { text: "© ubed Bot 2025" },
                        header: {
                            title: "",
                            subtitle: `Grup: ${groupMetadata.subject}`,
                            hasMediaAttachment: false
                        },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    title: "Pilih Peraturan",
                                    sections: [{
                                        title: "Daftar Peraturan Grup",
                                        highlight_label: "Aturan",
                                        rows: rows
                                    }]
                                })
                            }]
                        }
                    }
                }
            }
        },
        { quoted: m }
    )

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.command = ['peraturan']
handler.owner = true

export default handler