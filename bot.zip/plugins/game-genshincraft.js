import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text) {
    try {
      const list = await genshindb.crafts("names", { matchCategories: true });
      return m.reply(`📜 *Daftar Craft Tersedia:*\n\n${list.join(", ")}`);
    } catch (e) {
      console.error('[CRAFT LIST ERROR]', e);
      return m.reply('❌ Gagal mengambil daftar craft.');
    }
  }

  try {
    const result = await genshindb.crafts(text);
    if (result) {
      let response = `🔧 *Craft Ditemukan: ${result.name}*\n\n`;
      response += `📝 _${result.description || "Deskripsi tidak tersedia"}_\n\n`;
      response += `📦 *Type:* ${result.type || "Tidak diketahui"}\n`;
      response += `⭐ *Rarity:* ${result.rarity || "Tidak diketahui"}`;
      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[CRAFT ERROR]', err);
    try {
      const available = await genshindb.crafts("names", { matchCategories: true });
      return m.reply(`❌ Craft '${text}' tidak ditemukan.\n\n📜 *Craft yang tersedia:*\n${available.join(", ")}`);
    } catch (e) {
      return m.reply('⚠️ Gagal menampilkan daftar craft.');
    }
  }
};

handler.help = ['genshin-craft <nama craft>'];
handler.tags = ['game'];
handler.command = /^(genshin-craft|g-craft|gens-craft)$/i;
handler.limit = 1;
handler.register = true;

export default handler;