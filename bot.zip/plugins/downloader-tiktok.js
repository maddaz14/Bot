import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from "@fuxxy-star/baileys";
import axios from 'axios'
import * as cheerioModule from 'cheerio'
import FormData from 'form-data'
import * as tough from 'tough-cookie'
import { wrapper } from 'axios-cookiejar-support'

// ==========================================================
// UNIVERSAL CHEERIO IMPORT (support Node 18–22+)
// ==========================================================
const cheerio = cheerioModule.default || cheerioModule
const load = cheerio.load || cheerioModule.load

// ==========================================================
// CLIENT SCRAPING TIKTOK (SnapTikClient)
// (Bagian ini tidak diubah, berfungsi untuk scraping)
// ==========================================================
class SnapTikClient {
  constructor(config = {}) {
    this.config = {
      baseURL: "https://snaptik.app",
      ...config,
    }

    const cookieJar = new tough.CookieJar()

    const baseClient = axios.create({
      baseURL: this.config.baseURL,
      withCredentials: true,
      headers: {
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36",
        "sec-ch-ua": '"Not A(Brand";v="8", "Chromium";v="132"',
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": '"Android"',
        "Upgrade-Insecure-Requests": "1",
      },
      timeout: 30000,
    })

    this.axios = wrapper(baseClient)
  }

  async get_token() {
    const { data } = await this.axios.get("/en2", {
      headers: { Referer: "https://snaptik.app/en2" },
    })
    const $ = load(data)
    return $("input[name=\"token\"]").val()
  }

  async get_script(url) {
    const form = new FormData()
    const token = await this.get_token()
    if (!token) throw new Error("Failed to get token")

    form.append("url", url)
    form.append("lang", "en2")
    form.append("token", token)

    const { data } = await this.axios.post("/abc2.php", form, {
      headers: {
        ...form.getHeaders(),
        "authority": "snaptik.app",
        "accept": "*/*",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "origin": "https://snaptik.app",
        "referer": "https://snaptik.app/en2",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
      },
    })
    return data
  }

  async eval_script(script1) {
    const script2 = await new Promise((resolve) =>
      Function("eval", script1)(resolve)
    )

    return new Promise((resolve, reject) => {
      let html = ""
      const mockObjects = {
        $: () => ({
          remove() {},
          style: { display: "" },
          get innerHTML() { return html },
          set innerHTML(t) { html = t },
        }),
        app: { showAlert: reject },
        document: { getElementById: () => ({ src: "" }) },
        fetch: (a) => {
          resolve({ html, oembed_url: a })
          return { json: () => ({ thumbnail_url: "" }) }
        },
        gtag: () => 0,
        Math: { round: () => 0 },
        XMLHttpRequest: function () { return { open() {}, send() {} } },
        window: { location: { hostname: "snaptik.app" } },
      }

      try {
        Function(...Object.keys(mockObjects), script2)(...Object.values(mockObjects))
      } catch (error) {
        console.log("Eval error:", error.message)
        reject(error)
      }
    })
  }

  async get_hd_video(hdUrl, backupUrl) {
    try {
      const { data } = await this.axios.get(hdUrl)
      if (data && data.url) return data.url
    } catch (error) {
      console.log("HD URL failed, using backup:", error.message)
    }
    return backupUrl
  }

  async parse_html(html) {
    const $ = load(html)
    const isVideo = !$("div.render-wrapper").length

    const thumbnail = $(".avatar").attr("src") || $("#thumbnail").attr("src")
    const title = $(".video-title").text().trim()
    const creator = $(".info span").text().trim()

    if (isVideo) {
      const hdButton = $("div.video-links > button[data-tokenhd]")
      const hdTokenUrl = hdButton.data("tokenhd")
      const backupUrl = hdButton.data("backup")

      let hdUrl = null
      if (hdTokenUrl) hdUrl = await this.get_hd_video(hdTokenUrl, backupUrl)

      const videoUrls = [
        hdUrl || backupUrl,
        ...$("div.video-links > a:not(a[href=\"/\"])")
          .map((_, elem) => $(elem).attr("href"))
          .get()
          .filter((url) => url && !url.includes("play.google.com"))
          .map((x) => (x.startsWith("/") ? this.config.baseURL + x : x)),
      ].filter(Boolean)

      return {
        type: "video",
        urls: videoUrls,
        metadata: { title, description: title, thumbnail, creator },
      }
    } else {
      const photos = $("div.columns > div.column > div.photo")
        .map((_, elem) => ({
          urls: [
            $(elem).find("img[alt=\"Photo\"]").attr("src"),
            $(elem).find("a[data-event=\"download_albumPhoto_photo\"]").attr("href"),
          ],
        }))
        .get()

      const formattedUrls = photos.map(p => p.urls[0] || p.urls[1]).filter(Boolean)

      return {
        type: photos.length === 1 ? "photo" : "slideshow",
        urls: formattedUrls,
        metadata: { title, description: title, thumbnail, creator },
      }
    }
  }

  async process(url) {
    try {
      const script = await this.get_script(url)
      const { html, oembed_url } = await this.eval_script(script)
      const result = await this.parse_html(html)
      return { original_url: url, oembed_url, ...result }
    } catch (error) {
      throw new Error(error.message || "Scraping failed")
    }
  }
}

async function scrapeTiktok(url) {
  try {
    const client = new SnapTikClient()
    return await client.process(url)
  } catch (error) {
    return { error: error.message || "Gagal memproses URL TikTok" }
  }
}

// ==========================================================
// HANDLER BOT WHATSAPP (MODIFIKASI SLIDESHOW)
// ==========================================================
const handler = async (m, { conn, text }) => {
  if (!text) return m.reply('Masukin URL TikTok woy!\nContoh: .tiktok https://vt.tiktok.com/xxxxxx')

  await conn.sendMessage(m.chat, { react: { text: '🔄', key: m.key } })

  try {
    const d = await scrapeTiktok(text.trim())
    if (d.error) throw new Error(d.error)

    const { metadata = {}, original_url, urls = [], type } = d
    if (!urls || urls.length === 0 || type === 'error') {
      throw new Error('Video/foto tidak tersedia atau SnapTik gagal memproses.')
    }

    const contentTitle = (type === 'slideshow' ? ' (SLIDESHOW)' : type === 'photo' ? ' (FOTO)' : ' (VIDEO)')
    const baseCaption = `*TikTok Downloader*${contentTitle}\n*Judul:* ${metadata.title || '-'}\n👤 Creator: ${metadata.creator || '-'}\n🔗 Original: ${original_url || '-'}`

    if (type === 'video') {
      // Kirim sebagai Video Biasa
      await conn.sendMessage(m.chat, { video: { url: urls[0] }, caption: baseCaption }, { quoted: m })
    } else if (type === 'photo') {
      // Kirim sebagai Foto Biasa
      await conn.sendMessage(m.chat, { image: { url: urls[0] }, caption: baseCaption }, { quoted: m })
    } else if (type === 'slideshow' && urls.length > 0) {
      // --- MODIFIKASI UNTUK CAROUSEL MESSAGE (Gaya Pinterest) ---
      
      let push = []
      // Batasi maksimal 10 gambar untuk CarouselMessage
      const slideshowUrls = urls.slice(0, 10) 

      for (let i = 0; i < slideshowUrls.length; i++) {
          const photoUrl = slideshowUrls[i]
          
          const media = await prepareWAMessageMedia(
              { image: { url: photoUrl } },
              { upload: conn.waUploadToServer }
          );

          // Gunakan caption di kartu pertama, sisanya kosongkan
          const cardBody = i === 0 ? baseCaption : `Foto ${i + 1} dari ${slideshowUrls.length}`

          push.push({
              header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: `📸 SLIDE ${i + 1} / ${slideshowUrls.length}`,
                  hasMediaAttachment: true,
                  ...media
              }),
              body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: cardBody
              }),
              footer: proto.Message.InteractiveMessage.Footer.fromObject({
                  text: "TikTok Slideshow Downloader"
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [
                      {
                          name: "cta_url",
                          buttonParamsJson: JSON.stringify({
                              display_text: "🔗 Kunjungi TikTok",
                              url: original_url
                          })
                      },
                      {
                           name: "quick_reply",
                           buttonParamsJson: JSON.stringify({
                               display_text: "⬇️ Download Foto Ini",
                               id: `.getfoto ${photoUrl}` // Anda perlu membuat handler terpisah untuk command .getfoto
                           })
                      }
                  ]
              })
          });
      }

      // Bangun dan kirim CarouselMessage
      const msg = generateWAMessageFromContent(m.chat, {
          viewOnceMessage: {
              message: {
                  messageContextInfo: {
                      deviceListMetadata: {},
                      deviceListMetadataVersion: 2
                  },
                  businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },
                  forwardingScore: 256,
                  interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                      body: proto.Message.InteractiveMessage.Body.create({
                          text: `*${slideshowUrls.length} Foto* ditemukan dari Slideshow TikTok!`
                      }),
                      footer: proto.Message.InteractiveMessage.Footer.create({
                          text: "Geser ke samping untuk melihat foto lainnya."
                      }),
                      carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                          cards: [...push]
                      })
                  })
              }
          }
      }, { userJid: m.chat, quoted: m });

      await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
      // --- AKHIR MODIFIKASI CAROUSEL MESSAGE ---

    } else {
      throw new Error('Tipe konten tidak dikenal atau tidak didukung.')
    }

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (e) {
    console.error('Error TikTok Scrape:', e)
    m.reply(`❌ Eror saat men-scrape TikTok:\n\n${e.message}`)
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
  }
}

handler.command = ['tiktok', 'tt', 'ttdl']
handler.help = ['tiktok <url>']
handler.tags = ['downloader']

export default handler