import fetch from 'node-fetch';

export async function before(m, { conn }) {
    let chat = global.db.data.chats[m.chat] || {};
    if (typeof chat.simi === 'undefined') chat.simi = false;
    if (typeof chat.isBanned === 'undefined') chat.isBanned = false;

    if (chat.simi && !chat.isBanned) {
        if (/^.*false|disable|(turn)?off|0/i.test(m.text)) return;
        if (!m.text || m.fromMe) return;

        try {
            let response = await fetch(
                `https://api.ubed.my.id/ai/simi?apikey=alhamdulilah&text=${encodeURIComponent(m.text)}`
            );
            if (!response.ok) throw new Error('API Obet Error');

            let json = await response.json();

            if (!json.status || !json.result) throw new Error();

            await conn.reply(m.chat, json.result, m);
        } catch (err) {
            console.error(err);
            await conn.reply(m.chat, '⚠️ Terjadi kesalahan pada SimSimi API.', m);
        }

        return true;
    }

    return true;
}