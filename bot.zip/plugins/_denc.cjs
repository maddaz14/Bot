const { Deobfuscator } = require("deobfuscator");

let handler = async (m, { args, command, usedPrefix }) => {
    const usage = `*Contoh:* ${usedPrefix}${command} *[input/reply code]*`;
    let codeToDecrypt;

    // Menentukan sumber kode: dari argumen atau dari pesan yang di-reply
    if (args.length >= 1) {
        codeToDecrypt = args.join(" ");
    } else if (m.quoted && m.quoted.text) {
        codeToDecrypt = m.quoted.text;
    } else {
        throw usage;
    }

    try {
        await m.reply("Sedang mendekripsi kode... 🕊️");
        const decryptedCode = await decryptCode(codeToDecrypt);
        
        // Memastikan hasil dekripsi tidak kosong
        if (!decryptedCode) {
            return m.reply("Gagal mendekripsi kode. Mungkin kode tidak di-obfuscate.");
        }

        // Mengirim hasil dekripsi
        m.reply(decryptedCode);
    } catch (error) {
        console.error("Error during deobfuscation:", error);
        m.reply("Terjadi kesalahan saat mendekripsi kode. Pastikan kode valid.");
    }
};

handler.help = ["denc", "dencrypt"].map((a) => a + " *[input/reply code]*");
handler.tags = ["tools"];
handler.command = ["denc", "dencrypt"];
module.exports = handler;

/**
 * Mendekripsi kode yang di-obfuscate.
 * @param {string} code - Kode yang akan didekripsi.
 * @returns {Promise<string>} - Kode yang sudah didekripsi.
 */
async function decryptCode(code) {
    const deobfuscator = new Deobfuscator();
    return deobfuscator.deobfuscateSource(code);
}