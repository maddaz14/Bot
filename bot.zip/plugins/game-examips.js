import similarity from 'similarity'

let timeout = 120000
let poin = 4999
const threshold = 0.72

let handler = async (m, { conn, command, usedPrefix }) => {
    conn.tebaksosial = conn.tebaksosial ? conn.tebaksosial : {}
    let id = m.chat
    if (id in conn.tebaksosial) {
        conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.tebaksosial[id][0])
        throw false
    }

    let json = soalIPSBANK[Math.floor(Math.random() * soalIPSBANK.length)]
    let caption = `*${command.toUpperCase()}*
${json.soal}
a. ${json.a}
b. ${json.b}
c. ${json.c}
d. ${json.d}

Timeout *${(timeout / 1000).toFixed(2)} detik*
Bonus: ${poin} XP
`.trim()
    
    conn.tebaksosial[id] = [
        await conn.reply(m.chat, caption, m),
        json, poin,
        setTimeout(() => {
            if (conn.tebaksosial[id]) conn.reply(m.chat, `Waktu habis!\nJawaban yang benar adalah *${json.jawaban}*`, conn.tebaksosial[id][0])
            delete conn.tebaksoal[id]
        }, timeout)
    ]
}

handler.help = ['tebaksosial']
handler.tags = ['game']
handler.command = /^tebaksosial$/i

handler.before = async function (m, { conn }) {
    let id = m.chat
    if (!m.text) return
    this.tebaksosial = this.tebaksosial || {}
    if (!(id in this.tebaksosial)) return

    let kuis = this.tebaksosial[id]
    
    // Periksa apakah pengguna menyerah
    let isSurrender = /^(me)?nyerah|surr?ender$/i.test(m.text)
    if (isSurrender) {
        clearTimeout(kuis[3])
        delete this.tebaksosial[id]
        return m.reply('*Yah, menyerah :( !*')
    }

    let json = kuis[1]
    let userAnswer = m.text.toLowerCase().trim()
    
    // Cek jawaban
    let isCorrect = (userAnswer === json.jawaban.toLowerCase().trim() ||
                     (userAnswer === 'a' && json.a.toLowerCase().trim() === json.jawaban.toLowerCase().trim()) ||
                     (userAnswer === 'b' && json.b.toLowerCase().trim() === json.jawaban.toLowerCase().trim()) ||
                     (userAnswer === 'c' && json.c.toLowerCase().trim() === json.jawaban.toLowerCase().trim()) ||
                     (userAnswer === 'd' && json.d.toLowerCase().trim() === json.jawaban.toLowerCase().trim()))

    if (isCorrect) {
        global.db.data.users[m.sender].exp += kuis[2]
        global.db.data.users[m.sender].limit += 2
        conn.reply(m.chat, `✅ *Benar!*\n🎉 +${kuis[2]} XP\n🎁 +2 Limit`, m)
        clearTimeout(kuis[3])
        delete this.tebaksosial[id]
    } else {
        conn.reply(m.chat, `*Jawaban Salah!*`, m)
    }
}

export default handler

const soalIPSBANK = [
  { "soal": "Pada abad ke-15, bangsa Eropa melakukan perjalanan laut yang dikenal sebagai …", "a": "Revolusi Industri", "b": "Era Penjelajahan", "c": "Era Perang Dunia", "d": "Zaman Batu", "jawaban": "Era Penjelajahan" },
  { "soal": "Apa dampak dari Revolusi Industri terhadap kehidupan manusia?", "a": "Peningkatan produksi tangan", "b": "Pengurangan populasi", "c": "Peningkatan pertanian tradisional", "d": "Penurunan permintaan bahan bakar", "jawaban": "Peningkatan produksi tangan" },
  { "soal": "Apakah yang dimaksud dengan kolonisasi?", "a": "Proses perpindahan penduduk dalam satu wilayah", "b": "Proses membangun industri", "c": "Penjelajahan luar angkasa", "d": "Proses penjajahan dan pengambilalihan wilayah lain", "jawaban": "Proses penjajahan dan pengambilalihan wilayah lain" },
  { "soal": "Apa yang menjadi faktor penyebab utama terjadinya Perang Dunia I?", "a": "Perang Dingin antara AS dan Uni Soviet", "b": "Kebijakan perdagangan bebas", "c": "Persaingan antar negara Eropa", "d": "Revolusi Industri di Asia", "jawaban": "Persaingan antar negara Eropa" },
  { "soal": "Manakah dari berikut ini bukan akibat dari Perang Dunia II?", "a": "Pembagian Jerman menjadi Timur dan Barat", "b": "Pembentukan Liga Bangsa-Bangsa", "c": "Pemisahan India dan Pakistan", "d": "Peningkatan hubungan antar negara", "jawaban": "Pembentukan Liga Bangsa-Bangsa" },
  { "soal": "Apa yang dimaksud dengan kapitalisme?", "a": "Sistem ekonomi di mana pemerintah mengendalikan semua aspek ekonomi", "b": "Sistem ekonomi di mana perekonomian dikendalikan oleh swasta dan pasar bebas", "c": "Sistem politik yang menekankan persamaan sosial", "d": "Sistem pertanian tradisional", "jawaban": "Sistem ekonomi di mana perekonomian dikendalikan oleh swasta dan pasar bebas" },
  { "soal": "Apa yang dimaksud dengan perdagangan internasional?", "a": "Perdagangan antara dua negara yang berbeda", "b": "Perdagangan antar kelompok masyarakat di dalam negara yang sama", "c": "Perdagangan dalam satu wilayah geografis", "d": "Pertukaran barang dan jasa dalam satu kelompok masyarakat", "jawaban": "Perdagangan antara dua negara yang berbeda" },
  { "soal": "Apa yang menjadi tujuan utama dari ASEAN?", "a": "Membentuk aliansi militer global", "b": "Memperluas kolonialisasi", "c": "Menciptakan pasar tunggal dan produksi", "d": "Mengurangi perdagangan internasional", "jawaban": "Menciptakan pasar tunggal dan produksi" },
  { "soal": "Apakah yang dimaksud dengan globalisasi?", "a": "Penutupan perbatasan antar negara", "b": "Pembentukan blok ekonomi regional", "c": "Perang dunia antara berbagai negara", "d": "Penyebaran budaya, perdagangan, dan komunikasi secara global", "jawaban": "Penyebaran budaya, perdagangan, dan komunikasi secara global" },
  { "soal": "Apa yang menjadi penyebab utama pemanasan global?", "a": "Kegiatan vulkanik alami", "b": "Emisi gas rumah kaca akibat aktivitas manusia", "c": "Penurunan penggunaan bahan bakar fosil", "d": "Penurunan tingkat deforestasi", "jawaban": "Emisi gas rumah kaca akibat aktivitas manusia" }
]