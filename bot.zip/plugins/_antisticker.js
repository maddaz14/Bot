export async function before(m, { isAdmin, isBotAdmin }) {
  // Nomor owner
  const owner = '6283857182374@s.whatsapp.net';

  // Abaikan pesan dari bot / baileys
  if (m.isBaileys && m.fromMe) return true;

  // Ambil data chat
  let chat = global.db.data.chats[m.chat] || {};
  if (typeof chat.antiSticker === 'undefined') chat.antiSticker = false;

  let sender = m.sender;

  // Cek apakah pesan adalah stiker
  let isSticker = m.mtype === 'stickerMessage';
  let hapus = m.key.participant || m.sender;
  let bang = m.key.id;

  // Anti-sticker logic
  if (chat.antiSticker && isSticker) {
    // Kalau admin, bot bukan admin, atau owner → biarkan
    if (isAdmin || !isBotAdmin || sender === owner) {
      return true;
    }

    // Kalau bukan admin → hapus
    await m.reply(
      `*「 ANTI STICKER 」*\n\nSticker dari @${sender.split('@')[0]} dihapus karena fitur *antiSticker* aktif.`,
      { mentions: [sender] }
    );

    return this.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: bang,
        participant: hapus,
      },
    });
  }

  return true;
}