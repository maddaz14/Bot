const isNumber = x => typeof x === 'number' && !isNaN(x);
const delay = ms => isNumber(ms) && new Promise(resolve => setTimeout(resolve, ms));

global.prefix = new RegExp('^[' + (opts['prefix'] || '‎xzXZ/!#$Oo%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-').replace(/[|\\{}()[\]^Oo$+*?.\-\^]/g, '\\$&') + ']');

// default aktif
global.typing = true 

export async function all(m) {
    if (!global.typing) return; // kalau off, bot gak kirim status mengetik

    if (m.message && global.prefix.test(m.text)) {
        await this.readMessages([m.key]);
        await this.sendPresenceUpdate('composing', m.chat);
        await delay(1000);
        await this.sendPresenceUpdate('paused', m.chat);
    }
}

// Handler perintah .typing on / .typing off
let handler = async (m, { conn, args }) => {
    if (!args[0]) {
        return conn.reply(m.chat, `Gunakan:\n.typing on\n.typing off`, m)
    }
    if (args[0].toLowerCase() === 'on') {
        global.typing = true
        conn.reply(m.chat, `Status mengetik: ✅ ON`, m)
    } else if (args[0].toLowerCase() === 'off') {
        global.typing = false
        conn.reply(m.chat, `Status mengetik: ❌ OFF`, m)
    } else {
        conn.reply(m.chat, `Pilihan tidak valid.\nGunakan:\n.typing on\n.typing off`, m)
    }
}

handler.command = /^typing$/i
handler.owner = true

export default handler