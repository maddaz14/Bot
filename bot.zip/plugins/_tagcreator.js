/*
let handler = async (m, { conn, isOwner }) => {
    if (!isOwner) {
        await conn.sendMessage(m.chat, {
            sticker: {
                url: 'https://files.catbox.moe/sa2jdc.webp'
            }
        }, {
            quoted: floc
        });
    }
}

handler.customPrefix = new RegExp(`@${global.nomorown}`, 'i');
handler.command = new RegExp();

export default handler;
*/