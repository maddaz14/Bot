import { generateWAMessageFromContent, prepareWAMessageMedia, proto } from "@fuxxy-star/baileys";
import axios from 'axios'
import crypto from 'crypto'
import yts from 'yt-search'
import https from "https";

// Pesan acak untuk fkontak
const randomConversations = [
  "Download lagu langsung dari YouTube! 🎶",
  `${global.botname} siap temani harimu dengan musik 📀`,
  "Udah siap dengerin lagu favoritmu? 😎",
  "Musik pilihanmu siap diputar 🍃",
]

const getRandomText = () =>
  randomConversations[Math.floor(Math.random() * randomConversations.length)]

// Scraper dari .yta
const downloadYouTube = async (link, format = '720') => {
  const apiBase = "https://media.savetube.me/api";
  const apiCDN = "/random-cdn";
  const apiInfo = "/v2/info";
  const apiDownload = "/download";

  const decryptData = async (enc) => {
    try {
      const key = Buffer.from('C5D58EF67A7584E4A29F6C35BBC4EB12', 'hex');
      const data = Buffer.from(enc, 'base64');
      const iv = data.slice(0, 16);
      const content = data.slice(16);
      
      const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
      let decrypted = decipher.update(content);
      decrypted = Buffer.concat([decrypted, decipher.final()]);
      
      return JSON.parse(decrypted.toString());
    } catch (error) {
      return null;
    }
  };

  const request = async (endpoint, data = {}, method = 'post') => {
    try {
      const { data: response } = await axios({
        method,
        url: `${endpoint.startsWith('http') ? '' : apiBase}${endpoint}`,
        data: method === 'post' ? data : undefined,
        params: method === 'get' ? data : undefined,
        headers: {
          'accept': '*/*',
          'content-type': 'application/json',
          'origin': 'https://yt.savetube.me',
          'referer': 'https://yt.savetube.me/',
          'user-agent': 'Postify/1.0.0'
        }
      });
      return { status: true, data: response };
    } catch (error) {
      return { status: false, error: error.message };
    }
  };

  const youtubeID = link.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|v\/|shorts\/))([a-zA-Z0-9_-]{11})/);
  if (!youtubeID) return { status: false, error: "Gagal mengekstrak ID video dari URL." };

  try {
    const cdnRes = await request(apiCDN, {}, 'get');
    if (!cdnRes.status) return cdnRes;
    const cdn = cdnRes.data.cdn;

    const infoRes = await request(`https://${cdn}${apiInfo}`, { url: `https://www.youtube.com/watch?v=${youtubeID[1]}` });
    if (!infoRes.status) return infoRes;
    
    const decrypted = await decryptData(infoRes.data.data);
    if (!decrypted) return { status: false, error: "Gagal mendekripsi data video." };

    const downloadRes = await request(`https://${cdn}${apiDownload}`, {
      id: youtubeID[1],
      downloadType: format === 'mp3' ? 'audio' : 'video',
      quality: format === 'mp3' ? '128' : format,
      key: decrypted.key
    });

    return {
      status: true,
      result: {
        title: decrypted.title || "Tidak diketahui",
        type: format === 'mp3' ? 'audio' : 'video',
        format: format,
        download: downloadRes.data.data.downloadUrl
      }
    };
  } catch (error) {
    return { status: false, error: error.message };
  }
}

const handler = async (m, { conn, args, command, usedPrefix }) => {
  const fkontak = {
    key: {
      participant: '0@s.whatsapp.net',
      remoteJid: '0@s.whatsapp.net',
      fromMe: false,
      id: 'Halo',
    },
    message: {
      conversation: getRandomText(),
    },
  }

  if (!args.length) {
    return conn.reply(
      m.chat,
      `🎵 Hai Kak! Mau cari lagu apa hari ini?\n\nContoh: *${usedPrefix}${command} blue bird naruto*`,
      m,
      { quoted: fkontak }
    )
  }

  let query = args.join(' ');

  try {
    await conn.sendMessage(m.chat, {
      react: { text: '🎶', key: m.key },
    })

    const search = await yts(query);
    if (!search.videos.length) throw '❌ Lagu tidak ditemukan di YouTube.';

    const top10Videos = search.videos.slice(0, 10);
    const firstVideo = search.videos[0];
    
    // --- Menampilkan Pilihan 10 Lagu dalam format produk (persis seperti di gambar) ---
    const rows = top10Videos.map((video, index) => {
      const duration = video.timestamp || '00:00';
      const description = `Durasi: ${duration} | Ditonton: ${video.views.toLocaleString()} kali`;
      
      return {
        header: `${index + 1}. ${video.title}`,
        title: video.title,
        description: description,
        id: `.ytmp3 ${video.url}`
      }
    });
    
    const thumbnailUrl = firstVideo.thumbnail;
    
    await conn.sendMessage(m.chat, {
      product: {
        productImage: { url: thumbnailUrl },
        productId: '9999999999999999',
        title: 'Hasil Pencarian YouTube',
        description: 'Pilih musik yang ingin Anda unduh',
        currencyCode: 'IDR',
        priceAmount1000: '999999999999',
        retailerId: 'ytsearch',
        url: 'https://wa.me/6285885773612',
        productImageCount: 1
      },
      businessOwnerJid: '6285885773612@s.whatsapp.net',
      caption: `🧠 *Hasil pencarian untuk:* ${query}\n\n*Silakan pilih dari daftar di bawah ini!*`,
      title: 'Daftar Lagu',
      subtitle: 'Klik tombol di bawah',
      footer: '> Nooriko Bot',
      interactiveButtons: [
        {
          name: 'single_select',
          buttonParamsJson: JSON.stringify({
            title: 'Pilih Musik',
            sections: [
              {
                title: 'Hasil Pencarian',
                highlight_label: 'Pilih Salah Satu',
                rows: rows
              }
            ]
          })
        }
      ],
      hasMediaAttachment: false
    }, { quoted: fkontak });

    // --- Mengunduh dan Kirim Audio Hasil Pertama (sebagai pesan terpisah) ---
    const ytmp3 = await downloadYouTube(firstVideo.url, 'mp3');

    if (!ytmp3.status) {
      await conn.sendMessage(m.chat, {
        react: { text: '❌', key: m.key },
      });
      return m.reply(`❌ *Gagal download audio!*`);
    }

    const captionAudio = `✅ *Berhasil mengunduh lagu!*`;

    await conn.sendMessage(
      m.chat,
      {
        audio: { url: ytmp3.result.download },
        mimetype: 'audio/mpeg',
        fileName: `${ytmp3.result.title}.mp3`,
        ptt: false,
        caption: captionAudio
      },
      { quoted: fkontak }
    )

    await conn.sendMessage(m.chat, {
      react: { text: '✅', key: m.key },
    })

  } catch (e) {
    console.error(e)
    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key },
    })
    throw `❌ Gagal mengambil audio YouTube.\n\nLog: ${e.message || e}`
  }
}

handler.help = ['play', 'musik', 'lagu', 'song'].map(v => v + ' <judul>')
handler.tags = ['downloader']
handler.command = /^(play|musik|lagu|song)$/i
handler.limit = true
handler.premium = false
handler.register = true

export default handler