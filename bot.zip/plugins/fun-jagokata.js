import fetch from 'node-fetch';

// Objek kontak dummy (Opsional)
const fkontak = {
  key: {
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast',
    fromMe: false,
    id: 'Halo',
  },
  message: {
    conversation: `📜 Kata-kata Bijak by ${global.namebot}`,
  },
};

// Fungsi untuk mendapatkan quote acak yang tidak kosong
const getRandomQuoteWithContent = (quotes) => {
    const validQuotes = quotes.filter(q => q.quote && q.author);
    if (validQuotes.length === 0) {
        return null;
    }
    const randomIndex = Math.floor(Math.random() * validQuotes.length);
    return validQuotes[randomIndex];
};

// Handler utama untuk plugin
let handler = async (m, { conn, text, usedPrefix, command }) => {
  // Pastikan pengguna menyertakan kata kunci
  if (!text) {
    return conn.reply(m.chat, `⚠️ Masukkan kata kunci untuk mencari kata bijak.\nContoh: *${usedPrefix + command} kesuksesan*`, m, { quoted: fkontak });
  }

  try {
    // Kirim reaksi '⏳' untuk menandakan sedang diproses
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    // Panggil API untuk mencari kata-kata bijak
    const url = `https://api.siputzx.my.id/api/fun/jagokata?q=${encodeURIComponent(text)}`;
    const res = await fetch(url);
    
    // Periksa status respons
    if (!res.ok) {
      throw new Error(`Gagal terhubung ke API Jagokata. Status: ${res.status}`);
    }

    const json = await res.json();

    // Periksa apakah ada data yang ditemukan
    if (!json.status || !json.data || json.data.length === 0) {
      return conn.reply(m.chat, `❌ Tidak ada kata bijak yang ditemukan untuk "${text}".`, m);
    }
    
    // Ambil quote acak yang memiliki konten lengkap
    const randomQuote = getRandomQuoteWithContent(json.data);

    // Jika tidak ada quote yang valid, berikan pesan error
    if (!randomQuote) {
        return conn.reply(m.chat, `❌ Tidak ada kata bijak yang valid ditemukan untuk "${text}".`, m);
    }

    const { quote, author, description, lifespan } = randomQuote;
    
    // Buat format pesan
    let caption = `
*"${quote}"*
    `.trim();

    // Tambahkan detail penulis jika tersedia
    if (author) {
        caption += `\n\n— *${author}*`;
    }
    if (description) {
        caption += `\n_${description}_`;
    }
    if (lifespan) {
        caption += `\n_${lifespan}_`;
    }

    // Kirim pesan teks (tanpa gambar karena tidak selalu ada)
    await conn.sendMessage(m.chat, { text: caption }, { quoted: m });

    // Kirim reaksi '✅' setelah berhasil
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error(e);
    // Kirim reaksi '❌' jika terjadi error
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    conn.reply(m.chat, `❌ Terjadi kesalahan: ${e.message}`, m);
  }
};

// Pengaturan metadata plugin
handler.help = ['jagokata'];
handler.tags = ['fun', 'internet'];
handler.command = /^(jagokata)$/i;
handler.limit = true;
handler.register = true;

export default handler;