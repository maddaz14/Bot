const handler = m => m;

handler.before = async function (m, { conn, isAdmin, isBotAdmin }) {
  if (m.isBaileys && m.fromMe) return true;
  if (!m.isGroup || !m.text) return true;

  const chat = global.db.data.chats[m.chat];
  if (!chat || !chat.antitag) return true;

  let text = m.text;
  let messageId = m.key.id;
  let participant = m.key.participant || m.sender;

  // Ambil metadata grup
  let meta;
  try {
    meta = await conn.groupMetadata(m.chat);
  } catch (e) {
    return true; // gagal ambil metadata, abaikan
  }

  // Cek apakah pesan berisi tag ke salah satu anggota grup
  let tagged = meta.participants.find(p => {
    let jid = p.id.split('@')[0];
    return text.includes(jid);
  });

  if (!tagged) return true;

  if (!isAdmin && isBotAdmin) {
    await m.reply(`🚫 *ANTI TAG*\nKamu menandai anggota grup dan pesanmu akan dihapus karena melanggar aturan.`);
    return conn.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: messageId,
        participant: participant
      }
    });
  }

  return true;
};

export default handler;