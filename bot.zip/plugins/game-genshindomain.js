import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text) {
    try {
      const list = await genshindb.domains("names", { matchCategories: true });
      return m.reply(`📜 *Daftar Domain Tersedia:*\n\n${list.join(", ")}`);
    } catch (e) {
      console.error('[DOMAIN LIST ERROR]', e);
      return m.reply('❌ Gagal mengambil daftar domain.');
    }
  }

  try {
    const result = await genshindb.domains(text);
    if (result) {
      let response = `🏯 *Domain Ditemukan: ${result.name}*\n\n`;
      response += `📝 _${result.description || "Deskripsi tidak tersedia"}_\n\n`;
      response += `📍 *Area:* ${result.area || "Tidak diketahui"}\n`;
      response += `🎚️ *Level:* ${result.level || "Tidak diketahui"}`;
      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[DOMAIN ERROR]', err);
    try {
      const available = await genshindb.domains("names", { matchCategories: true });
      return m.reply(`❌ Domain '${text}' tidak ditemukan.\n\n📜 *Domain yang tersedia:*\n${available.join(", ")}`);
    } catch (e) {
      return m.reply('⚠️ Gagal menampilkan daftar domain.');
    }
  }
};

handler.help = ['genshin-domain <nama domain>'];
handler.tags = ['game'];
handler.command = /^(genshin-domain|g-domain|gens-domain)$/i;
handler.limit = 1;
handler.register = true;

export default handler;