let handler = async (m, { conn }) => {
  if (!m.isGroup) return m.reply('❌ Hanya bisa dipakai di grup!')

  try {
    const meta = await conn.groupMetadata(m.chat)
    const me = meta.participants.find(p => p.id === m.sender || p.jid === m.sender)

    if (!me) {
      return m.reply('⚠️ Kamu tidak ditemukan di metadata grup. Coba kirim pesan dulu di grup.')
    }

    // tampilkan id dan kalau ada lid
    let teks = `👤 Info kamu di grup ini:\n`
    teks += `• WID: ${m.sender}\n`
    if (me.id && me.id !== m.sender) teks += `• Local ID: ${me.id}\n`
    if (me.jid && me.jid !== m.sender) teks += `• JID (alt): ${me.jid}\n`

    m.reply(teks)
  } catch (e) {
    m.reply('❌ Gagal ambil metadata grup!\n' + e.message)
  }
}

handler.command = /^ceklid$/i
handler.tags = ['group']
handler.help = ['ceklid']

export default handler