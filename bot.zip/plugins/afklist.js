var handler = async (m, { conn, participants }) => {
    let users = global.db.data.users;
    let list = [];

    for (let jid in users) {
        let user = users[jid];
        if (user.afk2 && user.afk2.time && user.afk2.group) {
            let name = '@' + jid.split('@')[0];
            let duration = Math.floor((Date.now() - user.afk2.time) / 1000);
            let [hours, minutes, seconds] = [
                Math.floor(duration / 3600),
                Math.floor((duration % 3600) / 60),
                duration % 60
            ];

            // Dapatkan nama grup dari metadata
            let groupName = 'Grup tidak diketahui';
            try {
                let metadata = await conn.groupMetadata(user.afk2.group);
                groupName = metadata.subject;
            } catch (e) {
                groupName = '❌ Grup keluar atau tidak ditemukan';
            }

            list.push(
`👤 Nama   : ${name}
👥 Grup   : ${groupName}
📑 Alasan : ${user.afk2.reason || "Tanpa Keterangan"}
🕒 Durasi : ${hours}j ${minutes}m ${seconds}d`);
        }
    }

    if (list.length === 0) {
        return conn.reply(m.chat, 'Tidak ada yang sedang AFK di grup manapun.', m);
    }

    conn.reply(m.chat, 
`====== [ LIST SEMUA AFK2 ] ======\n\n${list.join('\n\n')}\n\n=====================`, m, {
        mentions: list.map(v => v.match(/@[\d]+/g)).flat().filter(Boolean)
    });
};

handler.help = ['listafk2'];
handler.tags = ['main'];
handler.command = /^listafk2$/i;

export default handler;