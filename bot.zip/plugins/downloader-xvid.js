import fetch from 'node-fetch'

const handler = async (m, { conn, args, usedPrefix }) => {
    const url = args[0]
    const apiKey = 'CocoaHoto' // Ganti dengan API key Anda

    if (!url || !url.startsWith('http')) {
        const example = `${usedPrefix}xvid https://www.xvideos.com/video123456/blabla`
        return m.reply(`❗ Masukkan URL video xvideos.\n\nContoh:\n${example}`)
    }

    try {
        const res = await fetch(`https://api.betabotz.eu.org/api/download/xvideosdl?url=${encodeURIComponent(url)}&apikey=${apiKey}`)
        const json = await res.json()

        if (!json || !json.status || !json.result?.url) {
            throw new Error('Tidak ada hasil atau URL tidak valid.')
        }

        const result = json.result

        const caption = `🔞 *XVideos Downloader*\n\n` +
            `🎬 Judul: *${result.title}*\n` +
            `👁️ Views: ${result.views}\n` +
            `👍 Like: ${result.like_count}\n` +
            `👎 Dislike: ${result.dislike_count}\n\n` +
            `_Sedang mengirim videonya..._`

        await conn.reply(m.chat, caption, m)

        await conn.sendVideo(m.chat, result.url, `🎬 *${result.title}*`, m)

    } catch (err) {
        console.error('❌ Error Xvid Video Download:', err)
        await conn.reply(m.chat, '❌ Gagal mengirim video. Bisa jadi terlalu besar atau link mati.', m)
    }
}

handler.command = ['xvid']
handler.tags = ['downloader', 'nsfw']
handler.help = ['xvid <url>']
handler.private = false
handler.premium = true 

export default handler