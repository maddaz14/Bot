let handler = async (m, { conn, text, args, participants, isOwner }) => {
    if (!isOwner) return m.reply('❌ Hanya owner yang bisa menggunakan perintah ini.')

    if (!args[0]) return m.reply(`Masukkan jumlah.\nContoh: *.addduit 10000 @user*`);

    let jumlah = parseInt(args[0]?.replace(/[^0-9]/g, ''))
    if (!jumlah || isNaN(jumlah)) return m.reply(`Jumlah tidak valid.\nContoh: *.addduit 10000 @user*`)
    if (jumlah < 1) return m.reply(`Jumlah minimal adalah 1`)

    let who;
    let debug = [];

    // 1. Jika tag
    if (m.isGroup && m.mentionedJid?.length) {
        who = m.mentionedJid[0];
        debug.push('Source: Mention');
    }

    // 2. Jika reply
    else if (m.quoted?.sender) {
        who = m.quoted.sender;
        debug.push('Source: Reply');
    }

    // 3. Nomor dari teks (misal: .addduit 10000 628xxx)
    else if (args[1]) {
        let input = args[1].replace(/\D/g, '');
        if (input.startsWith('0')) input = '62' + input.slice(1);
        if (input.length < 9 || input.length > 15) return m.reply('❌ Format nomor salah.');
        who = input + '@s.whatsapp.net';
        debug.push('Source: Raw Number');
    }

    // 4. Kalau tidak ada target, pakai pengirim
    else {
        who = m.sender;
        debug.push('Source: Default Sender');
    }

    // 5. Resolve dari @lid (jika ada)
    if (who.endsWith('@lid') && m.isGroup) {
        if (!participants) participants = (await conn.groupMetadata(m.chat)).participants;
        let resolved = participants.find(p => p.id === who || p.jid === who);
        if (resolved?.jid?.endsWith('@s.whatsapp.net')) {
            who = resolved.jid;
            debug.push('Resolved @lid → JID');
        } else {
            return m.reply('⚠️ Tidak bisa resolve JID dari @lid. Suruh user kirim pesan dulu.');
        }
    }

    // Pastikan user ada di database
    if (!global.db.data.users[who]) global.db.data.users[who] = { eris: 0 };
    let user = global.db.data.users[who];
    user.eris = (user.eris || 0) + jumlah;

    await conn.reply(m.chat, `✅ Berhasil menambahkan Rp.${jumlah.toLocaleString()} ke @${who.split('@')[0]}.\nTotal saldo: Rp.${user.eris.toLocaleString()}`, m, {
        mentions: [who]
    });

    // Debug log (optional)
    console.log('\n[DEBUG addduit]');
    console.log('Target:', who);
    console.log('Jumlah:', jumlah);
    console.log('Debug:', debug.join(' → '));
    console.log('-------------------------\n');
};

handler.help = ['addduit <jumlah> [@user|nomor|reply]'];
handler.tags = ['owner'];
handler.command = /^addduit$/i;
handler.owner = true;

export default handler;