import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
    conn.autoAI = conn.autoAI ?? false

    if (!text) throw `.autoai on atau off`

    if (text === 'on') {
        if (conn.autoAI) return m.reply('Auto AI sudah aktif sebelumnya')
        conn.autoAI = true
        m.reply('✅ Auto AI telah diaktifkan.')
    } else if (text === 'off') {
        if (!conn.autoAI) return m.reply('Auto AI sudah nonaktif')
        conn.autoAI = false
        m.reply('❌ Auto AI telah dimatikan.')
    } else {
        m.reply('Gunakan perintah: .autoai on atau .autoai off')
    }
}

handler.before = async (m, { conn }) => {
    if (m.isBaileys && m.fromMe) return
    if (!m.text) return
    if (!conn.autoAI) return
    if (/^[.\#!\/\\]/.test(m.text)) return

    // Throttle agar tidak spam
    conn._lastAutoAI = conn._lastAutoAI ?? {}
    if (Date.now() - (conn._lastAutoAI[m.chat] || 0) < 3000) return
    conn._lastAutoAI[m.chat] = Date.now()

    try {
        let res = await fetch(`https://api.ubed.my.id/ai/ubed2?apikey=alhamdulillah&text=${encodeURIComponent(m.text)}`)
        if (!res.ok) throw new Error('Gagal mengambil respon dari API ubed.')

        let json = await res.json()
        if (!json.status || !json.result) throw new Error('Respon tidak valid.')

        await m.reply(json.result)
    } catch (err) {
        console.error(err)
        await m.reply('⚠️ Terjadi kesalahan saat mengambil respon AI.')
    }
}

handler.command = ['autoai']
handler.tags = ['ai']
handler.help = ['autoai on', 'autoai off']

export default handler