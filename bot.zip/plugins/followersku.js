const followersHandler = async (m, { conn }) => {
  global.db.data.ubedAccounts ??= {};
  global.db.data.ubedSessions ??= {};

  if (!global.db.data.ubedSessions[m.sender]) {
    return m.reply('❌ Kamu belum login ke *ubed Media*.');
  }

  const akun = global.db.data.ubedAccounts[m.sender];
  if (!akun) {
    return m.reply('❌ Akun tidak ditemukan.');
  }

  const followerCount = Array.isArray(akun.followers) ? akun.followers.length : 0;

  m.reply(`📊 Jumlah Followers kamu: ${followerCount}`);
};

followersHandler.command = /^followersfuxxy$/i;
followersHandler.tags = ['media'];
followersHandler.help = ['followersfuxxy'];

export default followersHandler;