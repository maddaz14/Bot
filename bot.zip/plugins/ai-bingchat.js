import axios from 'axios';

const handler = async (m, { conn, text, usedPrefix, command }) => {
    // Pastikan ada teks query yang diberikan oleh pengguna
    if (!text) {
        throw `Halo! Ada yang bisa saya bantu?\n\nContoh: *${usedPrefix}${command} Apa itu AI?*`;
    }

    // Ambil domain dan API Key Maelyn dari global.maelyn di config.js
    const maelynDomain = global.maelyn.domain;
    const maelynApiKey = global.maelyn.key;

    // Lakukan validasi dasar untuk memastikan konfigurasi ada
    if (!maelynDomain || !maelynApiKey) {
        throw 'API Key atau Domain Maelyn untuk Bing Chat belum diatur di config.js! Mohon hubungi pemilik bot.';
    }

    await conn.sendMessage(m.chat, { react: { text: '🍏', key: m.key } }); // Reaksi loading

    try {
        const apiUrl = `${maelynDomain}/api/bing/chat?q=${encodeURIComponent(text)}&apikey=${maelynApiKey}`;
        const response = await axios.get(apiUrl);
        const { status, result, code } = response.data;

        if (status === 'Success' && code === 200 && result?.choices?.[0]?.message?.content) {
            const bingResponse = result.choices[0].message.content;
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); // Reaksi sukses
            m.reply(bingResponse);
        } else {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }); // Reaksi gagal
            m.reply(`❌ Gagal mendapatkan respons dari Bing Chat. Respon API: ${JSON.stringify(response.data)}`);
        }
    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }); // Reaksi error
        m.reply(`Terjadi kesalahan saat menghubungi Bing Chat API: ${e.message}`);
    }
};

handler.help = ['bingchat', 'bingai'];
handler.tags = ['ai'];
handler.command = /^(bingchat|bingai)$/i; // Menggunakan regex untuk beberapa alias
handler.limit = true; 
handler.premium = false; 

export default handler;