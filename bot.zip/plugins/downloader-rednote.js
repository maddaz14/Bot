// Plugin: .rednote
// Dibuat oleh ubed - https://siputzx.my.id

import fetch from 'node-fetch';

const handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `*Contoh:* ${usedPrefix + command} https://xhslink.com/a/J5HkEShsO6t4`;

  try {
    // Reaksi saat memproses
    await conn.sendReact(m.chat, '⏳', m.key);

    const api = `https://api.siputzx.my.id/api/d/rednote?url=${encodeURIComponent(args[0])}`;
    const res = await fetch(api);
    const json = await res.json();

    if (!json.status || !json.data) throw '*Gagal mengambil data Rednote!*';

    const {
      title = 'Tidak ada judul',
      desc = '',
      engagement = {},
      images = []
    } = json.data;

    const caption = `
📌 *Judul:* ${title}
📝 *Deskripsi:* ${desc || '-'}
❤️ *Suka:* ${engagement.likes || '-'}
💬 *Komentar:* ${engagement.comments || '-'}
📥 *Disimpan:* ${engagement.collects || '-'}
`.trim();

    if (images.length > 0) {
      let img = images[0];
      if (img.startsWith('//')) img = 'https:' + img;

      await conn.sendFile(m.chat, img, 'rednote.jpg', caption, m);
    } else {
      await conn.sendMessage(m.chat, { text: caption, quoted: m });
    }

    await conn.sendReact(m.chat, '✅', m.key);
  } catch (e) {
    console.error(e);
    await conn.sendReact(m.chat, '❌', m.key);
    throw '*Terjadi kesalahan saat mengambil postingan Rednote.*';
  }
};

handler.help = ['rednote'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^rednote$/i;

export default handler;