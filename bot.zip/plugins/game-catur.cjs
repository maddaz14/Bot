// Dibuat oleh UBED - Dilarang keras menyalin tanpa izin!
// Plugin untuk permainan catur antara dua pemain.

// UBED_WM_DONT_TOUCH_START
const UBED_WM_TAG = "UBED_WM_DONT_TOUCH"; // UBED_WM_DONT_TOUCH - Tanda tangan watermark
const UBED_VALIDATION_STRING = "ubed_secure_hash_2025_abcdef123456_CHESS_CANVAS_V2_FIXED"; // UBED_WM_DONT_TOUCH - String validasi unik untuk CHESS_CANVAS_V2_FIXED

function validateUbedWm(codeString) { // UBED_WM_DONT_TOUCH - Fungsi validasi
    const expectedCount = 5; // UBED_WM_DONT_TOUCH - Jumlah minimal tanda tangan yang diharapkan
    let foundCount = 0; // UBED_WM_DONT_TOUCH
    const lines = codeString.split('\n'); // UBED_WM_DONT_TOUCH

    for (const line of lines) { // UBED_WM_DONT_TOUCH
        if (line.includes(UBED_WM_TAG)) { // UBED_WM_DONT_TOUCH
            foundCount++; // UBED_WM_DONT_TOUCH
        }
    }

    if (foundCount < expectedCount || !codeString.includes(UBED_VALIDATION_STRING)) { // UBED_WM_DONT_TOUCH
        throw new Error("UBED_WM_ERROR: Kode plugin terdeteksi dimodifikasi secara ilegal. Harap gunakan kode asli."); // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH
} // UBED_WM_DONT_TOUCH

// Baca file ini sendiri untuk validasi saat dimuat (ini sangat tidak efisien dan rentan!)
try { // UBED_WM_DONT_TOUCH
    const fs = require('fs'); // UBED_WM_DONT_TOUCH
    const path = require('path'); // UBED_WM_DONT_TOUCH
    const currentFilePath = __filename; // UBED_WM_DONT_TOUCH
    const codeContent = fs.readFileSync(currentFilePath, 'utf8'); // UBED_WM_DONT_TOUCH
    validateUbedWm(codeContent); // UBED_WM_DONT_TOUCH
} catch (e) { // UBED_WM_DONT_TOUCH
    console.error("UBED_WM_FATAL_ERROR: Gagal memverifikasi kode. Plugin mungkin telah dimodifikasi atau rusak. " + e.message); // UBED_WM_DONT_TOUCH
    process.exit(1); // UBED_WM_DONT_TOUCH - Menghentikan proses bot
} // UBED_WM_DONT_TOUCH
// UBED_WM_DONT_TOUCH_END

const { Chess } = require('chess.js'); // UBED_WM_DONT_TOUCH - Menggunakan require
const { createCanvas, loadImage, registerFont } = require('canvas'); // UBED_WM_DONT_TOUCH - Menggunakan canvas
const axios = require('axios'); // UBED_WM_DONT_TOUCH - Untuk mengunduh gambar bidak

// UBED_WM_DONT_TOUCH - Objek fkontak untuk tampilan pesan yang dikutip
const fkontak = { // UBED_WM_DONT_TOUCH
    "key": { // UBED_WM_DONT_TOUCH
        "participant": '0@s.whatsapp.net', // UBED_WM_DONT_TOUCH
        "remoteJid": "0@s.whatsapp.net", // UBED_WM_DONT_TOUCH
        "fromMe": false, // UBED_WM_DONT_TOUCH
        "id": "Halo", // UBED_WM_DONT_TOUCH
    }, // UBED_WM_DONT_TOUCH
    "message": { // UBED_WM_DONT_TOUCH
        "conversation": `♟️ Game Catur ${global.namebot || 'Bot'} ✨`, // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH
}; // UBED_WM_DONT_TOUCH

// UBED_WM_DONT_TOUCH - Ukuran papan dan bidak
const BOARD_SIZE = 8; // UBED_WM_DONT_TOUCH
const CELL_SIZE = 60; // UBED_WM_DONT_TOUCH - Ukuran setiap kotak (piksel)
const PIECE_SIZE = 56; // UBED_WM_DONT_TOUCH - Ukuran bidak (sedikit lebih kecil dari kotak)
const PADDING = 20; // UBED_WM_DONT_TOUCH - Padding untuk koordinat
const BOARD_PIXEL_SIZE = BOARD_SIZE * CELL_SIZE; // UBED_WM_DONT_TOUCH
const TOTAL_CANVAS_SIZE = BOARD_PIXEL_SIZE + PADDING * 2; // UBED_WM_DONT_TOUCH

// UBED_WM_DONT_TOUCH - Warna papan catur
const LIGHT_SQUARE = '#f0d9b5'; // UBED_WM_DONT_TOUCH
const DARK_SQUARE = '#b58863'; // UBED_WM_DONT_TOUCH

// UBED_WM_DONT_TOUCH - URL gambar bidak (dari Catbox sesuai permintaan user)
const PIECE_IMAGE_URLS = { // UBED_WM_DONT_TOUCH
    'k': 'https://files.catbox.moe/dnimgs.jpeg', // UBED_WM_DONT_TOUCH - Raja hitam
    'q': 'https://files.catbox.moe/o675lc.jpeg', // UBED_WM_DONT_TOUCH - Menteri hitam
    'b': 'https://files.catbox.moe/8rnmo2.jpeg', // UBED_WM_DONT_TOUCH - Gajah hitam
    'n': 'https://files.catbox.moe/a1dnvo.jpeg', // UBED_WM_DONT_TOUCH - Kuda hitam
    'r': 'https://files.catbox.moe/d2ppss.jpeg', // UBED_WM_DONT_TOUCH - Benteng hitam
    'p': 'https://files.catbox.moe/ylerdm.jpeg', // UBED_WM_DONT_TOUCH - Pion hitam
    'K': 'https://files.catbox.moe/wzmqh6.jpeg', // UBED_WM_DONT_TOUCH - Raja putih
    'Q': 'https://files.catbox.moe/q8ks8b.jpeg', // UBED_WM_DONT_TOUCH - Menteri putih
    'B': 'https://files.catbox.moe/din207.jpeg', // UBED_WM_DONT_TOUCH - Gajah putih
    'N': 'https://files.catbox.moe/nne4t0.jpeg', // UBED_WM_DONT_TOUCH - Kuda putih
    'R': 'https://files.catbox.moe/u67dbr.jpeg', // UBED_WM_DONT_TOUCH - Benteng putih
    'P': 'https://files.catbox.moe/k24pny.jpeg'  // UBED_WM_DONT_TOUCH - Pion putih
}; // UBED_WM_DONT_TOUCH

let loadedPieceImages = {}; // UBED_WM_DONT_TOUCH - Cache gambar bidak
let areImagesLoaded = false; // UBED_WM_DONT_TOUCH - Status pemuatan gambar

// UBED_WM_DONT_TOUCH - Fungsi untuk memuat semua gambar bidak
async function loadAllPieceImages() { // UBED_WM_DONT_TOUCH
    if (areImagesLoaded) return; // UBED_WM_DONT_TOUCH - Jangan muat ulang jika sudah dimuat

    console.log('[CHESS CANVAS] Starting to load chess piece images...'); // UBED_WM_DONT_TOUCH
    const loadPromises = Object.keys(PIECE_IMAGE_URLS).map(async (pieceKey) => { // UBED_WM_DONT_TOUCH
        try { // UBED_WM_DONT_TOUCH
            const response = await axios.get(PIECE_IMAGE_URLS[pieceKey], { responseType: 'arraybuffer' }); // UBED_WM_DONT_TOUCH
            loadedPieceImages[pieceKey] = await loadImage(Buffer.from(response.data)); // UBED_WM_DONT_TOUCH
            console.log(`[CHESS CANVAS] Successfully loaded: ${pieceKey}`); // UBED_WM_DONT_TOUCH
        } catch (error) { // UBED_WM_DONT_TOUCH
            console.error(`[CHESS CANVAS] Failed to load piece image for ${pieceKey} from ${PIECE_IMAGE_URLS[pieceKey]}:`, error.message); // UBED_WM_DONT_TOUCH
            loadedPieceImages[pieceKey] = null; // UBED_WM_DONT_TOUCH - Set ke null jika gagal
        } // UBED_WM_DONT_TOUCH
    }); // UBED_WM_DONT_TOUCH
    await Promise.all(loadPromises); // UBED_WM_DONT_TOUCH
    areImagesLoaded = true; // UBED_WM_DONT_TOUCH
    console.log('[CHESS CANVAS] All chess piece images load attempt finished.'); // UBED_WM_DONT_TOUCH
} // UBED_WM_DONT_TOUCH

// UBED_WM_DONT_TOUCH - Muat gambar bidak saat startup
loadAllPieceImages().catch(e => console.error('Error during initial chess piece image loading:', e)); // UBED_WM_DONT_TOUCH

// UBED_WM_DONT_TOUCH - Kelas ChessGame untuk menggambar papan
class ChessGame { // UBED_WM_DONT_TOUCH
    constructor() { // UBED_WM_DONT_TOUCH
        this.boardSize = BOARD_SIZE; // UBED_WM_DONT_TOUCH
        this.cellSize = CELL_SIZE; // UBED_WM_DONT_TOUCH
        this.pieceSize = PIECE_SIZE; // UBED_WM_DONT_TOUCH
        this.padding = PADDING; // UBED_WM_DONT_TOUCH
        this.totalCanvasSize = TOTAL_CANVAS_SIZE; // UBED_WM_DONT_TOUCH

        // UBED_WM_DONT_TOUCH - Register font jika ada (opsional)
        // try { registerFont('./src/font/Roboto-Regular.ttf', { family: 'Roboto' }); } catch (e) { console.warn('Font Roboto not found, using default.'); }
    } // UBED_WM_DONT_TOUCH

    async drawChessBoard(fen, flipBoard = false) { // UBED_WM_DONT_TOUCH
        const chess = new Chess(fen); // UBED_WM_DONT_TOUCH
        const board = chess.board(); // UBED_WM_DONT_TOUCH

        const canvas = createCanvas(this.totalCanvasSize, this.totalCanvasSize); // UBED_WM_DONT_TOUCH
        const ctx = canvas.getContext('2d'); // UBED_WM_DONT_TOUCH

        // UBED_WM_DONT_TOUCH - Background putih
        ctx.fillStyle = '#ffffff'; // UBED_WM_DONT_TOUCH
        ctx.fillRect(0, 0, this.totalCanvasSize, this.totalCanvasSize); // UBED_WM_DONT_TOUCH

        ctx.font = '12px Arial'; // UBED_WM_DONT_TOUCH
        ctx.textAlign = 'center'; // UBED_WM_DONT_TOUCH
        ctx.textBaseline = 'middle'; // UBED_WM_DONT_TOUCH
        ctx.fillStyle = '#333333'; // UBED_WM_DONT_TOUCH

        // UBED_WM_DONT_TOUCH - Menggambar papan dan bidak
        for (let row = 0; row < this.boardSize; row++) { // UBED_WM_DONT_TOUCH
            for (let col = 0; col < this.boardSize; col++) { // UBED_WM_DONT_TOUCH
                const x = col * this.cellSize + this.padding; // UBED_WM_DONT_TOUCH
                const y = row * this.cellSize + this.padding; // UBED_WM_DONT_TOUCH

                const isLightSquare = (row + col) % 2 === 0; // UBED_WM_DONT_TOUCH
                ctx.fillStyle = isLightSquare ? LIGHT_SQUARE : DARK_SQUARE; // UBED_WM_DONT_TOUCH
                ctx.fillRect(x, y, this.cellSize, this.cellSize); // UBED_WM_DONT_TOUCH

                let displayRow = row; // UBED_WM_DONT_TOUCH
                let displayCol = col; // UBED_WM_DONT_TOUCH

                if (flipBoard) { // UBED_WM_DONT_TOUCH
                    displayRow = this.boardSize - 1 - row; // UBED_WM_DONT_TOUCH
                    displayCol = this.boardSize - 1 - col; // UBED_WM_DONT_TOUCH
                } // UBED_WM_DONT_TOUCH

                const piece = board[displayRow][displayCol]; // UBED_WM_DONT_TOUCH
                if (piece) { // UBED_WM_DONT_TOUCH
                    // UBED_WM_DONT_TOUCH - Chess.js piece.type adalah 'p', 'n', 'b', 'r', 'q', 'k'
                    // UBED_WM_DONT_TOUCH - Chess.js piece.color adalah 'w' atau 'b'
                    const pieceKey = piece.color === 'w' ? piece.type.toUpperCase() : piece.type.toLowerCase(); // UBED_WM_DONT_TOUCH
                    const pieceImage = loadedPieceImages[pieceKey]; // UBED_WM_DONT_TOUCH

                    if (pieceImage) { // UBED_WM_DONT_TOUCH
                        ctx.drawImage(pieceImage, x + (this.cellSize - this.pieceSize) / 2, y + (this.cellSize - this.pieceSize) / 2, this.pieceSize, this.pieceSize); // UBED_WM_DONT_TOUCH
                    } else { // UBED_WM_DONT_TOUCH
                        console.warn(`[CHESS CANVAS] Piece image not found in cache for key: ${pieceKey}. Check loading.`); // UBED_WM_DONT_TOUCH
                        // UBED_WM_DONT_TOUCH - Opsional: gambar placeholder atau teks
                        ctx.fillStyle = 'red'; // UBED_WM_DONT_TOUCH
                        ctx.fillText('?', x + this.cellSize / 2, y + this.cellSize / 2); // UBED_WM_DONT_TOUCH
                    } // UBED_WM_DONT_TOUCH
                } // UBED_WM_DONT_TOUCH

                // UBED_WM_DONT_TOUCH - Menggambar koordinat (ranks dan files)
                if (col === 0) { // UBED_WM_DONT_TOUCH - Ranks (nomor baris)
                    ctx.fillStyle = isLightSquare ? DARK_SQUARE : LIGHT_SQUARE; // UBED_WM_DONT_TOUCH
                    ctx.fillText(
                        flipBoard ? (row + 1).toString() : (this.boardSize - row).toString(), // UBED_WM_DONT_TOUCH
                        this.padding / 2, // UBED_WM_DONT_TOUCH
                        y + this.cellSize / 2 // UBED_WM_DONT_TOUCH
                    ); // UBED_WM_DONT_TOUCH
                } // UBED_WM_DONT_TOUCH
                if (row === this.boardSize - 1) { // UBED_WM_DONT_TOUCH - Files (huruf kolom)
                    ctx.fillStyle = isLightSquare ? DARK_SQUARE : LIGHT_SQUARE; // UBED_WM_DONT_TOUCH
                    ctx.fillText(
                        flipBoard ? String.fromCharCode(97 + (this.boardSize - 1 - col)) : String.fromCharCode(97 + col), // UBED_WM_DONT_TOUCH
                        x + this.cellSize / 2, // UBED_WM_DONT_TOUCH
                        this.totalCanvasSize - this.padding / 2 // UBED_WM_DONT_TOUCH
                    ); // UBED_WM_DONT_TOUCH
                } // UBED_WM_DONT_TOUCH
            } // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        
        return canvas.toBuffer('image/png'); // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH
} // UBED_WM_DONT_TOUCH

// UBED_WM_DONT_TOUCH - Kelas GameSession
class GameSession { // UBED_WM_DONT_TOUCH
    constructor(id, sMsg) { // UBED_WM_DONT_TOUCH
        this.id = id; // UBED_WM_DONT_TOUCH
        this.players = []; // UBED_WM_DONT_TOUCH - Array of player JIDs
        this.game = new ChessGame(); // UBED_WM_DONT_TOUCH
        this.sendMsg = sMsg; // UBED_WM_DONT_TOUCH - Simpan conn di GameSession
    } // UBED_WM_DONT_TOUCH
} // UBED_WM_DONT_TOUCH

// UBED_WM_DONT_TOUCH - Handler untuk bot
let handler = async (m, { conn, args, usedPrefix, command }) => { // UBED_WM_DONT_TOUCH
    // UBED_WM_DONT_TOUCH - Validasi watermark di awal handler juga
    try { // UBED_WM_DONT_TOUCH
        const fs = require('fs'); // UBED_WM_DONT_TOUCH
        const path = require('path'); // UBED_WM_DONT_TOUCH
        const currentFilePath = __filename; // UBED_WM_DONT_TOUCH
        const codeContent = fs.readFileSync(currentFilePath, 'utf8'); // UBED_WM_DONT_TOUCH
        validateUbedWm(codeContent + UBED_VALIDATION_STRING); // UBED_WM_DONT_TOUCH - Menambahkan string validasi
    } catch (e) { // UBED_WM_DONT_TOUCH
        return conn.reply(m.chat, "UBED_WM_ERROR_RUNTIME: Kode plugin telah dimodifikasi secara ilegal. Plugin tidak dapat berfungsi.", m); // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH

    const sendReaction = async (emoji) => { // UBED_WM_DONT_TOUCH
        await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }); // UBED_WM_DONT_TOUCH
    }; // UBED_WM_DONT_TOUCH

    const key = m.chat; // UBED_WM_DONT_TOUCH
    conn.chess = conn.chess || {}; // UBED_WM_DONT_TOUCH
    let chessData = conn.chess[key] || { // UBED_WM_DONT_TOUCH
        gameData: null,    // UBED_WM_DONT_TOUCH - { status: 'waiting'/'ready'/'playing', black: jid, white: jid, players: [] }
        fen: null,         // UBED_WM_DONT_TOUCH - FEN string
        currentTurn: null, // UBED_WM_DONT_TOUCH - JID pemain yang sedang giliran
        msg: null,         // UBED_WM_DONT_TOUCH - Object pesan game terakhir dari bot untuk quoted reply
        hasJoined: []      // UBED_WM_DONT_TOUCH - Array of JIDs yang sudah bergabung (untuk tampilan)
    }; // UBED_WM_DONT_TOUCH
    conn.chess[key] = chessData; // UBED_WM_DONT_TOUCH

    const { gameData, fen, currentTurn, hasJoined, msg } = chessData; // UBED_WM_DONT_TOUCH
    const feature = args[0]?.toLowerCase(); // UBED_WM_DONT_TOUCH

    // UBED_WM_DONT_TOUCH - Helper function to send the chess board image (menggunakan canvas)
    const sendChessBoard = async (chatId, currentFen, turnJid, gameWhiteJid, gameBlackJid, messageText, quotedMessage) => { // UBED_WM_DONT_TOUCH
        await sendReaction("⏳"); // UBED_WM_DONT_TOUCH - Reaksi loading saat menggambar
        await conn.sendPresenceUpdate('composing', chatId); // UBED_WM_DONT_TOUCH

        // UBED_WM_DONT_TOUCH - Pastikan gambar bidak sudah dimuat sebelum menggambar
        if (!areImagesLoaded) { // UBED_WM_DONT_TOUCH
            console.log('[CHESS CANVAS] Images not fully loaded, attempting to load again...'); // UBED_WM_DONT_TOUCH
            await loadAllPieceImages(); // UBED_WM_DONT_TOUCH
            if (!areImagesLoaded) { // UBED_WM_DONT_TOUCH
                await sendReaction("❌"); // UBED_WM_DONT_TOUCH
                await conn.reply(chatId, `❌ *Maaf, Kak!* Gambar bidak catur gagal dimuat. Coba lagi nanti atau hubungi pengembang bot.`, quotedMessage, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
                throw new Error("Chess piece images could not be loaded."); // UBED_WM_DONT_TOUCH
            } // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH

        const chessGameInstance = new ChessGame(); // UBED_WM_DONT_TOUCH - Membuat instance ChessGame
        chessGameInstance.sendMsg = conn; // UBED_WM_DONT_TOUCH - Menetapkan conn ke ChessGameInstance
        const isBlackTurnView = turnJid === gameBlackJid; // UBED_WM_DONT_TOUCH
        let boardBuffer; // UBED_WM_DONT_TOUCH
        try { // UBED_WM_DONT_TOUCH
            boardBuffer = await chessGameInstance.drawChessBoard(currentFen, isBlackTurnView); // UBED_WM_DONT_TOUCH
        } catch (drawError) { // UBED_WM_DONT_TOUCH
            console.error('[ERROR] Gagal menggambar papan catur dengan canvas:', drawError); // UBED_WM_DONT_TOUCH
            await sendReaction("❌"); // UBED_WM_DONT_TOUCH
            await conn.reply(chatId, `❌ *Maaf, Kak!* Gagal membuat gambar papan catur. Mungkin ada masalah teknis. Error: ${drawError.message}`, quotedMessage, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
            throw drawError; // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH

        let sentMsg; // UBED_WM_DONT_TOUCH
        try { // UBED_WM_DONT_TOUCH
            // UBED_WM_DONT_TOUCH - Hapus pesan papan lama jika ada
            if (msg && msg.key) { // UBED_WM_DONT_TOUCH
                try { await conn.sendMessage(chatId, { delete: msg.key }); } catch (delErr) { console.warn('Failed to delete old chess board message:', delErr.message); } // UBED_WM_DONT_TOUCH
            } // UBED_WM_DONT_TOUCH

            sentMsg = await conn.sendMessage(chatId, { // UBED_WM_DONT_TOUCH
                image: boardBuffer, // UBED_WM_DONT_TOUCH
                caption: messageText, // UBED_WM_DONT_TOUCH
                mentions: [turnJid].filter(Boolean), // UBED_WM_DONT_TOUCH
            }, { quoted: quotedMessage || fkontak }); // UBED_WM_DONT_TOUCH
            await sendReaction("✅"); // UBED_WM_DONT_TOUCH
        } catch (sendError) { // UBED_WM_DONT_TOUCH
            console.error('[ERROR] Gagal mengirim papan catur:', sendError); // UBED_WM_DONT_TOUCH
            await sendReaction("❌"); // UBED_WM_DONT_TOUCH
            await conn.reply(chatId, `❌ *Maaf, Kak!* Gagal mengirim gambar papan catur. Mungkin ada masalah koneksi. Error: ${sendError.message}`, quotedMessage, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
            throw sendError; // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        return sentMsg; // UBED_WM_DONT_TOUCH
    }; // UBED_WM_DONT_TOUCH

    // UBED_WM_DONT_TOUCH - Perintah DELETE
    if (feature === 'delete') { // UBED_WM_DONT_TOUCH
        if (!gameData) { // UBED_WM_DONT_TOUCH
            await sendReaction("🤷‍♂️"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, '🤷‍♂️ *Tidak ada permainan catur yang sedang berlangsung di chat ini untuk dihentikan.*', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        delete conn.chess[key]; // UBED_WM_DONT_TOUCH
        await sendReaction("🏳️"); // UBED_WM_DONT_TOUCH
        return conn.reply(m.chat, '🏳️ *Permainan catur dihentikan.*', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH

    // UBED_WM_DONT_TOUCH - Perintah CREATE
    if (feature === 'create') { // UBED_WM_DONT_TOUCH
        if (gameData && gameData.status !== 'waiting') { // UBED_WM_DONT_TOUCH
            await sendReaction("⚠️"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, '⚠️ *Permainan catur sudah dimulai!* Jika ingin memulai yang baru, gunakan `' + usedPrefix + command + ' delete` dulu ya.', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        if (gameData && gameData.status === 'waiting') { // UBED_WM_DONT_TOUCH
            await sendReaction("⏳"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, '⏳ *Permainan sudah dibuat dan sedang menunggu pemain lain untuk bergabung.* Gunakan `' + usedPrefix + command + ' join` untuk bergabung.', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH

        chessData.gameData = { status: 'waiting', players: [], black: null, white: null }; // UBED_WM_DONT_TOUCH
        chessData.hasJoined = []; // UBED_WM_DONT_TOUCH
        chessData.fen = new Chess().fen(); // UBED_WM_DONT_TOUCH - Inisialisasi FEN baru untuk game baru
        console.log(`[DEBUG CHESS] New game created. Initial FEN: ${chessData.fen}`); // UBED_WM_DONT_TOUCH
        await sendReaction("🎮"); // UBED_WM_DONT_TOUCH
        return conn.reply(m.chat, `🎮 *Permainan catur dimulai!*\n\nSilakan gunakan *${usedPrefix}${command} join* untuk bergabung.\n\n> © ${global.namebot || 'Bot'} ${new Date().getFullYear()} ✨`, m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH

    // UBED_WM_DONT_TOUCH - Perintah JOIN
    if (feature === 'join') { // UBED_WM_DONT_TOUCH
        const senderId = m.sender; // UBED_WM_DONT_TOUCH
        if (!gameData || gameData.status === 'playing') { // UBED_WM_DONT_TOUCH
            await sendReaction("🤷‍♂️"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, `⚠️ *Tidak ada permainan catur yang sedang menunggu untuk bergabung.* Gunakan *${usedPrefix}${command} create* untuk memulai yang baru.`, m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        if (gameData.players.includes(senderId)) { // UBED_WM_DONT_TOUCH
            await sendReaction("🙅‍♂️"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, '🙅‍♂️ *Anda sudah bergabung dalam permainan ini!*', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        if (gameData.players.length >= 2) { // UBED_WM_DONT_TOUCH
            await sendReaction("👥"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, '👥 *Pemain sudah mencukupi!* Permainan sudah siap dimulai. Silakan gunakan `' + usedPrefix + command + ' start`.', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH

        gameData.players.push(senderId); // UBED_WM_DONT_TOUCH
        hasJoined.push(senderId); // UBED_WM_DONT_TOUCH

        if (gameData.players.length === 2) { // UBED_WM_DONT_TOUCH
            gameData.status = 'ready'; // UBED_WM_DONT_TOUCH
            const [player1, player2] = gameData.players; // UBED_WM_DONT_TOUCH
            const [black, white] = Math.random() < 0.5 ? [player2, player1] : [player1, player2]; // UBED_WM_DONT_TOUCH
            gameData.black = black; // UBED_WM_DONT_TOUCH
            gameData.white = white; // UBED_WM_DONT_TOUCH
            chessData.currentTurn = white; // UBED_WM_DONT_TOUCH - Putih selalu mulai duluan

            const blackName = await conn.getName(black) || black.split('@')[0]; // UBED_WM_DONT_TOUCH
            const whiteName = await conn.getName(white) || white.split('@')[0]; // UBED_WM_DONT_TOUCH

            await sendReaction("🙌"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, `🙌 *Pemain yang telah bergabung:*\n${hasJoined.map(playerId => `- @${conn.getName(playerId) || playerId.split('@')[0]}`).join('\n')}\n\n*Hitam:* @${blackName}\n*Putih:* @${whiteName}\n\nSilakan gunakan *${usedPrefix}${command} start* untuk memulai permainan!\n\n> © ${global.namebot || 'Bot'} ${new Date().getFullYear()} ✨`, m, { mentions: hasJoined, quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } else { // UBED_WM_DONT_TOUCH
            await sendReaction("🙋‍♂️"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, `🙋‍♂️ *Anda telah bergabung dalam permainan catur!* Menunggu pemain lain untuk bergabung.`, m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH

    // UBED_WM_DONT_TOUCH - Perintah START
    if (feature === 'start') { // UBED_WM_DONT_TOUCH
        if (!gameData || gameData.status !== 'ready') { // UBED_WM_DONT_TOUCH
            await sendReaction("⚠️"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, '⚠️ *Tidak dapat memulai permainan.* Pastikan sudah ada dua pemain bergabung (`' + usedPrefix + command + ' join`).', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        if (m.sender !== gameData.white && m.sender !== gameData.black) { // UBED_WM_DONT_TOUCH
             await sendReaction("🚫"); // UBED_WM_DONT_TOUCH
             return conn.reply(m.chat, '🚫 *Anda bukan pemain dalam sesi ini.* Hanya pemain yang bisa memulai.', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        
        gameData.status = 'playing'; // UBED_WM_DONT_TOUCH
        // UBED_WM_DONT_TOUCH - Pastikan FEN diinisialisasi dari Chess.js untuk kevalidan
        chessData.fen = new Chess().fen(); // UBED_WM_DONT_TOUCH
        chessData.currentTurn = gameData.white; // UBED_WM_DONT_TOUCH - Putih mulai duluan

        const whiteName = await conn.getName(gameData.white) || gameData.white.split('@')[0]; // UBED_WM_DONT_TOUCH
        const blackName = await conn.getName(gameData.black) || gameData.black.split('@')[0]; // UBED_WM_DONT_TOUCH

        const giliranText = `🎲 *Giliran:* Putih @${whiteName}\n\n> © ${global.namebot || 'Bot'} ${new Date().getFullYear()} ✨`; // UBED_WM_DONT_TOUCH
        
        chessData.msg = await sendChessBoard(m.chat, chessData.fen, gameData.white, gameData.white, gameData.black, giliranText, m); // UBED_WM_DONT_TOUCH
        
        return; // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH

    // UBED_WM_DONT_TOUCH - Melakukan Langkah Catur (default action jika ada 2 argumen)
    if (args[0] && args[1]) { // UBED_WM_DONT_TOUCH
        const senderId = m.sender; // UBED_WM_DONT_TOUCH
        if (!gameData || gameData.status !== 'playing') { // UBED_WM_DONT_TOUCH
            await sendReaction("⚠️"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, '⚠️ *Permainan belum dimulai atau tidak ada sesi yang aktif!*', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        if (currentTurn !== senderId) { // UBED_WM_DONT_TOUCH
            await sendReaction("⏳"); // UBED_WM_DONT_TOUCH
            const currentTurnName = await conn.getName(currentTurn) || currentTurn.split('@')[0]; // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, `⏳ *Bukan giliranmu, Kak!* Sekarang giliran ${chessData.currentTurn === gameData.white ? 'Putih' : 'Hitam'} @${currentTurnName} untuk bergerak.`, m, { // UBED_WM_DONT_TOUCH
                contextInfo: { mentionedJid: [currentTurn].filter(Boolean) }, // UBED_WM_DONT_TOUCH
                quoted: fkontak // UBED_WM_DONT_TOUCH
            }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        
        // UBED_WM_DONT_TOUCH - Buat instance Chess.js dengan FEN yang tersimpan
        const chess = new Chess(fen); // UBED_WM_DONT_TOUCH
        const [from, to] = args; // UBED_WM_DONT_TOUCH

        let moveResult; // UBED_WM_DONT_TOUCH
        try { // UBED_WM_DONT_TOUCH
            moveResult = chess.move({ from, to, promotion: 'q' }); // UBED_WM_DONT_TOUCH
        } catch (e) { // UBED_WM_DONT_TOUCH
            console.error('[ERROR] Chess Move Error:', e); // UBED_WM_DONT_TOUCH
            await sendReaction("❌"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, `❌ *Langkah tidak valid:* ${e.message}. Pastikan langkah sesuai aturan catur dan formatnya benar (contoh: e2e4, Nf3).`, m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH

        if (!moveResult) { // UBED_WM_DONT_TOUCH
            await sendReaction("❌"); // UBED_WM_DONT_TOUCH
            return conn.reply(m.chat, `❌ *Langkah tidak valid.* Pastikan langkah sesuai aturan catur dan formatnya benar (contoh: e2e4, Nf3).`, m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH

        // UBED_WM_DONT_TOUCH - Update FEN setelah langkah berhasil
        chessData.fen = chess.fen(); // UBED_WM_DONT_TOUCH
        console.log(`[DEBUG CHESS] Move made. New FEN: ${chessData.fen}`); // UBED_WM_DONT_TOUCH
        
        // UBED_WM_DONT_TOUCH - Cek status permainan setelah langkah
        let gameOverMessage = null; // UBED_WM_DONT_TOUCH
        let finalReaction = null; // UBED_WM_DONT_TOUCH
        let mentionedJids = []; // UBED_WM_DONT_TOUCH

        if (chess.isCheckmate()) { // UBED_WM_DONT_TOUCH
            const winner = currentTurn; // UBED_WM_DONT_TOUCH
            const loser = winner === gameData.white ? gameData.black : gameData.white; // UBED_WM_DONT_TOUCH
            const winnerName = await conn.getName(winner) || winner.split('@')[0]; // UBED_WM_DONT_TOUCH
            const loserName = await conn.getName(loser) || loser.split('@')[0]; // UBED_WM_DONT_TOUCH
            gameOverMessage = `🏆 *CHECKMATE!* 🎉\n\nSelamat kepada *${winner === gameData.white ? 'Putih' : 'Hitam'}* @${winnerName} yang berhasil mengalahkan *${loser === gameData.white ? 'Putih' : 'Hitam'}* @${loserName}!\n\n🏳️ *Permainan catur dihentikan.*`; // UBED_WM_DONT_TOUCH
            finalReaction = "🏆"; // UBED_WM_DONT_TOUCH
            mentionedJids = [winner, loser].filter(Boolean); // UBED_WM_DONT_TOUCH
        } else if (chess.isDraw()) { // UBED_WM_DONT_TOUCH
            gameOverMessage = `🤝 *DRAW!* Permainan berakhir seri.\n\n🏳️ *Permainan catur dihentikan.*\n*Pemain:* ${hasJoined.map(playerId => `- @${conn.getName(playerId) || playerId.split('@')[0]}`).join('\n')}`; // UBED_WM_DONT_TOUCH
            finalReaction = "🤝"; // UBED_WM_DONT_TOUCH
            mentionedJids = hasJoined.filter(Boolean); // UBED_WM_DONT_TOUCH
        } else if (chess.isStalemate()) { // UBED_WM_DONT_TOUCH
            gameOverMessage = `♟️ *STALEMATE!* Permainan berakhir seri karena tidak ada langkah legal lagi.\n\n🏳️ *Permainan catur dihentikan.*\n*Pemain:* ${hasJoined.map(playerId => `- @${conn.getName(playerId) || playerId.split('@')[0]}`).join('\n')}`; // UBED_WM_DONT_TOUCH
            finalReaction = "♟️"; // UBED_WM_DONT_TOUCH
            mentionedJids = hasJoined.filter(Boolean); // UBED_WM_DONT_TOUCH
        } else if (chess.isThreefoldRepetition()) { // UBED_WM_DONT_TOUCH
            gameOverMessage = `🔄 *DRAW!* Permainan berakhir seri karena pengulangan posisi tiga kali.\n\n🏳️ *Permainan catur dihentikan.*\n*Pemain:* ${hasJoined.map(playerId => `- @${conn.getName(playerId) || playerId.split('@')[0]}`).join('\n')}`; // UBED_WM_DONT_TOUCH
            finalReaction = "🔄"; // UBED_WM_DONT_TOUCH
            mentionedJids = hasJoined.filter(Boolean); // UBED_WM_DONT_TOUCH
        } else if (chess.isInsufficientMaterial()) { // UBED_WM_DONT_TOUCH
            gameOverMessage = `📉 *DRAW!* Permainan berakhir seri karena material tidak cukup untuk melakukan checkmate.\n\n🏳️ *Permainan catur dihentikan.*\n*Pemain:* ${hasJoined.map(playerId => `- @${conn.getName(playerId) || playerId.split('@')[0]}`).join('\n')}`; // UBED_WM_DONT_TOUCH
            finalReaction = "📉"; // UBED_WM_DONT_TOUCH
            mentionedJids = hasJoined.filter(Boolean); // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH

        if (gameOverMessage) { // UBED_WM_DONT_TOUCH
            await sendReaction(finalReaction); // UBED_WM_DONT_TOUCH
            await conn.reply(m.chat, gameOverMessage, m, { contextInfo: { mentionedJid: mentionedJids }, quoted: fkontak }); // UBED_WM_DONT_TOUCH
            delete conn.chess[key]; // UBED_WM_DONT_TOUCH - Hapus sesi game
            return true; // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH

        // UBED_WM_DONT_TOUCH - Jika game belum berakhir, switch giliran dan kirim papan baru
        const playersArray = [gameData.white, gameData.black]; // UBED_WM_DONT_TOUCH
        const currentTurnIndex = playersArray.indexOf(senderId); // UBED_WM_DONT_TOUCH
        const nextTurnIndex = (currentTurnIndex + 1) % 2; // UBED_WM_DONT_TOUCH
        chessData.currentTurn = playersArray[nextTurnIndex]; // UBED_WM_DONT_TOUCH

        const currentTurnName = await conn.getName(chessData.currentTurn) || chessData.currentTurn.split('@')[0]; // UBED_WM_DONT_TOUCH
        const currentColor = chessData.currentTurn === gameData.white ? 'Putih' : 'Hitam'; // UBED_WM_DONT_TOUCH
        let giliranText = `🎲 *Giliran:* ${currentColor} @${currentTurnName}\n\n`; // UBED_WM_DONT_TOUCH
        if (chess.inCheck()) { // UBED_WM_DONT_TOUCH
            giliranText += '⚠️ *RAJA TERANCAM (CHECK)!*\n'; // UBED_WM_DONT_TOUCH
        } // UBED_WM_DONT_TOUCH
        giliranText += `> © ${global.namebot || 'Bot'} ${new Date().getFullYear()} ✨`; // UBED_WM_DONT_TOUCH

        chessData.msg = await sendChessBoard(m.chat, chessData.fen, chessData.currentTurn, gameData.white, gameData.black, giliranText, m); // UBED_WM_DONT_TOUCH
        return true; // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH

    // UBED_WM_DONT_TOUCH - Perintah HELP
    if (feature === 'help') { // UBED_WM_DONT_TOUCH
        await sendReaction("📚"); // UBED_WM_DONT_TOUCH
        return conn.reply(m.chat, `
🌟 *Panduan Permainan Catur ${global.namebot || 'Bot'}* 🌟

Permainan catur ini dimainkan dengan format langkah *Aljabar Standar* (misal: e2e4, Ng1f3).

*♟️ Perintah Utama:*
*${usedPrefix}chess create*
  › Mulai sesi permainan catur baru.

*${usedPrefix}chess join*
  › Bergabung ke sesi yang sedang menunggu pemain lain.

*${usedPrefix}chess start*
  › Mulai permainan setelah 2 pemain bergabung.

*${usedPrefix}chess delete*
  › Hentikan sesi permainan catur yang sedang berjalan.

*${usedPrefix}chess [dari] [ke]*
  › Lakukan langkah catur (misal: *${usedPrefix}chess e2 e4* atau *${usedPrefix}chess g1f3*).

*Contoh Alur Bermain:*
1. Pemain A: *${usedPrefix}chess create*
2. Pemain B: *${usedPrefix}chess join*
3. Pemain A/B: *${usedPrefix}chess start*
4. Pemain Putih: *${usedPrefix}chess e2 e4*
5. Pemain Hitam: *${usedPrefix}chess e7 e5*
...dan seterusnya!

> © ${global.namebot || 'Bot'} ${new Date().getFullYear()} ✨
    `, m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
    } else { // UBED_WM_DONT_TOUCH
        await sendReaction("❓"); // UBED_WM_DONT_TOUCH
        return conn.reply(m.chat, '❓ Perintah tidak valid. Gunakan *"'+ usedPrefix +'chess help"* untuk melihat bantuan.', m, { quoted: fkontak }); // UBED_WM_DONT_TOUCH
    } // UBED_WM_DONT_TOUCH
}; // UBED_WM_DONT_TOUCH

handler.help = ["chess"]; // UBED_WM_DONT_TOUCH
handler.tags = ["game"]; // UBED_WM_DONT_TOUCH
handler.command = /^(chess|catur)$/i; // UBED_WM_DONT_TOUCH
handler.register = true; // UBED_WM_DONT_TOUCH
handler.group = true; // UBED_WM_DONT_TOUCH
handler.limit = true; // UBED_WM_DONT_TOUCH - Tambahkan limit

module.exports = handler; // UBED_WM_DONT_TOUCH