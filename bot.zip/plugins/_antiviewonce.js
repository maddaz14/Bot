export async function before(m, { conn, isBotAdmin }) {
  if (m.isBaileys && m.fromMe) return !0
  if (!m.isGroup) return

  let chat = global.db.data.chats[m.chat]
  if (!chat.viewonce) return // Mengacu pada pengaturan `viewonce`

  // Deteksi pesan view once
  const msg = m.message?.viewOnceMessageV2?.message || m.message?.viewOnceMessage?.message
  if (!msg) return

  if (!isBotAdmin) return

  // Ambil tipe media dan konten
  let type = Object.keys(msg)[0]
  let media = msg[type]
  let buffer = await conn.downloadMediaMessage({ message: { [type]: media } })

  // Kirim ulang tanpa view once
  await conn.sendFile(m.chat, buffer, type === 'videoMessage' ? 'video.mp4' : 'image.jpg', media.caption || '', m)

  // Hapus pesan aslinya
  return conn.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      fromMe: false,
      id: m.key.id,
      participant: m.key.participant || m.sender
    }
  })
}