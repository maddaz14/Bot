const fetch = require('node-fetch');

// Objek kontak dummy (Opsional, sesuaikan dengan framework bot Anda)
const fkontak = {
  key: {
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast',
    fromMe: false,
    id: 'Halo',
  },
  message: {
    conversation: `🤖 Ask Latukam AI by ${global.namebot}`,
  },
};

// Handler utama untuk plugin Latukam
let handler = async (m, { conn, text, usedPrefix, command }) => {
  // Pastikan pengguna menyertakan pertanyaan
  if (!text) {
    return conn.reply(m.chat, `⚠️ Masukkan pertanyaan untuk Latukam AI.\nContoh: *${usedPrefix + command} Halo AI, bagaimana kabarmu?*`, m, { quoted: fkontak });
  }

  try {
    // Kirim reaksi '⏳' untuk menandakan sedang diproses
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    // Panggil API Latukam AI
    const url = `https://api.siputzx.my.id/api/ai/latukam?content=${encodeURIComponent(text)}`;
    const res = await fetch(url);

    // Periksa status respons
    if (!res.ok) {
      throw new Error(`Gagal terhubung ke API. Status: ${res.status}`);
    }

    const json = await res.json();

    // Periksa jika status API false atau tidak ada respons
    if (!json.status || !json.data) {
      const errorMessage = json.message || 'AI tidak dapat memberikan jawaban untuk pertanyaan Anda.';
      return conn.reply(m.chat, `❌ ${errorMessage}`, m);
    }
    
    const response = json.data;

    // Kirim jawaban dari Latukam AI
    await conn.reply(m.chat, response, m);

    // Kirim reaksi '✅' setelah berhasil
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error(e);
    // Kirim reaksi '❌' jika terjadi error
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    conn.reply(m.chat, `❌ Terjadi kesalahan: ${e.message}`, m);
  }
};

// Pengaturan metadata plugin
handler.help = ['latukam'];
handler.tags = ['ai', 'tools'];
handler.command = /^(latukam)$/i;
handler.limit = true;
handler.register = true;

module.exports = handler;