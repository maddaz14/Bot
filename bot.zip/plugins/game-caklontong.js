import { caklontong } from '@bochilteam/scraper'
import similarity from 'similarity'

let timeout = 60000
let poin = 600
const threshold = 0.72

let handler = async (m, { conn, usedPrefix }) => {
    conn.caklontong = conn.caklontong ? conn.caklontong : {}
    let id = m.chat
    if (id in conn.caklontong) return conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.caklontong[id][0])
    let json = await caklontong()
    let caption = `
${json.soal}
Timeout *${(timeout / 1000).toFixed(2)} detik*
Ketik ${usedPrefix}calo untuk bantuan
Bonus: ${poin} XP
`.trim()
    conn.caklontong[id] = [
        await m.reply(caption),
        json, poin,
        setTimeout(async () => {
            if (conn.caklontong[id]) await conn.reply(m.chat, `Waktu habis!\nJawabannya adalah *${json.jawaban}*\n${json.deskripsi}`, conn.caklontong[id][0])
            delete conn.caklontong[id]
        }, timeout)
    ]
}

handler.help = ['caklontong']
handler.tags = ['game']
handler.command = /^caklontong/i

handler.before = async function (m, { conn }) {
    let id = m.chat
    if (!m.text) return
    this.caklontong = this.caklontong ? this.caklontong : {}
    if (!(id in this.caklontong)) return

    let kuis = this.caklontong[id]
    
    // Check if the user's message is the correct answer
    if (m.text.toLowerCase().trim() === kuis[1].jawaban.toLowerCase().trim()) {
        global.db.data.users[m.sender].exp += kuis[2]
        global.db.data.users[m.sender].limit += 2
        conn.reply(m.chat, `✅ *Benar!*\n🎉 +${kuis[2]} XP\n🎁 +2 Limit`, m)
        clearTimeout(kuis[3])
        delete this.caklontong[id]
    } else if (similarity(m.text.toLowerCase(), kuis[1].jawaban.toLowerCase().trim()) >= threshold) {
        m.reply(`*Dikit lagi!*`)
    } else {
        m.reply(`*Salah!*`)
    }
}

export default handler