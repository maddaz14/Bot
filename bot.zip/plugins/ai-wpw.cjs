const axios = require('axios');
const FormData = require('form-data');

const FILTERS = ['Coklat', 'Hitam', 'Nerd', 'Piggy', 'Carbon', 'Botak'];

async function uploadImage(buffer) {
  try {
    const { data: html } = await axios.get("https://freeimage.host/");
    const token = html.match(/PF.obj.config.auth_token = "(.+?)";/)[1];

    const form = new FormData();
    form.append("source", buffer, 'file.jpg');
    form.append("type", "file");
    form.append("action", "upload");
    form.append("timestamp", Math.floor(Date.now() / 1000));
    form.append("auth_token", token);
    form.append("nsfw", "0");

    const { data } = await axios.post("https://freeimage.host/json", form, {
      headers: { "Content-Type": "multipart/form-data", ...form.getHeaders() },
    });

    if (data && data.image && data.image.url) {
      return data.image.url;
    } else {
      throw new Error("Upload failed, no URL received.");
    }
  } catch (err) {
    throw new Error(`Upload failed: ${err.message}`);
  }
}

async function Hytamkan(imageUrl, filter = 'Hitam') {
  const selected = FILTERS.find(f => f.toLowerCase() === filter.toLowerCase());
  if (!selected) throw new Error(`Filter '${filter}' tidak tersedia.`);

  const imgRes = await axios.get(imageUrl, { responseType: 'arraybuffer' });
  const base64Input = Buffer.from(imgRes.data).toString('base64');

  const res = await axios.post('https://wpw.my.id/api/process-image', {
    imageData: base64Input,
    filter: selected.toLowerCase()
  }, {
    headers: {
      'Content-Type': 'application/json',
      'Origin': 'https://wpw.my.id',
      'Referer': 'https://wpw.my.id/',
    }
  });

  const dataUrl = res.data?.processedImageUrl;
  if (!dataUrl?.startsWith('data:image/')) throw new Error('Tidak ada hasil yang didapat');

  return dataUrl;
}

let handler = async (m, { conn, usedPrefix, command, text }) => {
  const mikahytam = {
    "key": {
        "participant": '0@s.whatsapp.net',
        "remoteJid": "0@s.whatsapp.net",
        "fromMe": false,
        "id": "Halo",
    },
    "message": {
        "conversation": `😈 Penghitaman By Mika Misono`,
    }
};
  if (command === 'wpw') {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    
    if (!mime || !/image\/(jpe?g|png)/.test(mime)) {
      await conn.sendMessage(m.chat, {
        react: {
          text: "⛔️",
          key: m.key
        }
      });
      
      return conn.sendMessage(m.chat, {
        text: `😚 *Aduh, Sensei~!* Kamu harus membalas atau mengirim gambar dulu ya!\n\nContoh: ${usedPrefix + command}`
      }, { quoted: m });
    }

    await conn.sendMessage(m.chat, {
      react: {
        text: "⏳",
        key: m.key
      }
    });

    try {
      let media = await q.download();
      let imageUrl = await uploadImage(media);
      
      await conn.sendMessage(m.chat, {
        react: {
          text: "✨",
          key: m.key
        }
      });

      let buttons = FILTERS.map(filter => ({
        buttonId: `${usedPrefix}wpwgen ${filter} ${imageUrl}`,
        buttonText: { displayText: `🎨 ${filter}` }
      }));

      await conn.sendMessage(m.chat, {
        text: `✨ *Hai Sensei!* Pilih style yang kamu inginkan ya!`,
        footer: `🎨 WPW - Waifu Penghitaman Whatsapp`,
        buttons: buttons,
        headerType: 1
      });

    } catch (e) {
      await conn.sendMessage(m.chat, {
        react: {
          text: "⛔️",
          key: m.key
        }
      });
      
      conn.sendMessage(m.chat, {
        text: `😞 *Yah, Error Nih Sensei!* ${e.message}`
      }, { quoted: m });
    }
  }

  if (command === 'wpwgen') {
    let [style, imageUrl] = text.split(' ');
    
    if (!style || !imageUrl) {
      await conn.sendMessage(m.chat, {
        react: {
          text: "⛔️",
          key: m.key
        }
      });
      
      return conn.sendMessage(m.chat, {
        text: `😭 *Sensei..* Formatnya salah! Gunakan: ${usedPrefix + command} <style> <image_url>`
      }, { quoted: m });
    }

    await conn.sendMessage(m.chat, {
      react: {
        text: "⏳",
        key: m.key
      }
    });

    try {
      let result = await Hytamkan(imageUrl, style);
      let buffer = Buffer.from(result.split(',')[1], 'base64');
      
      await conn.sendMessage(m.chat, {
        react: {
          text: "✨",
          key: m.key
        }
      });

      await conn.sendMessage(m.chat, {
        image: buffer,
        caption: `✨ *Tadaa-!* Hasil penghitaman style ${style} untuk Sensei!\n\n🎨 *Style:* ${style}\n📸 *Sumber:* ${imageUrl}`
      }, { quoted: mikahytam });

    } catch (e) {
      await conn.sendMessage(m.chat, {
        react: {
          text: "⛔️",
          key: m.key
        }
      });
      
      conn.sendMessage(m.chat, {
        text: `😞 *Yah, Gagal Sensei!* ${e.message}`
      }, { quoted: m });
    }
  }
};

handler.help = ['wpw', 'wpwgen <style> <url>'];
handler.tags = ['ai', 'tools'];
handler.command = /^(wpw|wpwgen)$/i;

module.exports = handler