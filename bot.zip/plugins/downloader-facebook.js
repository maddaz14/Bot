// Dibuat oleh ubed - Dilarang keras menyalin tanpa izin!
// --- Kode Plugin Dimulai di sini ---
import fetch from 'node-fetch';

// Objek fkontak untuk tampilan pesan yang dikutip
const fkontak = {
  key: {
    participant: '447974045725@s.whatsapp.net',
    remoteJid: '447974045725@s.whatsapp.net',
    fromMe: false,
    id: 'Halo',
  },
  message: {
    conversation: `🌷 Facebook Downloader ${global.namebot || 'Bot'} ✨`,
  },
};

const handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) {
    return conn.reply(
      m.chat,
      `🌸 Halo Kak! Mau download video Facebook apa nih? ✨\n\nContoh: *${usedPrefix + command} https://www.facebook.com/share/v/1PPDVXnicc/*\n\nYuk, kirim link-nya biar aku bantu unduh! 🌷`,
      m,
      { quoted: fkontak }
    );
  }

  await conn.sendMessage(m.chat, { react: { text: '🎶', key: m.key } });

  try {
    const apiUrl = `https://api.ubed.my.id/download/facebook?apikey=alhamdulillah&url=${encodeURIComponent(args[0])}`;
    const res = await fetch(apiUrl);

    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(`API Error (${res.status}): ${errorText.substring(0, 100)}`);
    }

    const json = await res.json();

    if (!json.status || !json.result) {
      throw new Error(`Gagal mendapatkan data dari Facebook. Respon API: ${json.message || 'Tidak ada hasil.'}`);
    }

    const { title, duration, thumbnail, video } = json.result;
    const video720 = video.find(v => /720/.test(v.quality));
    const bestVideo =
      video720 ||
      video.sort((a, b) => parseInt(b.quality) - parseInt(a.quality))[0];

    if (!bestVideo || !bestVideo.url) {
      throw new Error('Video tidak tersedia atau tidak bisa diunduh. Pastikan link publik.');
    }

    const caption = `
🌷 *FACEBOOK VIDEO!* 🌷
----------------------------------------
✨ *Judul:* ${title || 'Tidak ada judul'}
⏱️ *Durasi:* ${duration || 'Tidak diketahui'}
🎥 *Resolusi:* ${bestVideo.quality || 'Tidak diketahui'}
🔗 *Sumber:* ${args[0].substring(0, 50)}...
----------------------------------------
Selamat menikmati videonya ya, Kak! 🌸

> © ${global.namebot || 'Bot'} 2025 ✨`.trim();

    await conn.sendMessage(
      m.chat,
      {
        video: { url: bestVideo.url },
        caption,
        contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 999,
          isForwarded: true,
          externalAdReply: {
            title: '✨ Video Facebook Siap Diunduh!',
            body: `Judul: ${title?.substring(0, 30) || '...'}`,
            mediaType: 2,
            renderLargeThumbnail: true,
            thumbnailUrl:
              thumbnail || global.foto || 'https://telegra.ph/file/ee60957d56941b8fdd221.jpg',
            sourceUrl: args[0],
          },
        },
      },
      { quoted: fkontak }
    );

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (e) {
    console.error('Error in Facebook Downloader:', e);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    await conn.reply(
      m.chat,
      `❌ Aduh, Kak! Terjadi kesalahan saat mengunduh dari Facebook. 😥\n\n*Detail Error:* ${e.message || e}\n\nPastikan URL valid dan publik ya, Kak! 🌷\n\n> © ${global.namebot || 'Bot'} 2025 ✨`,
      m,
      { quoted: fkontak }
    );
  }
};

handler.help = ['facebook <url>', 'fb <url>'];
handler.tags = ['downloader'];
handler.command = /^facebook|fb$/i;
handler.limit = true;
handler.register = true;

export default handler;