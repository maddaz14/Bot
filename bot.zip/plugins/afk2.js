var handler = async (m, { text, conn }) => {
    if (!m.isGroup) return conn.reply(m.chat, 'Perintah ini hanya bisa dipakai di grup!', m);

    let user = global.db.data.users[m.sender];
    user.afk2 = {
        time: +new Date(),
        reason: text || "Tanpa Keterangan",
        group: m.chat // Simpan ID grup
    };

    let afkTime = new Date(user.afk2.time);
    let afkTimeString = afkTime.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }).replace(',', ':');
    let userTag = '@' + m.sender.split('@')[0];

    conn.reply(m.chat,
`====== [ AFK MODE ] ======

👤 Nama   : ${userTag}
📄 Alasan : ${user.afk2.reason}
🕒 Sejak  : ${afkTimeString}

=====================`, floc);
};

handler.help = ['afk2'];
handler.tags = ['main'];
handler.command = /^afk2$/i;

export default handler;