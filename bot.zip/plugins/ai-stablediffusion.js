import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        throw `Masukkan prompt!\n\nContoh:\n${usedPrefix + command} kucing lucu sedang membaca buku`;
    }

    await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });

    const url = `https://api.siputzx.my.id/api/ai/stable-diffusion?prompt=${encodeURIComponent(text)}`;

    try {
        const response = await axios.get(url, { responseType: 'arraybuffer' });

        await conn.sendMessage(m.chat, {
            image: response.data,
            caption: `🧠 Stable Diffusion Prompt:\n*${text}*`
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error(err);
        m.reply('❌ Gagal menghasilkan gambar dari Stable Diffusion.');
    }
};

handler.help = ['stablediffusion <prompt>'];
handler.tags = ['ai', 'image'];
handler.command = /^stablediffusion$/i;
handler.limit = true;

export default handler;