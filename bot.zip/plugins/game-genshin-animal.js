import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text) {
    try {
      const list = await genshindb.animals("names", { matchCategories: true });
      return m.reply(`📜 *Daftar Hewan Tersedia:*\n\n${list.join(", ")}`);
    } catch (e) {
      console.error('[ANIMAL LIST ERROR]', e);
      return m.reply('❌ Gagal mengambil daftar hewan.');
    }
  }

  try {
    const result = await genshindb.animals(text);
    if (result) {
      let response = `🐾 *Hewan Ditemukan: ${result.name}*\n\n`;
      response += `📖 _"${result.description || "Deskripsi tidak tersedia"}"_\n\n`;
      response += `📚 *Kategori:* ${result.category || "Tidak diketahui"}\n`;
      response += `🔢 *Jenis Hitungan:* ${result.counttype || "Tidak diketahui"}\n`;
      response += `📋 *Urutan Sortir:* ${result.sortorder || "Tidak diketahui"}`;
      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[ANIMAL ERROR]', err);
    try {
      const categories = await genshindb.animals(text, { matchCategories: true });
      return m.reply(`🔍 *Kategori Hewan '${text}' ditemukan:*\n\n- ${categories.join("\n- ")}`);
    } catch (e) {
      console.warn('[ANIMAL FALLBACK ERROR]', e);
      try {
        const list = await genshindb.animals("names", { matchCategories: true });
        return m.reply(`❌ Hewan '${text}' tidak ditemukan.\n\n📜 *Hewan yang tersedia:*\n${list.join(", ")}`);
      } catch (finalErr) {
        return m.reply('⚠️ Gagal menampilkan daftar hewan.');
      }
    }
  }
};

handler.help = ['genshin-animal <nama hewan>'];
handler.tags = ['game'];
handler.command = /^(genshin-animal|g-animals|gens-animals)$/i;
handler.limit = 1;
handler.register = true;

export default handler;