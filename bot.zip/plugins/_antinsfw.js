import axios from 'axios';
import fetch from 'node-fetch';
import FormData from 'form-data';
import { fileTypeFromBuffer } from 'file-type';

/**
 * Endpoint API NSFW Checker
 */
const API_URL = 'https://api.nekolabs.my.id/tools/nsfw-checker';

/**
 * Fungsi untuk mengunggah Buffer ke Catbox.moe
 * (Diambil dari plugin tourl Anda)
 */
async function catboxUpload(buffer) {
  const fileInfo = await fileTypeFromBuffer(buffer) || { ext: 'bin', mime: 'application/octet-stream' };
  const { ext, mime } = fileInfo;
  
  const form = new FormData();
  form.append('reqtype', 'fileupload');
  form.append('fileToUpload', buffer, { filename: `file.${ext}`, contentType: mime });

  const res = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: form });
  const responseText = await res.text();
  
  if (!res.ok || responseText.startsWith('Error')) {
    throw new Error(`Catbox Upload Failed: ${responseText.trim()}`);
  }
  
  return responseText.trim();
}

let handler = async (m) => m;

handler.before = async function (m, { isBotAdmin, isAdmin, conn }) {
    // Abaikan pesan dari bot sendiri, dari owner, atau bukan di grup
    if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup) return true;

    // Pastikan data chat ada dan fitur aktif
    let chat = global.db.data.chats[m.chat] || {};
    if (typeof chat.antiNsfw === "undefined") chat.antiNsfw = false;
    global.db.data.chats[m.chat] = chat;

    // Cek apakah fitur antiNsfw aktif di grup ini
    if (!chat.antiNsfw) return true;

    // Cek apakah pengirim adalah Admin (dikecualikan)
    if (isAdmin) {
      return true; // Admin kebal
    }

    // Cek apakah Bot adalah Admin (wajib untuk menghapus)
    if (!isBotAdmin) {
      //m.reply("*Bot bukan admin, tidak bisa menjalankan Anti NSFW.*"); // Opsional: Beritahu bahwa bot tdk bisa menghapus
      return true;
    }

    // Cek apakah pesan berupa Gambar/Video/Stiker
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    // Hanya proses media (Gambar atau Video)
    if (mime.startsWith('image/') || mime.startsWith('video/')) {
        try {
            const media = await q.download();
            if (!media) return true; // Gagal download, lewati
            
            // 1. Upload ke Catbox
            const imageUrl = await catboxUpload(media); 
            
            // 2. Cek NSFW ke API
            const encodedImageUrl = encodeURIComponent(imageUrl);
            const requestUrl = `${API_URL}?imageUrl=${encodedImageUrl}`;
            
            const response = await axios.get(requestUrl, { timeout: 15000 });
            const data = response.data;

            if (data && data.status === true && data.result) {
                const result = data.result;
                // Ambang batas kepercayaan (misal: di atas 0.75 dianggap NSFW)
                const threshold = 0.75; 
                
                // Asumsi: Kita cek jika label BUKAN "Not Porn" DAN confidence tinggi
                if (result.labelName !== "Not Porn" && result.confidence > threshold) {
                    
                    await m.reply(
                        `*「 ANTI NSFW 」*\nPesan ${await conn.getName(m.sender)} terdeteksi konten *${result.labelName.toUpperCase()}* (${(result.confidence * 100).toFixed(2)}%), langsung dihapus 🚫`
                    );

                    // Hapus pesan
                    await conn.sendMessage(m.chat, { delete: m.key });
                    return true;
                }
            }
        } catch (error) {
            console.error('ANTI NSFW ERROR:', error.message);
            // Biarkan pesan jika ada error API/upload
            return true;
        }
    }

    return true;
};

// Pastikan handler.before berjalan
handler.notBlock = true;
export default handler;