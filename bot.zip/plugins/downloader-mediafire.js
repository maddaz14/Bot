import axios from 'axios'

async function mediafire(url) {
    try {
        if (!url.includes('mediafire.com')) throw new Error('❌ Link tidak valid')

        const { data } = await axios.get('https://api.siputzx.my.id/api/d/mediafire', {
            params: { url }
        })

        if (!data.status || !data.data) throw new Error('Gagal mengambil data dari API')

        return data.data
    } catch (e) {
        throw new Error(e.message || 'Terjadi kesalahan saat fetch data')
    }
}

const handler = async (m, { conn, text }) => {
    if (!text) return m.reply(
        'Masukkan link Mediafire!\n' +
        'Contoh: .mediafire https://www.mediafire.com/file/iojnikfucf67q74/Base_Bot_Simpel.zip/file'
    )

    try {
        // react loading
        await conn.sendMessage(m.chat, {
            react: { text: '⏳', key: m.key }
        })

        const res = await mediafire(text)

        const caption = `*Mediafire Downloader*
*Nama:* ${res.fileName}
*Tipe:* ${res.mimeType || res.fileType}
*Ekstensi:* ${res.fileExtension}
*Ukuran:* ${res.fileSize}
*Upload:* ${res.uploadDate}
*Deskripsi:* ${res.description || '-'} 
`

        await conn.sendMessage(m.chat, {
            document: { url: res.downloadLink },
            fileName: res.fileName,
            mimetype: res.mimeType || 'application/octet-stream',
            caption,
        }, { quoted: m })

        // react sukses
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        })

    } catch (e) {
        // react error
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        })
        m.reply(`❌ ${String(e)}`)
    }
}

handler.help = ['mediafire <link>']
handler.tags = ['downloader']
handler.command = ['mediafire', 'mf']

export default handler