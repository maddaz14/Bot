import axios from 'axios';
import chalk from 'chalk';
import FormData from 'form-data'; // Impor FormData di sini

let handler = async (m, { conn, args }) => {
    try {
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || '';
        
        if (!/image/.test(mime)) {
            return m.reply('❌ Balas gambar dengan caption atau tag gambar.');
        }

        m.reply(chalk.blue('⏳ Menganalisis gambar...'));

        let media = await q.download();
        let buffer = Buffer.isBuffer(media) ? media : Buffer.from(media);
        
        // --- KODE UPLOAD GAMBAR KE CATBOX LANGSUNG DI SINI ---
        const formData = new FormData();
        formData.append('reqtype', 'fileupload');
        formData.append('fileToUpload', buffer, { filename: 'file.jpg', contentType: 'image/jpeg' });
        
        let imageUrl;
        try {
            const uploadResponse = await axios.post('https://catbox.moe/user/api.php', formData, {
                headers: formData.getHeaders(),
            });
            imageUrl = uploadResponse.data.trim();
        } catch (uploadError) {
            console.error('Error saat mengunggah ke Catbox:', uploadError);
            m.reply('❌ Gagal mengunggah gambar ke Catbox.');
            return;
        }
        // --- AKHIR KODE UPLOAD ---

        // Memanggil API Maelyn
        const apiUrl = `https://api.maelyn.sbs/api/img2txt/prompt?url=${encodeURIComponent(imageUrl)}&apikey=zahra999`;
        const response = await axios.get(apiUrl);
        
        if (response.data.code !== 200 || !response.data.result) {
            return m.reply(`❌ Gagal menganalisis gambar. ${response.data.status || 'Pesan tidak diketahui.'}`);
        }

        const caption = `
*Result:*
${response.data.result}
`;
        conn.sendMessage(m.chat, { text: caption }, { quoted: m });

    } catch (e) {
        console.error('Error saat memproses img2txt:', e);
        m.reply('❌ Terjadi kesalahan, silakan coba lagi nanti.');
    }
};

handler.help = ['img2txt'];
handler.tags = ['tools'];
handler.command = /^(img2txt|deskripsikan)$/i;

export default handler;