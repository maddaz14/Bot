import axios from 'axios'
import zlib from 'zlib'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) throw `• *Example:* ${usedPrefix + command} https://www.capcut.com/tv2/ZSSSB94f3/`
    let url = args[0]

    // React emoji sebelum proses
    await conn.sendMessage(m.chat, {
        react: {
            text: "🕊️",
            key: m.key
        }
    })

    try {
        let hasil = await cangcut(url)
        if (!hasil?.originalVideoUrl) throw 'Gagal mendapatkan video.'

        let caption = `┌─⭓「 *CapCut Downloader* 」\n│ *• Judul :* ${hasil.title || '-'}\n│ *• Author :* ${hasil.author || '-'}\n└───────────────⭓`.trim()

        await conn.sendFile(m.chat, hasil.originalVideoUrl, '', caption, m)
    } catch (err) {
        m.reply(`❌ Error: ${err.message || err}`)
    }
}

handler.help = ['capcut'].map(v => v + ' <url>')
handler.tags = ['downloader']
handler.command = /^capcut$/i
export default handler

async function cangcut(url) {
    const headers = {
        'Host': '3bic.com',
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
        'Origin': 'https://3bic.com',
        'Referer': 'https://3bic.com/',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
    }

    const payload = { url }

    const res = await axios.post('https://3bic.com/api/download', payload, {
        headers,
        responseType: 'arraybuffer',
        decompress: false
    })

    let data = res.data
    const encoding = res.headers['content-encoding']

    if (encoding === 'br') {
        data = zlib.brotliDecompressSync(data)
    } else if (encoding === 'gzip') {
        data = zlib.gunzipSync(data)
    } else if (encoding === 'deflate') {
        data = zlib.inflateSync(data)
    }

    const json = JSON.parse(data.toString())

    if (json.originalVideoUrl && json.originalVideoUrl.startsWith('/')) {
        json.originalVideoUrl = 'https://3bic.com' + json.originalVideoUrl
    }

    return json
}