// plugins/ghibi.js
import axios from "axios"
import FormData from "form-data"
import crypto from "crypto"
import { fileTypeFromBuffer } from "file-type"

const BASE_URL = "https://ai-apps.codergautam.dev"

// --- util kecil ---
function acakName(len = 10) {
  const chars = "abcdefghijklmnopqrstuvwxyz"
  return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join("")
}

async function autoregist() {
  const uid = crypto.randomBytes(12).toString("hex")
  const email = `gienetic${Date.now()}@nyahoo.com`

  const payload = {
    uid,
    email,
    displayName: acakName(),
    photoURL: "https://i.pravatar.cc/150",
    appId: "photogpt"
  }

  const res = await axios.post(`${BASE_URL}/photogpt/create-user`, payload, {
    headers: {
      "content-type": "application/json",
      "accept": "application/json",
      "user-agent": "okhttp/4.9.2"
    }
  })

  if (res.data?.success) return uid
  throw new Error("Register gagal: " + JSON.stringify(res.data))
}

// panggil service untuk img2img (sama seperti plugin sebelumnya)
async function img2img(imageBuffer, prompt, mime) {
  const uid = await autoregist()

  const ext = (await fileTypeFromBuffer(imageBuffer))?.ext || "jpg"
  const form = new FormData()
  form.append("image", imageBuffer, { filename: `input.${ext}`, contentType: mime || `image/${ext}` })
  form.append("prompt", prompt)
  form.append("userId", uid)

  const uploadRes = await axios.post(`${BASE_URL}/photogpt/generate-image`, form, {
    headers: {
      ...form.getHeaders(),
      "accept": "application/json",
      "user-agent": "okhttp/4.9.2",
      "accept-encoding": "gzip"
    },
    maxBodyLength: Infinity
  })

  if (!uploadRes.data?.success) throw new Error(JSON.stringify(uploadRes.data))

  const { pollingUrl } = uploadRes.data
  let status = "pending"
  let resultUrl = null

  // polling
  while (status !== "Ready") {
    const pollRes = await axios.get(pollingUrl, {
      headers: { "accept": "application/json", "user-agent": "okhttp/4.9.2" }
    })
    status = pollRes.data?.status
    if (status === "Ready") {
      resultUrl = pollRes.data?.result?.url
      break
    }
    // pertahankan jeda agar tidak DDoS polling endpoint
    await new Promise(r => setTimeout(r, 3000))
  }

  if (!resultUrl) throw new Error("Gagal mendapatkan hasil gambar.")

  const resultImg = await axios.get(resultUrl, { responseType: "arraybuffer" })
  return Buffer.from(resultImg.data)
}

// --- prompt tertanam (Studio Ghibli style) ---
// Kamu bisa modifikasi string ini sesuai preferensi
const GHIBI_BASE_PROMPT = [
  "studio ghibli style",
  "beautiful soft pastel colors",
  "warm cinematic lighting",
  "hand painted look, film grain",
  "high detail, cinematic composition",
  "soft volumetric lighting, delicate textures",
  "ultra-detailed, 4k"
].join(", ")

// --- handler command .ghibi / .ghibli ---
let handler = async (m, { conn, args }) => {
  try {
    if (m._ghibi_done) return
    m._ghibi_done = true

    // react waiting
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } }).catch(() => null)

    // Tentukan sumber gambar:
    // 1) Reply image (m.quoted)
    // 2) Kalau pesan itu sendiri membawa media (kirim gambar + caption)
    // 3) URL gambar di argumen pertama (http/https)
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ""
    let mediaBuffer = null

    // jika argumen pertama adalah URL image, coba download
    const maybeUrl = (args[0] || "").trim()
    if (/^https?:\/\//i.test(maybeUrl)) {
      try {
        const res = await axios.get(maybeUrl, { responseType: "arraybuffer", timeout: 20000 })
        mediaBuffer = Buffer.from(res.data)
        // try to detect mime from buffer
        const ft = await fileTypeFromBuffer(mediaBuffer)
        mime = ft ? `image/${ft.ext}` : res.headers["content-type"] || "image/jpeg"
      } catch (e) {
        console.warn("Gagal download image dari URL:", e)
        return m.reply("❌ Gagal mengunduh gambar dari URL. Pastikan URL langsung mengarah ke file gambar.")
      }
    } else {
      // bukan URL => ambil dari media reply / media langsung
      if (!mime || !mime.startsWith("image/")) {
        return m.reply("📌 Kirim / reply gambar dengan caption:\n.ghibi <optional tambahan prompt>\nAtau: .ghibi <image_url> <optional tambahan prompt>")
      }
      try {
        mediaBuffer = await q.download()
      } catch (e) {
        console.error("Gagal download media:", e)
        return m.reply("❌ Gagal mengunduh media. Coba lagi.")
      }
    }

    // susun prompt final: gabungkan tambahan user (jika ada) + base Ghibli prompt
    const userExtra = args.slice(/^https?:\/\//i.test(maybeUrl) ? 1 : 0).join(" ").trim() // jika URL di arg[0], skip untuk extra prompt
    const finalPrompt = (userExtra ? `${userExtra}, ` : "") + GHIBI_BASE_PROMPT

    // Beri tahu user proses berjalan
    await conn.sendMessage(m.chat, { text: `🔎 Memproses gambar dengan prompt:\n${finalPrompt}` }, { quoted: m }).catch(() => null)

    // Panggil service img2img
    const outBuffer = await img2img(mediaBuffer, finalPrompt, mime)

    // Kirim hasil
    await conn.sendMessage(
      m.chat,
      { image: outBuffer, caption: `✅ Hasil .ghibi\nPrompt: ${finalPrompt}` },
      { quoted: m }
    )

    // react done
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => null)

  } catch (e) {
    console.error("Error di plugin ghibi:", e)
    // kirim pesan error (berusaha pakai e.message bila ada)
    const msg = (e && e.message) ? e.message : String(e)
    try { m.reply(`💥 Terjadi kesalahan: ${msg}`) } catch(_) { /* ignore */ }
  }
}

handler.help = ['ghibi2 <optional prompt>','ghibli2']
handler.tags = ['ai','image']
handler.command = /^ghibi2$|^ghibli2$/i
handler.group = false
handler.private = false

export default handler