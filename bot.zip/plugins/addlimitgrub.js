import { areJidsSameUser } from '@fuxxy-star/baileys' // ganti adiwajshing → whiskeysockets

let handler = async (m, { conn, args, participants, isPrems }) => {
  if (!m.isGroup) throw 'Fitur ini hanya bisa digunakan di grup!'
  if (!args[0] || isNaN(args[0])) throw 'Masukkan jumlah limit yang valid\nContoh: .addlimitgrub 5'

  let jumlah = parseInt(args[0])
  if (jumlah < 1) throw 'Minimal 1 limit'

  let users = global.db.data.users

  async function resolveAndCleanJid(inputJid, conn, groupParticipants = []) {
      if (inputJid.endsWith('@s.whatsapp.net')) {
          return inputJid
      }

      if (inputJid.endsWith('@lid')) {
          let resolved = groupParticipants.find(p => areJidsSameUser(p.id, inputJid) || areJidsSameUser(p.jid, inputJid))
          if (resolved?.jid?.endsWith('@s.whatsapp.net')) {
              return resolved.jid
          }

          try {
              const [res] = await conn.onWhatsApp(inputJid)
              if (res?.exists) {
                  return res.jid
              }
          } catch {}
      }
      return inputJid
  }

  let totalAffectedUsers = 0
  for (let user of participants) {
    try {
        const cleanedUserJid = await resolveAndCleanJid(user.id, conn, participants)

        if (!cleanedUserJid.endsWith('@s.whatsapp.net')) {
            console.warn(`[ADDLIMITGRUB] Melewati JID tidak valid setelah resolusi: ${user.id} -> ${cleanedUserJid}`)
            continue
        }

        if (!users[cleanedUserJid]) {
            users[cleanedUserJid] = {
                limit: 0,
                money: 0,
                exp: 0,
                level: 0,
                role: '',
                registered: false
            }
        }

        users[cleanedUserJid].limit += jumlah
        totalAffectedUsers++
    } catch (e) {
        console.error(`[ADDLIMITGRUB] Gagal memproses user ${user.id}:`, e)
    }
  }

  m.reply(`Berhasil menambahkan *+${jumlah} limit* ke *${totalAffectedUsers}* member grup!`)
}

handler.help = ['addlimitgrub <jumlah>']
handler.tags = ['owner']
handler.command = /^addlimitgrub$/i
handler.owner = true

export default handler