import fetch from 'node-fetch'
import { generateWAMessageContent, generateWAMessageFromContent, proto } from '@fuxxy-star/baileys'

let handler = async (m, { conn, text, command }) => {
  if (command == 'xn' || command == 'xns') {
    if (!text) return m.reply(`📌 Kirim kata kunci pencarian!\nContoh: .${command} anime`)

    try {
      const res = await fetch(`https://api.nekorinn.my.id/search/xnxx?q=${encodeURIComponent(text)}`)
      const json = await res.json()

      if (!json.status || !json.result || json.result.length === 0)
        return m.reply('❌ Tidak ditemukan hasil.')

      const filtered = json.result.filter(v => v.title && v.cover && v.url)
      const selected = filtered.slice(0, 8)

      if (selected.length === 0) return m.reply('❌ Tidak ada hasil valid.')

      const cards = await Promise.all(selected.map(async v => {
        try {
          const thumbContent = await generateWAMessageContent(
            { image: { url: v.cover } },
            { upload: conn.waUploadToServer }
          )

          return {
            header: {
              title: `🔞 ${v.title}`,
              hasMediaAttachment: true,
              imageMessage: thumbContent.imageMessage
            },
            body: {
              text: `📺 Durasi: ${v.duration || '-'}\n👁️ Views: ${v.views || '-'}\n🖼️ Resolusi: ${v.resolution || '-'}`
            },
            footer: {
              text: '📥 Klik tombol untuk copy command'
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: 'cta_url',
                  buttonParamsJson: JSON.stringify({
                    display_text: '🌐 Tonton Online',
                    url: v.url
                  })
                },
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: '📥 Copy Perintah Download',
                    id: v.url,
                    copy_code: `.xpdl ${v.url}`
                  })
                }
              ]
            }
          }
        } catch (e) {
          return null
        }
      }))

      const validCards = cards.filter(card => card !== null)
      if (validCards.length === 0) return m.reply('❌ Tidak ada hasil valid.')

      const carouselMsg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: { text: `🔍 Hasil pencarian untuk: *${text}*` },
              footer: { text: 'Geser untuk melihat lebih banyak hasil...' },
              carouselMessage: { cards: validCards }
            })
          }
        }
      }, { quoted: m })

      await conn.relayMessage(m.chat, carouselMsg.message, { messageId: carouselMsg.key.id })

    } catch (err) {
      console.error('❌ Error search:', err)
      m.reply('❌ Terjadi kesalahan saat memproses data.')
    }
  }

  if (command == 'xpdl') {
    if (!text) return m.reply('❌ Kirim URL videonya!\nContoh: .xpdl https://www.xnxx.com/video-xyz')

    try {
      const res = await fetch(`https://api.nekorinn.my.id/downloader/xnxx?url=${encodeURIComponent(text)}`)
      const json = await res.json()

      if (!json.status || !json.result) return m.reply('❌ Gagal mengambil video.')

      const { videos, thumb } = json.result

      const thumbContent = await generateWAMessageContent(
        { image: { url: thumb } },
        { upload: conn.waUploadToServer }
      )

      const downloadMsg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: {
                text: `✅ Pilih kualitas video, klik tombol untuk copy perintah lalu paste di chat:`
              },
              footer: {
                text: `🎬 Dari: ${text}`
              },
              header: {
                title: '🔞 Download Video',
                hasMediaAttachment: true,
                imageMessage: thumbContent.imageMessage
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                      display_text: '📥 Copy Low',
                      id: videos.low,
                      copy_code: `.xgetlow ${videos.low}`
                    })
                  },
                  {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                      display_text: '📥 Copy High',
                      id: videos.high,
                      copy_code: `.xgethigh ${videos.high}`
                    })
                  },
                  {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                      display_text: '📺 Copy HLS',
                      id: videos.HLS,
                      copy_code: `.xgethls ${videos.HLS}`
                    })
                  }
                ]
              }
            })
          }
        }
      }, { quoted: m })

      await conn.relayMessage(m.chat, downloadMsg.message, { messageId: downloadMsg.key.id })

    } catch (err) {
      console.error('❌ Error download:', err)
      m.reply('❌ Terjadi kesalahan saat mengambil data video.')
    }
  }

  if (/^xget(low|high|hls)$/i.test(command)) {
    if (!text || !text.startsWith('http')) return m.reply('❌ URL tidak valid.')

    try {
      await m.reply('⏳ Mengunduh dan mengirim video, mohon tunggu...')
      await conn.sendMessage(m.chat, {
        video: { url: text },
        caption: '✅ Berikut video yang kamu minta.'
      }, { quoted: m })
    } catch (err) {
      console.error('❌ Error kirim video:', err)
      m.reply('❌ Gagal mengirim video. Mungkin ukuran file terlalu besar atau tidak tersedia.')
    }
  }
}

handler.help = ['xn', 'xns', 'xpdl', 'xgetlow', 'xgethigh', 'xgethls']
handler.tags = ['nsfw']
handler.command = /^(xn|xns|xpdl|xgetlow|xgethigh|xgethls)$/i

export default handler