import axios from 'axios';

const handler = async (m, { conn, command }) => {
  try {
    const res = await axios.get('https://api.siputzx.my.id/api/berita/cnbcindonesia');
    const data = res.data;

    if (!data.status || !data.data || data.data.length === 0) {
      return m.reply('❌ Tidak ada berita ditemukan.');
    }

    // Reaksi
    await conn.sendMessage(m.chat, { react: { text: '📢', key: m.key } });

    // Ambil 5 berita pertama
    const beritaList = data.data.slice(0, 5);
    for (const item of beritaList) {
      await conn.sendMessage(m.chat, {
        image: { url: item.image },
        caption: `📰 *${item.title}*\n\n${item.label || ''}`,
        footer: 'Klik tombol di bawah untuk membaca lengkap.',
        templateButtons: [
          {
            index: 1,
            urlButton: {
              displayText: '🌐 Baca Selengkapnya',
              url: item.link
            }
          }
        ]
      }, { quoted: m });
    }

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (e) {
    console.error(e);
    m.reply('❌ Gagal mengambil berita CNBC.');
  }
};

handler.command = /^beritacnbc$/i;
handler.tags = ['news'];
handler.help = ['beritacnbc'];
handler.limit = true;

export default handler;