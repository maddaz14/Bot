import axios from "axios";
import crypto from "crypto";

// ─────────── API CLIENT ───────────
class DeepFakeMakerClient {
  constructor() {
    this.baseUrl = "https://apiv1.deepfakemaker.io";
    this.PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDa2oPxMZe71V4dw2r8rHWt59gH
W5INRmlhepe6GUanrHykqKdlIB4kcJiu8dHC/FJeppOXVoKz82pvwZCmSUrF/1yr
rnmUDjqUefDu8myjhcbio6CnG5TtQfwN2pz3g6yHkLgp8cFfyPSWwyOCMMMsTU9s
snOjvdDb4wiZI8x3UwIDAQAB
-----END PUBLIC KEY-----`;
    this.appId = "ai_df";
    this.appSecret = "NHGNy5YFz7HeFb";
    this.userID = DeepFakeMakerClient.randomString(64);
  }

  static randomString(n = 16) {
    return Array.from({ length: n }, () =>
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(
        Math.floor(Math.random() * 62)
      )
    ).join("");
  }

  static aesEncryptBase64(text, keyStr) {
    const buf = Buffer.from(keyStr, "utf8");
    const cipher = crypto.createCipheriv("aes-128-cbc", buf, buf);
    let enc = cipher.update(text, "utf8", "base64");
    return enc + cipher.final("base64");
  }

  generateParams() {
    const t = Math.floor(Date.now() / 1000);
    const nonce = this.userID;
    const secret = DeepFakeMakerClient.randomString(16);
    const secret_key = crypto
      .publicEncrypt(
        { key: this.PUBLIC_KEY, padding: crypto.constants.RSA_PKCS1_PADDING },
        Buffer.from(secret, "utf8")
      )
      .toString("base64");
    const signPayload = `${this.appId}:${this.appSecret}:${t}:${nonce}:${secret_key}`;
    const sign = DeepFakeMakerClient.aesEncryptBase64(signPayload, secret);
    return { app_id: this.appId, t, nonce, sign, secret_key };
  }

  async getUploadSign(fileBuffer) {
    const resp = await axios.post(
      `${this.baseUrl}/api/user/v2/upload-sign`,
      {
        filename: `NB_${DeepFakeMakerClient.randomString(32)}_${Date.now()}.png`,
        hash: crypto.createHash("sha256").update(fileBuffer).digest("hex"),
        user_id: this.userID,
      },
      {
        params: this.generateParams(),
        headers: {
          accept: "*/*",
          "content-type": "application/json",
          origin: "https://deepfakemaker.io",
          referer: "https://deepfakemaker.io/",
        },
      }
    );
    return resp.data.data;
  }

  async uploadFileToUrl(fileBuffer) {
    const { url, object_name } = await this.getUploadSign(fileBuffer);
    await axios.put(url, fileBuffer, {
      headers: {
        "Content-Type": "image/png",
        "Content-Length": fileBuffer.length,
      },
    });
    return `https://cdn.deepfakemaker.io/${object_name}`;
  }

  async createTask(prompt, imageUrl, output_format = "png") {
    const resp = await axios.post(
      `${this.baseUrl}/api/replicate/v1/free/nano/banana/task`,
      {
        prompt,
        platform: "nano_banana",
        images: [imageUrl],
        output_format,
        user_id: this.userID,
      },
      {
        params: this.generateParams(),
        headers: {
          accept: "*/*",
          "content-type": "application/json",
          origin: "https://deepfakemaker.io",
          referer: "https://deepfakemaker.io/",
        },
      }
    );
    return resp.data.data.task_id;
  }

  async waitForTask(taskId) {
    while (true) {
      const resp = await axios.get(
        `${this.baseUrl}/api/replicate/v1/free/nano/banana/task`,
        {
          params: { ...this.generateParams(), task_id: taskId, user_id: this.userID },
          headers: {
            accept: "*/*",
            origin: "https://deepfakemaker.io",
            referer: "https://deepfakemaker.io/",
          },
        }
      );
      const body = resp.data;
      if (body && body.msg === "success" && body.data) {
        return body.data;
      } else if (body && body.msg !== "processing" && body.data) {
        throw body.msg;
      }
      await new Promise((res) => setTimeout(res, 5000));
    }
  }
}

// ─────────── HANDLER ───────────
let handler = async (m, { conn, usedPrefix }) => {
  try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";
    if (!mime.startsWith("image/")) {
      throw `⚠️ Kirim atau reply gambar grup dengan caption *${usedPrefix}tostudioportrait*`;
    }

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    let media = await q.download();
    if (!media) throw new Error("Gagal download media!");

    const DeepFakeMaker = new DeepFakeMakerClient();
    const uploadUrl = await DeepFakeMaker.uploadFileToUrl(media);

    // Prompt Disesuaikan: Ganti pilihan di bawah sesuai keinginan Anda
    const prompt = `
Gunakan foto grup yang saya unggah ini. Ubah menjadi potret studio profesional.

Latar Belakang & Cahaya: Ganti latar belakangnya menjadi backdrop studio mulus berwarna abu-abu terang. Gunakan pencahayaan studio yang lembut dan merata untuk menonjolkan setiap wajah dengan jelas.

Pakaian: Ubah pakaian kami menjadi tema yang serasi, misalnya semua mengenakan blazer dengan kemeja putih.

Pose & Ekspresi: Pertahankan posisi dan pose umum kami dari foto asli, tetapi buat ekspresi kami tersenyum tipis dan profesional. Fokus pada menjaga kemiripan wajah setiap orang.

Detail Penting: Hasil akhir harus fotorealistik, tajam, dan berkualitas tinggi, seperti diambil oleh fotografer studio.
`;

    const taskId = await DeepFakeMaker.createTask(prompt, uploadUrl);
    const result = await DeepFakeMaker.waitForTask(taskId);

    // ambil hasil dari semua kemungkinan field
    let urls = [];
    if (Array.isArray(result?.images)) urls = result.images;
    else if (Array.isArray(result?.output)) urls = result.output;
    else if (typeof result?.output_url === "string") urls = [result.output_url];
    else if (typeof result?.url === "string") urls = [result.url];
    else if (typeof result?.generate_url === "string") urls = [result.generate_url];

    if (urls.length === 0) {
      console.log("DEBUG FULL RESULT:", result);
      throw new Error("❌ Tidak ada gambar yang dihasilkan dari API.");
    }

    for (let url of urls) {
      await conn.sendMessage(
        m.chat,
        { image: { url }, caption: "✨ Potret Studio Profesional siap!" },
        { quoted: m }
      );
    }

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (err) {
    console.error("PLUGIN tostudioportrait ERROR:", err);
    m.reply("💥 Error: " + (err.message || err));
  }
};

handler.command = /^tostudioportrait$/i;
handler.help = ["tostudioportrait"];
handler.tags = ["ai"];

export default handler;