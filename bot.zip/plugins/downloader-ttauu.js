import fetch from 'node-fetch'

let handler = async (m, { conn, args, usedPrefix, command }) => {
  const url = args[0]

  if (!url) {
    return m.reply(`❌ Link tidak ditemukan.\n\nContoh:\n${usedPrefix + command} https://vm.tiktok.com/ZSk5Xj2Ej/`)
  }

  // Kirim emoji reaksi saat mulai proses
  if (conn.sendMessage) {
    await conn.sendMessage(m.chat, {
      react: {
        text: '🍏',
        key: m.key
      }
    })
  }

  const apiDomain = global.ubedAPI?.domain || 'https://api.ubed.my.id'
  const apiKey = global.ubedAPI?.key || 'YOUR_DEFAULT_API_KEY'
  const endpoint = `${apiDomain}/download/Tiktok-audio?apikey=${apiKey}&url=${encodeURIComponent(url)}`

  try {
    const res = await fetch(endpoint)
    if (!res.ok) throw new Error(`Gagal fetch API: ${res.statusText}`)

    const json = await res.json()
    if (!json.status || !json.result?.audio_url) {
      throw new Error('❌ Tidak bisa mengambil audio TikTok. Cek kembali linknya.')
    }

    await conn.sendMessage(m.chat, {
      audio: { url: json.result.audio_url },
      mimetype: 'audio/mpeg',
      ptt: false
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply(`❌ Error saat mengambil audio:\n${err.message}`)
  }
}

handler.help = ['tiktokaudio <url>']
handler.tags = ['downloader']
handler.command = /^tiktokaudio|ttaudio$/i
handler.limit = true

export default handler