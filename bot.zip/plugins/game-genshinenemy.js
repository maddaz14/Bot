import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text) {
    try {
      const list = await genshindb.enemies("names", { matchCategories: true });
      return m.reply(`👹 *Daftar Musuh yang Tersedia:*\n\n${list.join(", ")}`);
    } catch (e) {
      console.error('[ENEMY LIST ERROR]', e);
      return m.reply('❌ Gagal mengambil daftar musuh.');
    }
  }

  try {
    const result = await genshindb.enemies(text);

    if (result) {
      let response = `👹 *Musuh Ditemukan: ${result.name}*\n\n`;
      response += `📖 _${result.description || "Deskripsi tidak tersedia"}_\n\n`;
      response += `🔢 *Level:* ${result.level || "Tidak diketahui"}\n`;
      response += `⭐ *Rarity:* ${result.rarity || "Tidak diketahui"}\n`;
      response += `🔥 *Element:* ${result.element || "Tidak diketahui"}`;
      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[ENEMY ERROR]', err);
    try {
      const available = await genshindb.enemies("names", { matchCategories: true });
      return m.reply(`❌ Musuh '${text}' tidak ditemukan.\n\n📜 *Musuh yang tersedia:*\n${available.join(", ")}`);
    } catch (e) {
      return m.reply('⚠️ Gagal menampilkan daftar musuh.');
    }
  }
};

handler.help = ['genshin-enemy <nama musuh>'];
handler.tags = ['game'];
handler.command = /^(genshin-enemy|g-enemy|gens-enemy)$/i;
handler.limit = 1;
handler.register = true;

export default handler;