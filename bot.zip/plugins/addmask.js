import axios from 'axios';

let handler = async (m, { conn, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (!mime) throw `Kirim gambar dengan caption *${usedPrefix}${command}* atau reply gambar yang ingin diberi masker.`;

    if (!/image\/(jpe?g|png)/.test(mime)) throw `File yang kamu kirim bukan gambar! Hanya format JPG/JPEG/PNG yang didukung.`;

    try {
        // Reaksi awal bahwa proses dimulai
        await conn.sendMessage(m.chat, { react: { text: '🍏', key: m.key } });

        // Download gambar sebagai buffer
        const imgBuffer = await q.download();

        // Upload ke Catbox
        const FormData = (await import('form-data')).default; // Dinamis import
        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', imgBuffer, { filename: 'image.jpg', contentType: mime }); // Sertakan filename & contentType

        const catboxRes = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: form.getHeaders(),
        });

        const catboxUrl = catboxRes.data;
        if (!catboxUrl || typeof catboxUrl !== 'string' || !catboxUrl.includes('catbox.moe')) {
            console.error("Catbox upload failed, response:", catboxUrl);
            throw 'Gagal upload gambar ke Catbox.';
        }

        // Panggil API maskerkan dengan URL dari Catbox
        const apiKey = "free1"; // API Key untuk maskerkan
        const apiUrl = `https://api.ubed.my.id/ai/maskerkan?apikey=${apiKey}&url=${encodeURIComponent(catboxUrl)}`;
        
        const { data: processedImageBuffer } = await axios.get(apiUrl, { responseType: 'arraybuffer' });

        if (!processedImageBuffer || processedImageBuffer.byteLength < 100) { // Cek sederhana jika buffer kosong/terlalu kecil
             throw 'Gagal mendapatkan gambar yang diproses dari API.';
        }

        // Kirim gambar hasil proses ke pengguna
        await conn.sendMessage(m.chat, {
            image: processedImageBuffer,
            caption: `😷 Ini dia gambarnya, sudah diberi masker!`,
        }, { quoted: m });

        // Reaksi bahwa proses selesai dengan sukses
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error("Error in maskerkan handler:", err);
        // Kirim reaksi gagal jika memungkinkan, sebelum pesan error teks
        try {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        } catch (reactErr) {
            console.error("Failed to send error reaction:", reactErr);
        }
        
        let errorMessage = '❌ Terjadi kesalahan saat memproses gambar.';
        if (err.message) {
            // Jika ada pesan error spesifik, tambahkan (misalnya dari throw 'Gagal upload...')
            if (err.message.includes('Gagal upload') || err.message.includes('Gagal mendapatkan gambar')) {
                errorMessage = `❌ ${err.message}`;
            } else if (err.response && err.response.status) {
                 errorMessage += ` (Status: ${err.response.status})`;
            }
        }
        await conn.reply(m.chat, errorMessage, m);
    }
};

handler.help = ['maskerkan'];
handler.tags = ['ai', 'image'];
handler.command = /^(maskerkan|addmask)$/i;
handler.limit = 1;
handler.register = true; 
handler.premium = false;

export default handler;