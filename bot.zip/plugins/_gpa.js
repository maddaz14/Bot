import fs from 'fs'
import axios from 'axios'
import chalk from 'chalk'

// Konfigurasi GitHub
const GITHUB_TOKEN = "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"
const REPO_OWNER = "obet24077"
const REPO_NAME = "Api-Nooriko"
const BRANCH = "main"

let handler = async (m, { text, usedPrefix, command, conn }) => {
  if (!text) {
    throw `
Penggunaan: ${usedPrefix}${command} <nama file>
Contoh: ${usedPrefix}gpa tools-tourl-quax
`.trim()
  }

  // Tambahkan .js secara otomatis jika tidak ada
  const filename = text.trim().endsWith('.js') ? text.trim() : text.trim() + '.js'
  const filePath = `src/${filename}`
  
  try {
    const url = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${filePath}?ref=${BRANCH}`

    // Panggil API GitHub untuk mendapatkan konten file
    const res = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${GITHUB_TOKEN}`,
        'Accept': 'application/vnd.github.v3.raw' // Penting untuk mendapatkan konten mentah
      },
    })
    
    // Kirim konten file langsung sebagai blok kode
    await conn.sendMessage(m.chat, { text: '```javascript\n' + res.data + '\n```' }, { quoted: m })

    console.log(chalk.green(`[GITHUB FETCH] '${filename}' sukses.`))

  } catch (e) {
    console.error(chalk.red(`[GET PLUGIN ERROR] ${filename}:`), e)
    
    // Tangani error 404 (file tidak ditemukan)
    if (e.response && e.response.status === 404) {
        throw `❌ File *${filename}* tidak ditemukan di repositori.`
    }
    
    throw `❌ Gagal mengambil file dari GitHub: ${e.message}`
  }
}

handler.help = ['gpa <filename>']
handler.tags = ['owner']
handler.command = /^gpa$/i
handler.rowner = true

export default handler