// plugins/tools-hitamkan-buffer.js
import fetch from 'node-fetch'
import FormData from 'form-data'
import { fileTypeFromBuffer } from 'file-type'

let handler = async (m, { conn }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

        // Ambil media dari reply atau pesan itu sendiri
        let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || q.mediaType || ''
        if (!mime || mime === 'conversation') return m.reply('Kirim atau reply gambar dulu bangg.')

        let media = await q.download?.()
        if (!media) return m.reply('Gagal mendownload file.')

        // Upload ke Qu.ax
        let quaxLink = await quaxUpload(media)
        await conn.sendMessage(m.chat, { text: '✅ Berhasil upload. Memproses...' }, { quoted: m })

        // Fetch langsung buffer dari API hitamkan
        const res = await fetch(`https://apiku.ubed.my.id/api/hitamkan?url=${encodeURIComponent(quaxLink)}`)
        if (!res.ok) throw new Error('Gagal memproses API hitamkan.')
        const buffer = Buffer.from(await res.arrayBuffer())

        // Deteksi MIME
        const { ext, mime: detectedMime } = await fileTypeFromBuffer(buffer) || { ext: 'jpg', mime: 'image/jpeg' }

        // Kirim ke WhatsApp
        await conn.sendMessage(m.chat, { 
            image: buffer, 
            caption: '✅ Hasil hitamkan', 
            mimetype: detectedMime 
        }, { quoted: m })

    } catch (error) {
        conn.sendMessage(m.chat, { text: `Error: ${error.message || error}` }, { quoted: m })
    }
}

handler.help = ['hitamkan']
handler.tags = ['tools']
handler.command = /^(hitamkan)$/i
handler.owner = false
export default handler

// Fungsi upload Qu.ax
async function quaxUpload(buffer) {
    const { ext, mime } = await fileTypeFromBuffer(buffer) || { ext: 'bin', mime: 'application/octet-stream' }
    const form = new FormData()
    form.append('files[]', buffer, { filename: `file.${ext}`, contentType: mime })
    form.append('expiry', '30') // 30 hari expired

    const res = await fetch('https://qu.ax/upload.php', {
        method: 'POST',
        headers: {
            'User-Agent': 'Mozilla/5.0',
            'origin': 'https://qu.ax',
            'referer': 'https://qu.ax/'
        },
        body: form
    })

    if (!res.ok) throw new Error('Gagal menghubungi Qu.ax.')
    const json = await res.json()
    if (!json.files || !json.files[0] || !json.files[0].url) throw new Error('Respon tidak valid dari Qu.ax.')
    return json.files[0].url
}