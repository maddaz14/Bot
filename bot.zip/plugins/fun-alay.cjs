const fetch = require('node-fetch')

let handler = async (m, { conn, text }) => {
 if (!text) return m.reply('Masukkan teks yang ingin diubah ke gaya alay\nContoh: .alay Hello World')
 
 try {
 await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
 
 const url = `https://api.siputzx.my.id/api/fun/alay?text=${encodeURIComponent(text)}`
 const response = await fetch(url)
 if (!response.ok) throw 'Gagal mengubah teks'
 
 const json = await response.json()
 if (!json.status) throw 'Gagal memproses teks'

 // Format the response
 let message = `*🔠 Hasil Konversi Alay:*\n\n`
 message += `*Teks Asli:* ${text}\n`
 message += `*Teks Alay:* ${json.result}`

 // Send the message
 await conn.sendMessage(m.chat, { 
 text: message,
 mentions: [m.sender]
 }, { quoted: m })

 await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
 } catch (e) {
 console.error(e)
 await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
 m.reply('Gagal mengubah teks. Coba lagi nanti.')
 }
}

handler.help = ['alay <teks>']
handler.tags = ['fun']
handler.command = /^(alay|alaytext)$/i
handler.limit = true

module.exports = handler