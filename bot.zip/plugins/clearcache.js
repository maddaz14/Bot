let handler = async (m, { conn, text }) => {
  // Hanya Owner yang bisa
  if (!['6285147777105@s.whatsapp.net', '6281399172380@s.whatsapp.net'].includes(m.sender)) {
    return m.reply('❌ Hanya Owner Bot yang bisa menggunakan perintah ini!')
  }

  let users = global.db.data.users
  let before = Object.keys(users).length
  let deleted = 0

  for (let jid in users) {
    if (!users[jid].registered) {
      delete users[jid]
      deleted++
    }
  }

  let after = Object.keys(users).length
  m.reply(`✅ Berhasil menghapus ${deleted} user yang belum registrasi.\n📌 Total sebelumnya: ${before}\n📌 Total sekarang: ${after}`)
}

handler.help = ['clearcacheunreg']
handler.tags = ['owner']
handler.command = /^clearcache$/i
handler.owner = true

export default handler