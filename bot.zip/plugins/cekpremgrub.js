let handler = async (m, { conn }) => {
  if (!m.isGroup) return m.reply('❌ Fitur ini hanya bisa digunakan di dalam grup.');

  const chatData = global.db.data.chats[m.chat] || {};
  const isPremium = chatData.isPremiumGroup;
  const expired = chatData.premiumGroupExpire || 0;
  const sisa = expired - Date.now();

  if (isPremium && sisa > 0) {
    return m.reply(`✨ *Grup Premium Aktif*\n\n📅 *Berakhir:* ${new Date(expired).toLocaleString()}\n⏳ *Sisa Waktu:* ${clockString(sisa)}`);
  } else {
    return m.reply(`❌ Grup ini *bukan* premium atau masa aktifnya sudah habis.\n\nSilakan minta owner bot untuk mengaktifkan premium dengan perintah:\n*.addpremgrub <jumlah hari>*`);
  }
};

handler.help = ['cekpremgrub', 'checkgrupprem'];
handler.tags = ['info', 'group'];
handler.command = /^(cekpremgrub|checkgrupprem)$/i;
handler.group = true;

export default handler;

// Fungsi untuk ubah ms ke format waktu
function clockString(ms) {
  if (isNaN(ms)) return '--';
  let d = Math.floor(ms / 86400000);
  let h = Math.floor(ms / 3600000) % 24;
  let m = Math.floor(ms / 60000) % 60;
  let s = Math.floor(ms / 1000) % 60;
  return `${d} hari, ${h} jam, ${m} menit, ${s} detik`;
}