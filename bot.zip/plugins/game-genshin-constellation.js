import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text) return m.reply(`Contoh: *${usedPrefix + command} diluc*\nHarap berikan nama karakter untuk mencari konstelasinya.`);

  try {
    const result = await genshindb.constellations(text);
    if (result && result.length > 0) {
      let response = `✨ *Konstelasi untuk Karakter: ${text}*\n\n`;
      result.forEach((c, i) => {
        response += `🔹 *${i + 1}. ${c.name}*\n`;
        response += `_${c.effect}_\n`;
        response += `🔓 *Unlock:* C${c.unlock || "?"}\n\n`;
      });
      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[CONSTELLATION ERROR]', err);
    return m.reply(`❌ Konstelasi untuk karakter '${text}' tidak ditemukan.`);
  }
};

handler.help = ['genshin-constellation <karakter>'];
handler.tags = ['game'];
handler.command = /^(genshin-const|g-const|gens-const|genshin-constellation|g-constellation|gens-constellation)$/i;
handler.limit = 1;
handler.register = true;

export default handler;