import yts from "yt-search";
import axios from 'axios';

// Fungsi global loading dengan reaction 🍏
global.loading = async (m, conn, end = false) => {
  if (!end) {
    return conn.sendMessage(m.chat, {
      react: {
        text: '🍏',
        key: m.key
      }
    });
  }
};

const downloadYouTube = async (url, format = 'mp3') => {
  try {
    const api = `https://api.cloudhostid.biz.id/downloader/ytmp3?url=${encodeURIComponent(url)}&format=${format}`
    const { data } = await axios.get(api)
    if (!data.status) return { status: false, error: 'Gagal download video.' }

    return {
      status: true,
      result: data.result
    }
  } catch (e) {
    return { status: false, error: e.message }
  }
}

let handler = async (m, { conn, args }) => {
  if (!args[0]) return m.reply("Masukkan Judul Lagu, contoh .playch souqy asbsk");

  let query = args.join(" ");
  await global.loading(m, conn);

  try {
    const search = await yts(query);
    if (!search || !search.videos.length) return m.reply("❌ *Lagu tidak ditemukan!*");

    const video = search.videos[0];
    const ytmp3 = await downloadYouTube(video.url, 'mp3');

    if (!ytmp3.status) {
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        return m.reply(`❌ *Gagal mengunduh audio!*`);
    }

    const {
      download: audioUrl,
      title,
      thumbnail
    } = ytmp3.result;

    // Mengirim audio ke channel yang ditentukan oleh global.ch
    await conn.sendMessage(global.ch, {
      audio: { url: audioUrl },
      mimetype: "audio/mpeg",
      ptt: true,
      fileName: `${title}.mp3`,
      contextInfo: {
        externalAdReply: {
          title: title,
          body: video.author.name,
          thumbnailUrl: thumbnail,
          mediaUrl: video.url,
          mediaType: 1,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m });

    // ✅ Berhasil kirim audio, beri reaction di chat asli
    await conn.sendMessage(m.chat, {
      react: {
        text: '✅',
        key: m.key
      }
    });

  } catch (e) {
    console.error(e);
    m.reply("❌ *Terjadi kesalahan saat memproses permintaan!*");
  } finally {
    await global.loading(m, conn, true);
  }
};

handler.help = ["playch"];
handler.tags = ["downloader"];
handler.command = /^(playch)$/i;
handler.owner = true;

export default handler;