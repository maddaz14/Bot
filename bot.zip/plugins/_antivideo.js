export async function before(m, { conn, isAdmin, isBotAdmin }) {
    if (m.isBaileys && m.fromMe) return true;
    if (!m.isGroup) return true;

    let chat = global.db.data.chats[m.chat];
    if (!chat || !chat.antiVideo) return true;

    const isVideo = m.mtype === 'videoMessage';
    const pengirim = m.key.participant || m.sender;
    const idPesan = m.key.id;
    const nama = await conn.getName(m.sender);

    if (!isVideo) return true;

    if (!isBotAdmin) {
        await m.reply(`⚠️ *ANTI VIDEO*\n${nama}, kamu mengirim video, tapi saya bukan admin jadi tidak bisa menghapus.`);
        return true;
    }

    await m.reply(`🚫 *ANTI VIDEO*\nVideo terdeteksi dan akan dihapus.`);

    return conn.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: idPesan,
            participant: pengirim
        }
    });
}