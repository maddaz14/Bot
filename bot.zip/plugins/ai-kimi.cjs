const fetch = require('node-fetch');

// Objek kontak dummy (Opsional)
const fkontak = {
  key: {
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast',
    fromMe: false,
    id: 'Halo',
  },
  message: {
    conversation: `🧠 Ask Kimi AI by ${global.namebot}`,
  },
};

// Handler utama untuk plugin
let handler = async (m, { conn, text, usedPrefix, command }) => {
  // Pastikan pengguna menyertakan pertanyaan
  if (!text) {
    return conn.reply(m.chat, `⚠️ Masukkan pertanyaan untuk AI Kimi.\nContoh: *${usedPrefix + command} apa makna hidup?*`, m, { quoted: fkontak });
  }

  try {
    // Kirim reaksi '⏳' untuk menandakan sedang diproses
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    // Panggil API Kimi
    const url = `https://api.siputzx.my.id/api/ai/kimi?content=${encodeURIComponent(text)}`;
    const res = await fetch(url);
    
    // Periksa status respons
    if (!res.ok) {
      throw new Error(`Gagal terhubung ke API. Status: ${res.status}`);
    }

    const json = await res.json();

    // Periksa jika status API false atau tidak ada respons
    if (!json.status || !json.data) {
        const errorMessage = json.message || 'AI tidak dapat memberikan jawaban untuk pertanyaan Anda.';
        return conn.reply(m.chat, `❌ ${errorMessage}`, m);
    }
    
    const response = json.data;

    // Kirim jawaban dari AI Kimi
    await conn.reply(m.chat, response, m);

    // Kirim reaksi '✅' setelah berhasil
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error(e);
    // Kirim reaksi '❌' jika terjadi error
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    conn.reply(m.chat, `❌ Terjadi kesalahan: ${e.message}`, m);
  }
};

// Pengaturan metadata plugin
handler.help = ['kimi'];
handler.tags = ['ai'];
handler.command = /^(kimi)$/i;
handler.limit = true;
handler.register = true;

module.exports = handler;