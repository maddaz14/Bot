const isToxic = /\b(wa\.me|anjing|anjg|ajg|anj|lonte|lont|kontol|kont|kntl|memek|mmk|memk|yatim|yatm|ytm|puki|pukimak|puqimak|asu|asw|bajingan|tempek|ngentod|ngntd|penis|peler|pepek|tolol|goblok|gblk|anjim|entod|entd|ngewe)\b/i;

export async function before(m, { conn, isBotAdmin }) {
  if (m.isBaileys && m.fromMe) return true;
  if (!m.isGroup || !m.text) return true;

  const chat = global.db.data.chats[m.chat];
  if (!chat || !chat.antiToxic) return true;

  const text = m.text.toLowerCase();
  const found = isToxic.exec(text);
  if (!found) return true;

  let kata = found[0];
  let idPesan = m.key.id;
  let pengirim = m.key.participant || m.sender;

  // Kalau bot bukan admin
  if (!isBotAdmin) {
    await m.reply(`*「 ANTI TOXIC 」*\nPesan mengandung kata kasar *(${kata})*, tapi saya bukan admin jadi tidak bisa menghapus.`);
    return true;
  }

  // Kasih notifikasi lalu hapus pesan
  await m.reply(`*「 ANTI TOXIC 」*\nPesan mengandung kata kasar *(${kata})*, dan telah dihapus oleh bot.`);

  return conn.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      fromMe: false,
      id: idPesan,
      participant: pengirim
    }
  });
}