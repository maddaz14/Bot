import axios from 'axios';

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    const res = await axios.get('https://api.siputzx.my.id/api/berita/antara');
    const data = res.data;

    if (!data.status || !data.data || data.data.length === 0) {
      return m.reply('❌ Tidak ada berita tersedia.');
    }

    await conn.sendMessage(m.chat, { react: { text: '📰', key: m.key } });

    for (let item of data.data.slice(0, 5)) {
      await conn.sendMessage(m.chat, {
        image: { url: item.image },
        caption: `📰 *${item.title}*\n📂 Kategori: ${item.category}\n🔗 ${item.link}`
      }, { quoted: m });
    }

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    console.error(err);
    m.reply('❌ Terjadi kesalahan saat mengambil data berita.');
  }
};

handler.help = ['beritaantara'];
handler.tags = ['news'];
handler.command = /^beritaantara$/i;
handler.limit = true;

export default handler;