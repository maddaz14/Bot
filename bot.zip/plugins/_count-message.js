export async function all(m) {
  if (!m.isGroup) return // hanya di grup

  let chat = global.db.data.chats[m.chat]
  if (!chat) chat = global.db.data.chats[m.chat] = {}

  if (!chat.totalPesan) chat.totalPesan = {} // simpan di object per user

  let count = chat.totalPesan[m.sender] || 0
  chat.totalPesan[m.sender] = count + 1
}