import axios from 'axios';
import * as cheerio from "cheerio";

// Channel WA tujuan (Opsional, hanya untuk contoh)
// const CHANNEL_ID = '120363369035192952@newsletter'; 

// --- FUNGSI SCRAPE API KEY (getApikey2) ---
// CATATAN: Fungsi ini sangat tidak stabil dan rentan rusak.
async function getApikey2() {
    try {
        const anu = await axios.get('https://chatgpt5free.com/chat/')
        const $ = cheerio.load(anu.data)
        let key;
        // Mencari API key yang terselip dalam tag <script>
        $('script').each((i, el) => {
            let html = $(el).html()
            let src = html.match(/sk-proj-[A-Za-z0-9_\-]{80,}/);
            if (src) key = src ? src[0] : null
        })
        return key
    } catch (e) {
        console.error("Gagal melakukan scraping API Key:", e.message);
        return null;
    }
}

// --- FUNGSI UTAMA CHATBOT (gpt5Chat) ---
async function gpt5Chat(history) {
    // 1. Dapatkan API Key
    const apikey = await getApikey2()
    if (!apikey) throw new Error("Gagal mendapatkan API Key dari situs.");

    // 2. Kirim Request ke API (Endpoint/Model ini sangat diragukan keasliannya)
    const res = await axios.post("https://api.openai.com/v1/responses", {
        model: "gpt-5",
        input: JSON.stringify(history),
    }, {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + apikey
        }
    });

    // 3. Parsing Response
    let teks = [];
    if (res.data && res.data.output) {
        for (let out of res.data.output) {
            if (out.content) {
                for (let c of out.content) {
                    if (c.type === "output_text") teks.push(c.text);
                }
            }
        }
    }
    
    if (teks.length === 0) {
        throw new Error("Respon dari API kosong atau format respons berubah.");
    }
    
    return teks.join("\n");
}


// --- HANDLER PLUGINS SIAP PAKAI ---
const handler = async (m, { conn, text, command }) => {
    if (!text) {
        return m.reply(`🤖 Hai! Tanyakan apa saja padaku.\n\nContoh: *${command}* siapa presiden pertama indonesia`);
    }

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    // Format history chat (disederhanakan untuk prompt tunggal)
    const history = [
        { role: "user", content: text }
    ];

    try {
        const responseText = await gpt5Chat(history);
        
        await conn.reply(m.chat, responseText, m);
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (e) {
        // Tampilkan error jika scraping gagal atau API menolak request
        console.error(`[GPT-5 ERROR]`, e);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        
        let errorMessage = `❌ Gagal mendapatkan jawaban dari GPT-5.\n\nDetail: ${e.message}`;
        if (e.message.includes("API Key")) {
            errorMessage += "\n\n⚠️ Penyebab paling mungkin: Situs sumber API Key (*chatgpt5free.com*) telah mengubah kodenya, sehingga *scraping* gagal.";
        }
        
        m.reply(errorMessage);
    }
};

handler.help = ['gpt5 <prompt>', 'jipiti5 <prompt>'];
handler.tags = ['ai'];
handler.command = /^(gpt5|jipiti5)$/i;
handler.limit = true;

export default handler;