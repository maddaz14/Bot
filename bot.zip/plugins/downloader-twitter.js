import axios from 'axios'

const twitterDL = async (url) => {
  const { data } = await axios.get(`https://api.siputzx.my.id/api/d/twitter?url=${encodeURIComponent(url)}`)
  if (!data.status || !data.data?.downloadLink) {
    throw new Error('Gagal mengambil video dari Twitter/X.')
  }
  return data.data
}

const handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply('Masukkan URL Twitter/X!\n\nContoh: *.twitter https://x.com/user/status/123456*')

  await conn.sendMessage(m.chat, {
    react: {
      text: '🦊',
      key: m.key
    }
  })

  try {
    const res = await twitterDL(text)

    const caption = `*Judul:* ${res.videoTitle || '-'}\n*Deskripsi:*\n${res.videoDescription || '-'}`

    await conn.sendMessage(m.chat, {
      video: { url: res.downloadLink },
      caption
    }, { quoted: m })

    await conn.sendMessage(m.chat, {
      react: {
        text: '✅',
        key: m.key
      }
    })
  } catch (e) {
    m.reply(`❌ Error: ${e.message}`)
  }
}

handler.help = ['twitter <url>', 'x <url>']
handler.tags = ['downloader']
handler.command = ['twitter', 'x']

export default handler