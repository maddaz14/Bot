let handler = async (m, { conn }) => {
  // React emoji 🍏 saat mulai proses
  await conn.sendMessage(m.chat, {
    react: {
      text: '🍏',
      key: m.key
    }
  })

  const videos = [
    {"url":"https://e.top4top.io/m_1930ns2zo0.mp4"},
    {"url":"https://k.top4top.io/m_1930j9i810.mp4"},
    {"url":"https://f.top4top.io/m_1930wtj580.mp4"},
    {"url":"https://d.top4top.io/m_1930a2isv0.mp4"},
    {"url":"https://e.top4top.io/m_1930wbgc41.mp4"},
    {"url":"https://f.top4top.io/m_1930urbj02.mp4"},
    {"url":"https://b.top4top.io/m_1930ceiqv0.mp4"},
    {"url":"https://i.top4top.io/m_1931a0z6o0.mp4"},
    {"url":"https://a.top4top.io/m_193190b500.mp4"},
    {"url":"https://b.top4top.io/m_1931dcixz1.mp4"},
    {"url":"https://g.top4top.io/m_19317gpjp0.mp4"},
    {"url":"https://i.top4top.io/m_1931cc22w1.mp4"},
    {"url":"https://j.top4top.io/m_1931xn6412.mp4"},
    {"url":"https://g.top4top.io/m_1931silxz0.mp4"},
    {"url":"https://h.top4top.io/m_1931as4mg1.mp4"},
    {"url":"https://i.top4top.io/m_1931p9j5v0.mp4"},
    {"url":"https://e.top4top.io/m_1931mgeuy0.mp4"},
    {"url":"https://f.top4top.io/m_1931lw9381.mp4"},
    {"url":"https://g.top4top.io/m_1931vm0dk2.mp4"},
    {"url":"https://h.top4top.io/m_1931fiv8x3.mp4"},
    {"url":"https://b.top4top.io/m_1931jm3dt0.mp4"},
    {"url":"https://e.top4top.io/m_1931i7yag1.mp4"},
    {"url":"https://f.top4top.io/m_1931dr5ya2.mp4"},
    {"url":"https://g.top4top.io/m_193172kpg3.mp4"},
    {"url":"https://h.top4top.io/m_1931j3b224.mp4"},
    {"url":"https://j.top4top.io/m_19317ykt25.mp4"},
    {"url":"https://k.top4top.io/m_1931o0vh16.mp4"},
    {"url":"https://l.top4top.io/m_1931ssfbn7.mp4"},
    {"url":"https://a.top4top.io/m_19318t7458.mp4"},
    {"url":"https://b.top4top.io/m_1931vhu759.mp4"}
  ]

  let randomVideo = videos[Math.floor(Math.random() * videos.length)]

  await conn.sendMessage(m.chat, {
    video: { url: randomVideo.url },
    caption: '✅ Asupan Ukhty Video',
  }, { quoted: m })
}

handler.help = ['ukhtyvideo']
handler.tags = ['asupan']
handler.command = /^ukhtyvideo$/i

export default handler