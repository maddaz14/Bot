let handler = async (m, { conn }) => {
  // React emoji 🍏 saat mulai proses
  await conn.sendMessage(m.chat, {
    react: {
      text: '🍏',
      key: m.key
    }
  })

  const videos = [
{"url":"https://b.top4top.io/m_1930thxw90.mp4"},
{"url":"https://d.top4top.io/m_1930pezhp0.mp4"},
{"url":"https://c.top4top.io/m_1930cjgbx0.mp4"},
{"url":"https://b.top4top.io/m_1930v6vhg0.mp4"},
{"url":"https://f.top4top.io/m_1930uh7ud0.mp4"},
{"url":"https://a.top4top.io/m_1930c9cpb0.mp4"},
{"url":"https://k.top4top.io/m_19308amkf0.mp4"},
{"url":"https://d.top4top.io/m_1930wjaq60.mp4"},
{"url":"https://i.top4top.io/m_1930n2um40.mp4"},
{"url":"https://i.top4top.io/m_1930e14pi0.mp4"},
{"url":"https://i.top4top.io/m_1930w6lwf0.mp4"},
{"url":"https://e.top4top.io/m_19307autl0.mp4"},
{"url":"https://d.top4top.io/m_1930i6tfc0.mp4"},
{"url":"https://c.top4top.io/m_1930qmr7u0.mp4"},
{"url":"https://d.top4top.io/m_1930itbte1.mp4"},
{"url":"https://i.top4top.io/m_1930ze4oq0.mp4"},
{"url":"https://j.top4top.io/m_1930kkqyh1.mp4"},
{"url":"https://f.top4top.io/m_1930zevlz0.mp4"},
{"url":"https://g.top4top.io/m_1930q0apu1.mp4"},
{"url":"https://h.top4top.io/m_1930trfsv2.mp4"}
]

  let randomVideo = videos[Math.floor(Math.random() * videos.length)]

  await conn.sendMessage(m.chat, {
    video: { url: randomVideo.url },
    caption: '✅ Asupan panrika',
  }, { quoted: m })
}

handler.help = ['panrika']
handler.tags = ['asupan']
handler.command = /^panrika$/i

export default handler