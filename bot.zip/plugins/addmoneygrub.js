let handler = async (m, { conn, text, participants }) => {
  if (!text) throw "❌ Masukkan jumlah money yang ingin ditambahkan!";
  if (isNaN(text)) throw "❌ Masukkan angka yang valid!";

  let money = parseInt(text);
  let userDb = global.db.data.users;
  let addedUsers = 0;

  for (let member of participants) {
    // Pastikan kita dapat JID asli
    let jid = member.id || member.jid;

    // Handle @lid → @s.whatsapp.net
    if (jid.endsWith('@lid')) {
      const resolved = participants.find(p => p.id === jid || p.jid === jid);
      if (resolved?.jid?.endsWith('@s.whatsapp.net')) {
        jid = resolved.jid;
      } else {
        // Skip jika tidak bisa resolve
        continue;
      }
    }

    // Inisialisasi user jika belum ada
    if (!userDb[jid]) {
      userDb[jid] = {
        name: '',
        money: 0,
        limit: 10,
        premium: false,
        premiumTime: 0,
        // ...data default lain jika kamu pakai
      };
    }

    userDb[jid].money += money;
    addedUsers++;
  }

  conn.reply(m.chat, `✅ Berhasil menambahkan *${money.toLocaleString()} money* ke *${addedUsers} anggota* dalam grup ini!`, m);
};

handler.help = ["addmoneygrub <jumlah>"];
handler.tags = ["owner"];
handler.command = /^(addmoneygrub)$/i;
handler.owner = true;
handler.group = true;

export default handler;