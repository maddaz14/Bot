import { exec } from 'child_process'
import util from 'util'

const execPromise = util.promisify(exec)

let handler = async (m, { conn }) => {
  conn.sendMessage(m.chat, { text: '⏳ Mengecek ffmpeg di server...' }, { quoted: m })

  try {
    const { stdout } = await execPromise('ffmpeg -version')
    await conn.sendMessage(m.chat, {
      text: `✅ *ffmpeg tersedia!*\n\n\`\`\`\n${stdout.trim()}\n\`\`\``,
    }, { quoted: m })
  } catch (e) {
    await conn.sendMessage(m.chat, {
      text: `❌ *ffmpeg tidak ditemukan di server!*\nPastikan container/image kamu memiliki ffmpeg.`,
    }, { quoted: m })
  }
}

handler.help = ['cekffmpeg']
handler.tags = ['tools']
handler.command = ['cekffmpeg']

export default handler