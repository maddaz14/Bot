import axios from 'axios'
import * as cheerio from "cheerio"

const SITE_URL = 'https://instatiktok.com/'

async function instaTiktokDownloader(platform, inputUrl) {
  const form = new URLSearchParams()
  form.append('url', inputUrl)
  form.append('platform', platform)
  form.append('siteurl', SITE_URL)

  const res = await axios.post(`${SITE_URL}api`, form.toString(), {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'Origin': SITE_URL,
      'Referer': SITE_URL,
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      'X-Requested-With': 'XMLHttpRequest'
    }
  })

  const html = res?.data?.html
  if (!html || res?.data?.status !== 'success') throw 'Gagal mengambil data.'

  const $ = cheerio.load(html)
  const links = []
  $('a.btn[href^="http"]').each((_, el) => {
    const link = $(el).attr('href')
    if (link && !links.includes(link)) links.push(link)
  })

  if (links.length === 0) throw 'Link tidak ditemukan.'

  let download
  if (platform === 'instagram') {
    download = links
  } else if (platform === 'tiktok') {
    download = links.find(link => /hdplay/.test(link)) || links[0]
  } else if (platform === 'facebook') {
    download = links.at(-1)
  }

  return { platform, download }
}

function detectPlatform(url = '') {
  url = url.toLowerCase()
  if (url.includes('instagram.com')) return 'instagram'
  if (url.includes('tiktok.com')) return 'tiktok'
  if (url.includes('facebook.com') || url.includes('fb.watch')) return 'facebook'
  return null
}

const handler = async (m, { conn, args, usedPrefix, command, text }) => {
  const url = args[0] || text
  const platform = detectPlatform(url)

  if (!platform) {
    throw `*Link tidak valid atau tidak didukung!*\nHanya mendukung: Instagram, TikTok, Facebook.\n\nContoh:\n${usedPrefix + command} https://www.instagram.com/p/xxxx`
  }

  await conn.sendMessage(m.chat, {
    react: { text: '🔄', key: m.key }
  })

  try {
    const { download } = await instaTiktokDownloader(platform, url)

    if (Array.isArray(download)) {
      for (const link of download) {
        await conn.sendFile(m.chat, link, null, `✅ *${platform} media:*`, m)
      }
    } else {
      await conn.sendFile(m.chat, download, null, `✅ *${platform} media:*`, m)
    }

    await conn.sendMessage(m.chat, {
      react: { text: '✅', key: m.key }
    })

  } catch (e) {
    await conn.sendMessage(m.chat, {
      react: { text: '❌', key: m.key }
    })
    throw typeof e === 'string' ? e : e?.message
  }
}

handler.help = ['all'].map(v => v + ' <link>')
handler.tags = ['downloader']
handler.command = /^all$/i
handler.limit = true

export default handler