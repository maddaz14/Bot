const handler = async (m, { conn }) => {
    const participants = await conn.groupMetadata(m.chat).then(metadata => metadata.participants);
    let countIndonesia = 0;
    let countMalaysia = 0;
    let countUSA = 0;
    let countOther = 0;
    
    participants.forEach(participant => {
        const phoneNumber = participant.id.split('@')[0];
        if (phoneNumber.startsWith("62")) {
            countIndonesia++;
        } else if (phoneNumber.startsWith("60")) {
            countMalaysia++;
        } else if (phoneNumber.startsWith("1")) {
            countUSA++;
        } else if (phoneNumber.startsWith("+1")) {
            countOther++;
        } else {
            countOther++;
        }
    });

    conn.relayMessage(m.chat, {
        "pollResultSnapshotMessage": {
            "name": "Jumlah Anggota Grup Berdasarkan Negara:",
            "pollVotes": [
                {
                    "optionName": "Anggota Indonesia 🇮🇩",
                    "optionVoteCount": JSON.stringify(countIndonesia)
                }, 
                {
                    "optionName": "Anggota Malaysia 🇲🇾",
                    "optionVoteCount": JSON.stringify(countMalaysia)
                },
                {
                    "optionName": "Anggota USA + OTHER 🇺🇲",
                    "optionVoteCount": JSON.stringify(countUSA)
                },
                {
                    "optionName": "Anggota Negara lain 🏳️",
                    "optionVoteCount": JSON.stringify(countOther)
                }
            ]
        }
    }, { quoted: m });
}

handler.help = ['checkmember']
handler.tags = ['group']
handler.command = /^(checkmember)$/i
handler.premium = false
handler.group = true;
handler.admin = true;

export default handler