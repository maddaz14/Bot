import fetch from 'node-fetch'

let handler = async (m, { conn, args, usedPrefix, command }) => {
  const query = args.join(' ')
  if (!query) {
    return m.reply(`❓ Mau tanya apa?\n\nContoh:\n${usedPrefix + command} Siapa kamu`)
  }

  // Kirim reaksi 🍏 saat mulai memproses
  if (conn.sendMessage) {
    await conn.sendMessage(m.chat, {
      react: {
        text: '🍏',
        key: m.key
      }
    })
  }

  const apiDomain = global.maelyn?.domain || 'https://api.maelyn.sbs'
  const apiKey = global.maelyn?.key || 'YOUR-API-KEY'
  const endpoint = `${apiDomain}/api/blackbox/chat?q=${encodeURIComponent(query)}`

  try {
    const res = await fetch(endpoint, {
      headers: {
        'mg-apikey': apiKey
      }
    })

    if (!res.ok) throw new Error(`Gagal akses API: ${res.statusText}`)

    const json = await res.json()

    if (!json?.result) {
      throw new Error('❌ Gagal mendapatkan jawaban dari API.')
    }

    m.reply(json.result)
  } catch (err) {
    console.error(err)
    m.reply(`❌ Terjadi kesalahan:\n${err.message}`)
  }
}

handler.help = ['blackboxai <pertanyaan>', 'blackbox <pertanyaan>']
handler.tags = ['ai', 'tools']
handler.command = /^blackboxai|blackbox$/i
handler.limit = true

export default handler