// plugins/tofigure2.js
import axios from "axios"
import FormData from "form-data"
import crypto from "crypto"
import { fileTypeFromBuffer } from "file-type"

const BASE_URL = "https://ai-apps.codergautam.dev"

// === util kecil ===
function acakName(len = 10) {
  const chars = "abcdefghijklmnopqrstuvwxyz"
  return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join("")
}

async function autoregist() {
  const uid = crypto.randomBytes(12).toString("hex")
  const email = `figure${Date.now()}@nyahoo.com`

  const payload = {
    uid,
    email,
    displayName: acakName(),
    photoURL: "https://i.pravatar.cc/150",
    appId: "photogpt"
  }

  const res = await axios.post(`${BASE_URL}/photogpt/create-user`, payload, {
    headers: {
      "content-type": "application/json",
      "accept": "application/json",
      "user-agent": "okhttp/4.9.2"
    }
  })

  if (res.data?.success) return uid
  throw new Error("Register gagal: " + JSON.stringify(res.data))
}

async function img2img(imageBuffer, prompt, mime) {
  const uid = await autoregist()

  const ext = (await fileTypeFromBuffer(imageBuffer))?.ext || "jpg"
  const form = new FormData()
  form.append("image", imageBuffer, { filename: `input.${ext}`, contentType: mime || `image/${ext}` })
  form.append("prompt", prompt)
  form.append("userId", uid)

  const uploadRes = await axios.post(`${BASE_URL}/photogpt/generate-image`, form, {
    headers: {
      ...form.getHeaders(),
      "accept": "application/json",
      "user-agent": "okhttp/4.9.2",
      "accept-encoding": "gzip"
    },
    maxBodyLength: Infinity
  })

  if (!uploadRes.data?.success) throw new Error(JSON.stringify(uploadRes.data))

  const { pollingUrl } = uploadRes.data
  let status = "pending"
  let resultUrl = null

  while (status !== "Ready") {
    const pollRes = await axios.get(pollingUrl, {
      headers: { "accept": "application/json", "user-agent": "okhttp/4.9.2" }
    })
    status = pollRes.data?.status
    if (status === "Ready") {
      resultUrl = pollRes.data?.result?.url
      break
    }
    await new Promise(r => setTimeout(r, 3000))
  }

  if (!resultUrl) throw new Error("Gagal mendapatkan hasil gambar.")

  const resultImg = await axios.get(resultUrl, { responseType: "arraybuffer" })
  return Buffer.from(resultImg.data)
}

// === PROMPT FIGURE ===
const FIGURE_PROMPT = `
Using the nano-banana model, a commercial 1/7 scale figurine of the character in the picture was created, depicting a realistic style and a realistic environment.
The figurine is placed on a computer desk with a round transparent acrylic base. There is no text on the base.
The computer screen shows the Zbrush modeling process of the figurine.
Next to the computer screen is a BANDAI-style toy box with the original painting printed on it.
-- Render the scene in LANDSCAPE orientation (16:9 aspect ratio), wide-angle composition
`.trim()

// === handler .tofigure2 ===
let handler = async (m, { conn, args }) => {
  try {
    if (m._tofigure2_done) return
    m._tofigure2_done = true

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } }).catch(() => null)

    // tentukan sumber gambar
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ""
    let mediaBuffer = null

    const maybeUrl = (args[0] || "").trim()
    if (/^https?:\/\//i.test(maybeUrl)) {
      try {
        const res = await axios.get(maybeUrl, { responseType: "arraybuffer", timeout: 20000 })
        mediaBuffer = Buffer.from(res.data)
        const ft = await fileTypeFromBuffer(mediaBuffer)
        mime = ft ? `image/${ft.ext}` : res.headers["content-type"] || "image/jpeg"
      } catch (e) {
        console.error("Download URL gagal:", e)
        return m.reply("❌ Gagal unduh gambar dari URL.")
      }
    } else {
      if (!mime || !mime.startsWith("image/")) {
        return m.reply("📌 Kirim/reply gambar dengan caption:\n.tofigure2\nAtau: .tofigure2 <url>")
      }
      mediaBuffer = await q.download()
    }

    await conn.sendMessage(m.chat, { text: "🔎 Membuat figurine digital..." }, { quoted: m })

    const outBuffer = await img2img(mediaBuffer, FIGURE_PROMPT, mime)

    await conn.sendMessage(
      m.chat,
      { image: outBuffer, caption: "✅ Hasil figurine siap!\nPrompt sudah tertanam khusus nano-banana." },
      { quoted: m }
    )

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } }).catch(() => null)

  } catch (e) {
    console.error("Error tofigure2:", e)
    m.reply("💥 Error: " + (e?.message || e))
  }
}

handler.help = ["tofigure2"]
handler.tags = ["ai", "image"]
handler.command = /^tofigure2$/i

export default handler