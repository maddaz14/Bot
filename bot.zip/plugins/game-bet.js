// Script Judi Versi @whiskeysockets/baileys
import baileys from '@fuxxy-star/baileys';
const { generateWAMessageFromContent, proto } = baileys;

const fkontak = {
    key: {
        participant: '0@s.whatsapp.net',
        remoteJid: '0@s.whatsapp.net',
        fromMe: false,
        id: 'Halo',
    },
    message: {
        conversation: `🌷 Judi Haram ${global.namebot || 'Bot'} ✨`
    }
};

const confirm = {};

async function showTaruhanMenu(conn, m) {
    let pp = await conn.profilePictureUrl(m.sender, 'image').catch(() => 'https://files.catbox.moe/4tizh9.jpg');
    let oya = `Pilih Jumlah Uang yang Ingin Kamu Taruhkan`;

    let taruhanList = [
        ['10000', '10.000 IDR'],
        ['20000', '20.000 IDR'],
        ['50000', '50.000 IDR'],
        ['100000', '100.000 IDR'],
        ['200000', '200.000 IDR'],
        ['500000', '500.000 IDR'],
        ['all', 'Semua Saldo']
    ];

    let rows = taruhanList.map(([value, label]) => ({
        title: label,
        description: `Taruhan: ${label}`,
        rowId: `.bet ${value}`
    }));

    let listMessage = {
        text: `*${oya}*`,
        footer: `© ${global.namebot || 'Bot'} - Game Judi`,
        title: 'Menu Taruhan Judi',
        buttonText: 'Pilih Jumlah Taruhan',
        sections: [
            {
                title: 'Daftar Taruhan',
                rows
            }
        ]
    };

    await conn.sendMessage(m.chat, listMessage, { quoted: m });
}

let handler = async (m, { conn, args }) => {
    if (!args[0]) return await showTaruhanMenu(conn, m);

    if (m.sender in confirm) throw 'Kamu masih melakukan judi, tunggu sampai selesai!';

    try {
        let user = global.db.data.users[m.sender];
        let count = (args[0] && number(parseInt(args[0]))) ? Math.max(parseInt(args[0]), 1)
            : /all/i.test(args[0]) ? Math.floor(user.money) : 1;

        if (user.money < count) return m.reply('Uang kamu tidak cukup!');

        confirm[m.sender] = {
            sender: m.sender,
            count,
            timeout: setTimeout(() => {
                m.reply('⏱️ Waktu habis!');
                delete confirm[m.sender];
            }, 60000)
        };

        let txt = `Apakah kamu yakin mau melakukan judi?\n\n💵 *Taruhan:* ${count.toLocaleString()} IDR\n⏳ Waktu: 60 detik\n\nBalas *Iya* untuk lanjut atau *Tidak* untuk batal.`;

        await conn.sendMessage(m.chat, {
            text: txt,
            footer: 'Pikir dulu matang-matang ya:',
            buttons: [
                { buttonId: 'iya', buttonText: { displayText: 'Iya' }, type: 1 },
                { buttonId: 'tidak', buttonText: { displayText: 'Tidak' }, type: 1 }
            ],
            headerType: 1
        }, { quoted: fkontak });

    } catch (e) {
        console.error(e);
        if (m.sender in confirm) {
            clearTimeout(confirm[m.sender].timeout);
            delete confirm[m.sender];
            m.reply('Terjadi kesalahan, judi dibatalkan.');
        }
    }
};

handler.before = async m => {
    if (!(m.sender in confirm)) return;
    if (m.isBaileys) return;

    let { timeout, count } = confirm[m.sender];
    let user = global.db.data.users[m.sender];
    let uangAwal = user.money;

    let txt = (m.msg?.selectedDisplayText || m.text || '').toLowerCase();

    try {
        if (/^(iya|yes|ya)$/i.test(txt)) {
            let bot = Math.ceil(Math.random() * 91);
            let kamu = Math.floor(Math.random() * 71);
            let status = 'Kalah';

            if (bot < kamu) {
                user.money += count;
                status = 'Menang';
            } else if (bot > kamu) {
                user.money -= count;
            } else {
                status = 'Seri';
                user.money += Math.floor(count / 1.5);
            }

            m.reply(`🎲 *Hasil Taruhan*\n\n🤖 Bot: ${bot}\n🙎 Kamu: ${kamu}\n\n📈 Status: *${status}*\n${
                status === 'Menang' ? `🎉 Menang *+${count * 2}* IDR` :
                status === 'Kalah' ? `😢 Kalah *-${count}* IDR` :
                `⚖️ Seri *+${Math.floor(count / 1.5)}* IDR`
            }\n\n> © ${global.namebot || 'Bot'}`);

        } else if (/^(tidak|no)$/i.test(txt)) {
            m.reply('❌ Judi dibatalkan.\n\n> © ' + (global.namebot || 'Bot'));
        } else return;

    } catch (e) {
        console.error(e);
        if (uangAwal > user.money) user.money = uangAwal;
        m.reply('❗ Terjadi error saat memproses judi.\n\n> © ' + (global.namebot || 'Bot'));
    } finally {
        clearTimeout(timeout);
        delete confirm[m.sender];
    }

    return true;
};

handler.help = ['judi'];
handler.tags = ['rpg'];
handler.command = /^(judi|bet)$/i;

export default handler;

function number(x = 0) {
    x = parseInt(x);
    return !isNaN(x) && typeof x === 'number';
}