import fs from 'fs';
import path from 'path';

let handler = async (m, { conn }) => {
    let pluginsPath = './plugins/';
    let files = fs.readdirSync(pluginsPath).filter(f => (f.endsWith('.js') || f.endsWith('.cjs')) && f !== 'checkreadreceipt.js');
    let found = [];

    for (let file of files) {
        let content = fs.readFileSync(path.join(pluginsPath, file), 'utf8');
        if (content.includes('sendReadReceipt')) {
            found.push(file);
        }
    }

    if (found.length > 0) {
        m.reply(`⚠️ Ditemukan plugin yang masih pakai \`sendReadReceipt\`:\n\n${found.map(f => `• ${f}`).join('\n')}\n\nSegera ubah ke \`readMessages\` ya.`);
    } else {
        m.reply(`✅ Tidak ada plugin yang pakai \`sendReadReceipt\`.`);
    }
};

handler.command = /^checkreadreceipt$/i;
handler.help = ['checkreadreceipt'];
handler.tags = ['tools'];

export default handler;