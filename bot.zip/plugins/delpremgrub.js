const handler = async (m, { conn }) => {
  if (!m.isGroup) return m.reply('❌ Fitur ini hanya bisa digunakan di grup.');

  const chat = global.db.data.chats[m.chat];

  if (!chat || !chat.isPremiumGroup) {
    return m.reply('ℹ️ Grup ini tidak sedang berstatus premium.');
  }

  // Hapus status premium grup
  chat.isPremiumGroup = false;
  chat.premiumGroupExpire = 0;

  if (global.db.write) await global.db.write();

  m.reply('✅ Grup ini tidak lagi berstatus *Premium Group*. Semua anggota tidak bisa menggunakan fitur premium kecuali mereka memiliki premium pribadi.');
};

handler.command = /^delpremgrub$/i;
handler.help = ['delpremgrub'];
handler.tags = ['owner'];
handler.group = true;
handler.owner = true;

export default handler;