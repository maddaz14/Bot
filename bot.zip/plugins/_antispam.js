let spamTracker = {};

export async function before(m, { conn, isBotAdmin, isAdmin, isOwner }) {
  if (!m.isGroup || m.isBaileys || m.fromMe) return true;

  // Pastikan data chat selalu ada
  let chat = global.db.data.chats[m.chat] || {};
  if (typeof chat.antiSpam === 'undefined') chat.antiSpam = false;

  if (!chat.antiSpam) return true;

  // Cek jika pengirim admin atau owner
  if (isAdmin || isOwner) return true;

  const sender = m.sender;
  const now = Date.now();

  // Inisialisasi tracking spam per grup & user
  if (!spamTracker[m.chat]) spamTracker[m.chat] = {};
  if (!spamTracker[m.chat][sender]) {
    spamTracker[m.chat][sender] = { count: 1, lastMessage: now };
  } else {
    const userData = spamTracker[m.chat][sender];
    const delta = now - userData.lastMessage;

    if (delta < 10_000) {
      // kalau jarak pesan < 10 detik → tambah count
      userData.count++;
    } else {
      // reset kalau sudah lewat dari 10 detik
      userData.count = 1;
    }

    userData.lastMessage = now;

    if (userData.count >= 5) {
      // Pastikan data user selalu ada
      let user = global.db.data.users[sender] || {};
      if (typeof user.warnSpam === 'undefined') user.warnSpam = 0;
      global.db.data.users[sender] = user; // simpan balik

      user.warnSpam += 1;
      userData.count = 0; // reset hitungan spam

      if (user.warnSpam >= 5) {
        if (isBotAdmin && !isAdmin) {
          await m.reply(
            `🚫 *ANTI SPAM*\n@${sender.split`@`[0]} melakukan spam dan mencapai 5 peringatan.\nAkan dikeluarkan dari grup.`,
            false,
            { mentions: [sender] }
          );
          await conn.groupParticipantsUpdate(m.chat, [sender], 'remove');
        } else {
          await m.reply(
            `⚠️ *ANTI SPAM*\n@${sender.split`@`[0]} sudah 5x peringatan, tapi tidak bisa dikeluarkan (bot bukan admin / dia admin).`,
            false,
            { mentions: [sender] }
          );
        }
        user.warnSpam = 0;
      } else {
        await m.reply(
          `⚠️ *ANTI SPAM*\n@${sender.split`@`[0]} terlalu sering mengirim pesan!\nPeringatan: *${user.warnSpam}/5*`,
          false,
          { mentions: [sender] }
        );
      }
    }
  }

  return true;
}