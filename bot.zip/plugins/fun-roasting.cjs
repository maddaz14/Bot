const axios = require('axios');
const cheerio = require('cheerio'); // Tambahkan cheerio jika belum ada

// Handler utama bot
let handler = async (m, { conn, usedPrefix, command, text }) => {
    if (!text) {
        throw `*Contoh:* ${usedPrefix + command} *[username]*`;
    }

    try {
        await m.reply("🕊️ Mencoba me-roasting akun...");
        const result = await getRoastingData(text);
        m.reply(result);
    } catch (error) {
        console.error("Error in roasting handler:", error);
        m.reply("❌ Maaf, tidak dapat me-roasting akun tersebut.");
    }
};

handler.help = ["roasting"].map(a => a + " *[username sosmed]*");
handler.tags = ["fun"];
handler.command = ["roasting"];
module.exports = handler;

// ---
// Fungsi utama untuk mencoba semua API
// ---

async function getRoastingData(username) {
    // Urutan prioritas: GitHub -> Instagram -> TikTok -> Threads
    let result;
    try {
        result = await roastGithub(username);
        if (result) return result;
    } catch (e) {
        // Lanjut ke API berikutnya jika gagal
    }

    try {
        result = await roastInstagram(username);
        if (result) return result;
    } catch (e) {
        // Lanjut ke API berikutnya jika gagal
    }

    try {
        result = await roastTiktok(username);
        if (result) return result;
    } catch (e) {
        // Lanjut ke API berikutnya jika gagal
    }

    try {
        result = await roastThreads(username);
        if (result) return result;
    } catch (e) {
        // Lanjut ke API berikutnya jika gagal
    }

    return "Akun ini Tidak bisa diroasting jir";
}

// ---
// Fungsi-fungsi pembantu untuk setiap API
// ---

async function roastGithub(username) {
    const userResponse = await axios.get(`https://api.github.com/users/${username}`);
    const userData = userResponse.data;
    const reposResponse = await axios.get(`https://api.github.com/users/${username}/repos?sort=updated`);
    const repos = reposResponse.data;

    const formattedRepos = repos.map((repo) => ({
        name: repo.name,
        language: repo.language,
        stargazers_count: repo.stargazers_count,
        open_issues_count: repo.open_issues_count,
        created_at: repo.created_at,
        updated_at: repo.updated_at,
        html_url: repo.html_url,
    }));

    const payload = {
        jsonData: JSON.stringify({
            name: userData.name || null,
            bio: userData.bio || null,
            company: userData.company || null,
            location: userData.location || null,
            followers: userData.followers,
            following: userData.following,
            public_repos: userData.public_repos,
            created_at: userData.created_at,
            updated_at: userData.updated_at,
            repositories: formattedRepos,
        }),
        README: null,
        model: "llama",
        language: "indonesia",
        apiKey: "",
    };

    const postResponse = await axios.post(`https://lelowgdwvvozdsjiixps.vercel.app/roasting?username=${username}`, payload, {
        headers: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36",
            Referer: "https://roastgithub.vercel.app/",
        },
    });

    return "*[ GitHub ]* " + postResponse.data.roasting;
}

async function roastInstagram(username) {
    const apiURL = `https://akhirpetang.vercel.app/api/ig?username=${encodeURIComponent(username)}`;
    const response = await fetch(apiURL, {
        headers: {
            Authorization: "Bearer akhirpetang-09853773678853385327Ab63",
        },
    });
    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);

    const data = await response.json();
    if (data.error) throw new Error(`Akun Instagram dengan username ${username} tidak ditemukan.`);

    const roastingApiURL = `https://roastiges.vercel.app/api/roasting?username=${encodeURIComponent(data.nama_lengkap)}&biodata=${encodeURIComponent(JSON.stringify(data))}&language=indonesia`;
    const roastingResponse = await fetch(roastingApiURL, {
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
    });
    if (!roastingResponse.ok) throw new Error(`HTTP error! Status: ${roastingResponse.status}`);

    const roastingData = await roastingResponse.json();
    return "*[ Instagram ]* " + (roastingData.roasting || "Tidak ada data roasting.");
}

async function roastTiktok(username) {
    const profileUrl = `https://tiktok-roasting.vercel.app/api/tiktok-profile?username=${username}`;
    const roastUrl = `https://tiktok-roasting.vercel.app/api/generate-roast`;

    const profileResponse = await fetch(profileUrl);
    if (!profileResponse.ok) throw new Error(`HTTP error! Status: ${profileResponse.status}`);
    const profileData = await profileResponse.json();
    if (!profileData || profileData.error) throw new Error("Akun tidak ditemukan.");

    const body = {
        username: profileData.username,
        profile: profileData,
        language: "indonesian",
    };
    const roastResponse = await fetch(roastUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    });
    if (!roastResponse.ok) throw new Error(`HTTP error! Status: ${roastResponse.status}`);

    const roastData = await roastResponse.json();
    return "*[ Tiktok ]* " + (roastData.roasting || "Tidak ada data roasting.");
}

async function roastThreads(username) {
    const url = `https://threads-roaster.vercel.app/?u=${encodeURIComponent(username)}&l=id`;
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
    
    const html = await response.text();
    const $ = cheerio.load(html);
    
    const result = {};
    result.username = $(".card-title").text().trim();
    if (!result.username) throw new Error("Akun pengguna tidak ditemukan");
    
    result.roasting = $(".card-body p").eq(1).text().trim();
    result.postLink = $(".card-actions a").attr("href") || "Tidak ada tautan";
    
    return "*[ Threads ]* " + (result.roasting || "Tidak ada yang bisa diroasting");
}