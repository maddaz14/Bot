import fs from 'fs';
import path from 'path';

const victimDatabasePath = path.resolve('./database/victimDatabase.json');

function loadData(filePath) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, '{}');
    }
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
}

function saveData(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

const getUserName = (jid) => {
    const user = global.db.data.users?.[jid] || {};
    return user.name || jid.split('@')[0];
};

let handler = async (m, { text, mentionedJid }) => {
    const args = text.trim().split(/\s+/);
    if (args.length < 2) return m.reply('Contoh: .addvictim @user 5 atau .addvictim 628xxxxxx 3');

    let target, amount;

    // Cari angka terakhir di argumen sebagai jumlah
    const amountMatch = text.match(/\d+$/);
    amount = amountMatch ? parseInt(amountMatch[0]) : NaN;
    if (isNaN(amount) || amount <= 0) return m.reply('Jumlah harus berupa angka positif.\nContoh: .addvictim @user 5 atau .addvictim 628xxxx 3');

    // Ambil target
    if (mentionedJid?.length) {
        target = mentionedJid[0];
    } else {
        // Coba ambil nomor dari argumen (misalnya: .addvictim 6281234567890 3)
        const number = args.find(arg => /^\d{5,}$/.test(arg)); // cari argumen yang mirip nomor telepon
        if (number) {
            target = number.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        }
    }

    if (!target) return m.reply('Tag atau masukkan nomor yang valid.');

    let victimDatabase = loadData(victimDatabasePath);

    if (!victimDatabase[target]) {
        victimDatabase[target] = { killed: 0, kills: 0 };
    }

    victimDatabase[target].killed += amount;
    saveData(victimDatabasePath, victimDatabase);

    m.reply(`☠️ Death untuk *${getUserName(target)}* berhasil ditambah *${amount}x*.\nTotal sekarang: *${victimDatabase[target].killed} death*`);
};

handler.help = ['addvictim @tag|nomor jumlah'];
handler.tags = ['owner'];
handler.command = /^addvictim$/i;
handler.owner = true;

export default handler;