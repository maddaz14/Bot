import fetch from 'node-fetch';

// Objek kontak dummy (Opsional)
const fkontak = {
  key: {
    participant: '0@s.whatsapp.net',
    remoteJid: 'status@broadcast',
    fromMe: false,
    id: 'Halo',
  },
  message: {
    conversation: `📚 Gist Downloader by ${global.namebot}`,
  },
};

// Handler utama untuk plugin
let handler = async (m, { conn, text, usedPrefix, command }) => {
  // Pastikan pengguna menyertakan URL Gist
  if (!text) {
    return conn.reply(m.chat, `⚠️ Masukkan URL GitHub Gist.\nContoh: *${usedPrefix + command} https://gist.github.com/siputzx/966268a3aa3c14695e80cc9f30da8e9f*`, m, { quoted: fkontak });
  }

  // Validasi URL sederhana
  const gistUrl = text.trim();
  if (!gistUrl.includes('gist.github.com')) {
    return conn.reply(m.chat, '❌ URL yang Anda masukkan bukan URL GitHub Gist yang valid.', m);
  }

  try {
    // Kirim reaksi '⏳' untuk menandakan sedang diproses
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    // Panggil API untuk mendapatkan data Gist
    const url = `https://api.siputzx.my.id/api/d/github?url=${encodeURIComponent(gistUrl)}`;
    const res = await fetch(url);
    
    // Periksa status respons
    if (!res.ok) {
      throw new Error(`Gagal terhubung ke API. Status: ${res.status}`);
    }

    const json = await res.json();

    // Periksa apakah ada data Gist yang valid
    if (!json.status || !json.data || !json.data.files || json.data.files.length === 0) {
      return conn.reply(m.chat, `❌ Gist tidak ditemukan atau tidak memiliki file.`, m);
    }
    
    const { owner, description, files } = json.data;

    // Kirim deskripsi Gist jika ada
    let responseText = `*📚 Gist oleh ${owner}*`;
    if (description) {
        responseText += `\n_${description}_\n\n`;
    }

    // Kirim konten setiap file dalam Gist
    for (const file of files) {
        const fileContent = `
*File:* ${file.name}
*Bahasa:* ${file.language || 'Tidak diketahui'}
\`\`\`${file.content}\`\`\`
        `.trim();
        await conn.sendMessage(m.chat, { text: fileContent }, { quoted: m });
    }

    // Kirim reaksi '✅' setelah berhasil
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error(e);
    // Kirim reaksi '❌' jika terjadi error
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    conn.reply(m.chat, `❌ Terjadi kesalahan: ${e.message}`, m);
  }
};

// Pengaturan metadata plugin
handler.help = ['github'];
handler.tags = ['downloader'];
handler.command = /^(github)$/i;
handler.limit = true;
handler.register = true;

export default handler;