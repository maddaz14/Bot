import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Kirim dengan format:\n\n*${usedPrefix + command} <isi tweet>*`;

    await conn.sendMessage(m.chat, { react: { text: '✍️', key: m.key } });

    // Ambil nama dan profil
    let name = m.pushName || 'User';
    let username = 'ubed Bot';
    let theme = 'dark';
    let retweets = 1000;
    let quotes = 200;
    let likes = 5000;
    let client = 'Twitter for iPhone';

    // Ambil foto profil user
    let profile;
    try {
        profile = await conn.profilePictureUrl(m.sender, 'image');
    } catch (e) {
        profile = 'https://files.catbox.moe/y8rn53.jpg';
    }

    const api = `https://api.siputzx.my.id/api/m/tweet?profile=${encodeURIComponent(profile)}&name=${encodeURIComponent(name)}&username=${encodeURIComponent(username)}&tweet=${encodeURIComponent(text)}&image=null&theme=${theme}&retweets=${retweets}&quotes=${quotes}&likes=${likes}&client=${encodeURIComponent(client)}`;

    try {
        const res = await axios.get(api, { responseType: 'arraybuffer' });

        await conn.sendMessage(m.chat, {
            image: res.data,
            caption: `🕊️ Tweet oleh @${username}`
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (e) {
        console.error(e);
        m.reply('❌ Gagal membuat tweet.');
    }
};

handler.help = ['faketweet <text>'];
handler.tags = ['maker'];
handler.command = /^faketweet$/i;
handler.limit = true;

export default handler;