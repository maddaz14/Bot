// plugins/fun-livefunfact.js
import util from 'util'

async function generateAdvancedFunFacts(birthDate) {
  const birth = new Date(birthDate)
  const now = new Date()
  
  if (isNaN(birth.getTime())) throw new Error('Format tanggal tidak valid. Gunakan YYYY-MM-DD.')
  if (birth > now) throw new Error('Tanggal lahir tidak boleh di masa depan.')

  const timeDiff = now - birth
  const ageInSeconds = Math.floor(timeDiff / 1000)
  const ageInMinutes = Math.floor(ageInSeconds / 60)
  const ageInHours = Math.floor(ageInMinutes / 60)
  const ageInDays = Math.floor(ageInHours / 24)
  const ageInWeeks = Math.floor(ageInDays / 7)
  const ageInMonths = Math.floor(ageInDays / 30.44)
  const ageInYears = Math.floor(ageInDays / 365.25)

  return {
    birthDate: birth.toISOString().split('T')[0],
    calculatedAt: now.toISOString(),
    basicInfo: {
      ageInYears,
      ageInMonths,
      ageInWeeks,
      ageInDays,
      ageInHours,
      ageInMinutes,
      ageInSeconds
    },
    respiratory: {
      totalBreaths: ageInMinutes * 15,
      oxygenConsumedL: Math.round(ageInMinutes * 250 / 1000),
    },
    cardiovascular: {
      heartBeatsTotal: ageInMinutes * 70,
      bloodPumpedL: ageInMinutes * 5,
    },
    neurological: {
      actionPotentials: ageInSeconds * 200000000,
      brainEnergyConsumedKJ: ageInDays * 1728,
    },
    digestive: {
      salivaProducedL: ageInDays * 1.5,
      gastricJuiceProducedL: ageInDays * 2.5,
    },
    renal: {
      bloodFilteredL: ageInMinutes * 1.2,
      urineProducedL: ageInDays * 1.5,
    },
    immuneSystem: {
      whiteCellsProduced: ageInDays * (200000000000 / 28),
    },
    sensory: {
      eyeBlinks: ageInMinutes * 20,
      eyeMovements: ageInDays * 100000,
    },
    lifeComparison: {
      worldLifeExpectancy: 73.4,
      percentageOfLifeLived: Math.round((ageInYears / 73.4) * 100),
      estimatedRemainingYears: Math.max(0, Math.round(73.4 - ageInYears))
    }
  }
}

let handler = async (m, { conn, text }) => {
  if (!text) throw `Format salah!\nGunakan: .livefunfact YYYY-MM-DD\nContoh: .livefunfact 2000-01-01`

  try {
    let result = await generateAdvancedFunFacts(text.trim())
    let caption = `📊 *Live Fun Fact Berdasarkan Tanggal Lahir*\n\n`
    caption += `📅 Tanggal Lahir: *${result.birthDate}*\n`
    caption += `📆 Umur: *${result.basicInfo.ageInYears} tahun* (${result.basicInfo.ageInDays} hari)\n`
    caption += `💓 Total detak jantung: *${result.cardiovascular.heartBeatsTotal.toLocaleString()} kali*\n`
    caption += `🫁 Total napas: *${result.respiratory.totalBreaths.toLocaleString()} kali*\n`
    caption += `🧠 Energi otak dipakai: *${result.neurological.brainEnergyConsumedKJ.toLocaleString()} kJ*\n`
    caption += `👁️ Kedipan mata: *${result.sensory.eyeBlinks.toLocaleString()} kali*\n`
    caption += `🧬 Sel darah putih diproduksi: *${result.immuneSystem.whiteCellsProduced.toLocaleString()}*\n\n`
    caption += `🌍 Harapan hidup dunia: *${result.lifeComparison.worldLifeExpectancy} tahun*\n`
    caption += `⏳ Persentase hidup dijalani: *${result.lifeComparison.percentageOfLifeLived}%*\n`
    caption += `🔮 Estimasi sisa hidup: *${result.lifeComparison.estimatedRemainingYears} tahun*\n`

    await conn.reply(m.chat, caption, m)
  } catch (e) {
    throw `❌ Error: ${e.message}`
  }
}

handler.help = ['livefunfact <YYYY-MM-DD>']
handler.tags = ['fun']
handler.command = /^livefunfact$/i
handler.limit = false

export default handler