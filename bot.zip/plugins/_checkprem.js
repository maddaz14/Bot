let before = async (m, { plugin }) => {
  if (!plugin || !plugin.premium) return; // Tambahkan pengecekan plugin ada atau tidak

  const user = global.db.data.users[m.sender] || {};
  const chat = global.db.data.chats[m.chat] || {};
  const now = Date.now();

  const isUserPremium = user.premium && (user.premiumTime === Infinity || user.premiumTime > now);
  const isGroupPremium = m.isGroup && chat.isPremiumGroup && chat.premiumGroupExpire > now;

  if (!isUserPremium && !isGroupPremium) {
    throw '❌ Fitur ini hanya bisa digunakan oleh pengguna premium atau di dalam grup premium.';
  }
};

export default {
  before,
};