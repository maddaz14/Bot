import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text) {
    try {
      const list = await genshindb.geographies("names", { matchCategories: true });
      return m.reply(`📜 *Daftar Area Tersedia:*\n\n${list.join(", ")}`);
    } catch (e) {
      console.error('[GEOGRAPHY LIST ERROR]', e);
      return m.reply('❌ Gagal mengambil daftar area.');
    }
  }

  try {
    const result = await genshindb.geographies(text);
    if (result) {
      let response = `🌍 *Info Geografi: ${result.name}*\n\n`;
      response += `📝 _${result.description || "Deskripsi tidak tersedia"}_\n\n`;
      response += `📍 *Area:* ${result.area || "Tidak diketahui"}\n`;
      response += `🌐 *Region:* ${result.region || "Tidak diketahui"}\n`;
      response += `🔢 *Urutan Sortir:* ${result.sortorder || "Tidak diketahui"}`;
      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[GEOGRAPHY ERROR]', err);
    try {
      const available = await genshindb.geographies("names", { matchCategories: true });
      return m.reply(`❌ Geografi '${text}' tidak ditemukan.\n\n📜 *Area yang tersedia:*\n${available.join(", ")}`);
    } catch (e) {
      return m.reply('⚠️ Gagal menampilkan daftar area.');
    }
  }
};

handler.help = ['genshin-area <nama area>'];
handler.tags = ['game'];
handler.command = /^(genshin-area|g-area|gens-area)$/i;
handler.limit = 1;
handler.register = true;

export default handler;