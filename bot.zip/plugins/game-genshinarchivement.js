import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text) {
    try {
      const list = await genshindb.achievements("names", { matchCategories: true });
      return m.reply(`📜 *Daftar Prestasi Tersedia:*\n\n${list.join(", ")}`);
    } catch (e) {
      console.error('[ACHIEVEMENT LIST ERROR]', e);
      return m.reply('❌ Gagal mengambil daftar prestasi.');
    }
  }

  try {
    const result = await genshindb.achievements(text);
    if (result) {
      let response = `🏆 *Prestasi Ditemukan: ${result.name}*\n\n`;
      response += `📝 _${result.description || "Deskripsi tidak tersedia"}_\n\n`;
      response += `📂 *Kategori:* ${result.category || "Tidak diketahui"}\n`;
      response += `🎖️ *Rarity:* ${result.rarity || "Tidak diketahui"}\n`;
      response += `🔎 *Detail:* ${result.detail || "Tidak diketahui"}\n`;
      response += `📌 *Cara Mendapatkan:* ${result.howToObtain || "Tidak diketahui"}`;
      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[ACHIEVEMENT ERROR]', err);
    try {
      const list = await genshindb.achievements("names", { matchCategories: true });
      return m.reply(`❌ Prestasi '${text}' tidak ditemukan.\n\n📜 *Prestasi yang tersedia:*\n${list.join(", ")}`);
    } catch (e) {
      return m.reply('⚠️ Gagal menampilkan daftar prestasi.');
    }
  }
};

handler.help = ['genshin-achievement <nama>'];
handler.tags = ['game'];
handler.command = /^(genshin-achievement|g-achievement|gens-achievement)$/i;
handler.limit = 1;
handler.register = true;

export default handler;