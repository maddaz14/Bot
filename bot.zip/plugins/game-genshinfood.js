import genshindb from 'genshin-db';

let handler = async (m, { text, command, usedPrefix }) => {
  if (db.data.users[m.sender].glimit < 1)
    return m.reply(`💢 Limit game kamu sudah habis`);
  db.data.users[m.sender].glimit -= 1;

  if (!text) {
    try {
      const list = await genshindb.foods("names", { matchCategories: true });
      return m.reply(`🍱 *Daftar Makanan yang Tersedia:*\n\n${list.join(", ")}`);
    } catch (e) {
      console.error('[FOOD LIST ERROR]', e);
      return m.reply('❌ Gagal mengambil daftar makanan.');
    }
  }

  try {
    const result = await genshindb.foods(text);

    if (result) {
      let response = `🍱 *Makanan Ditemukan: ${result.name}*\n\n`;
      response += `📖 _"${result.description || "Deskripsi tidak tersedia"}"_\n\n`;
      response += `⭐ *Rarity:* ${result.rarity || "Tidak diketahui"}\n`;
      response += `📦 *Type:* ${result.foodtype || "Tidak diketahui"}\n`;
      response += `📂 *Category:* ${result.foodfilter || "?"} (${result.foodcategory || "?"})\n\n`;

      if (result.effect) {
        response += `✨ *Effect:*\n${result.effect}\n\n`;
      }
      if (result.suspicious) {
        response += `😕 *Suspicious:*\n${result.suspicious.effect}\n_"${result.suspicious.description}"_\n\n`;
      }
      if (result.normal) {
        response += `🙂 *Normal:*\n${result.normal.effect}\n_"${result.normal.description}"_\n\n`;
      }
      if (result.delicious) {
        response += `😋 *Delicious:*\n${result.delicious.effect}\n_"${result.delicious.description}"_\n\n`;
      }

      return m.reply(response.trim());
    } else {
      throw "Not Found";
    }
  } catch (err) {
    console.warn('[FOOD ERROR]', err);
    try {
      const available = await genshindb.foods("names", { matchCategories: true });
      return m.reply(`❌ Makanan '${text}' tidak ditemukan.\n\n📜 *Makanan yang tersedia:*\n${available.join(", ")}`);
    } catch (e) {
      return m.reply('⚠️ Gagal menampilkan daftar makanan.');
    }
  }
};

handler.help = ['genshin-food <nama makanan>'];
handler.tags = ['game'];
handler.command = /^(genshin-food|g-food|gens-food)$/i;
handler.limit = 1;
handler.register = true;

export default handler;